#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JERRY Key Bayi Botu
Tek dosyalık Telegram bayi/admin/key stok yönetim botu.

Kurulum:
  pip install -U python-telegram-bot
  python jerry_key_bayi_bot.py

Not: Token dosyaya yerleştirildi. İstersen BOT_TOKEN ortam değişkeniyle override edebilirsin.
Admin ID: 8587288454
"""

from __future__ import annotations

import asyncio
import hashlib
import html
import io
import logging
import os
import re
import secrets
import sqlite3
import sys
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update, WebAppInfo
from telegram.constants import ParseMode
from telegram.error import BadRequest, TelegramError
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

# =========================
# AYARLAR
# =========================
ADMIN_IDS = {8587288454}
DB_PATH = os.environ.get("JERRY_DB", "jerry_bayi_bot.sqlite3")
BOT_TOKEN = os.environ.get("BOT_TOKEN") or os.environ.get("TELEGRAM_BOT_TOKEN") or "8842464258:AAHt4cCqOSaQ4nI8yJ1d1tb-On1s16XARiQ"
MINIAPP_URL = os.environ.get("MINIAPP_URL", "").strip()
DEFAULT_LANG = "tr"
SUPPORTED_LANGS = ("tr", "en", "uz", "ru")
ROLE_ORDER = ["customer", "sub_seller", "seller", "distributor", "admin"]
PRICE_ROLE_PRIORITY = ["user", "sub_seller", "seller", "distributor"]

# Key satın alma ana platformları. Bu üç kategori DB'de otomatik hazır tutulur.
PLATFORM_CATEGORIES: tuple[tuple[str, str, str], ...] = (
    ("android", "🤖", "Android"),
    ("ios", "🍎", "iOS"),
    ("emulator_pc", "🖥", "Emülatör / PC"),
)
PLATFORM_KEY_ORDER = {key: idx for idx, (key, _emoji, _name) in enumerate(PLATFORM_CATEGORIES, start=1)}
PLATFORM_ALIASES = {
    "android": "android",
    "andorid": "android",
    "androıd": "android",
    "ios": "ios",
    "i̇os": "ios",
    "iphone": "ios",
    "ipad": "ios",
    "emulator": "emulator_pc",
    "emülatör": "emulator_pc",
    "emulator pc": "emulator_pc",
    "emülatör pc": "emulator_pc",
    "emülatör / pc": "emulator_pc",
    "emulator / pc": "emulator_pc",
    "pc": "emulator_pc",
}

# Owner dışındaki yöneticilerde buton bazlı yetki sistemi.
ADMIN_PERMISSIONS: dict[str, str] = {
    "resellers": "👥 Bayi/Rol Yönet",
    "prices": "💵 Özel Fiyatlar",
    "keys": "🔑 Key/Stok Yönet",
    "cats": "📦 Kategori Yönet",
    "products": "🛒 Ürün Yönet",
    "balance": "💰 Bakiye Yönet",
    "history": "📜 Geçmiş Görüntüle",
    "users": "👤 Kullanıcı/Ban Yönet",
    "seed": "🧪 Demo Veri",
}
PERMISSION_ORDER = list(ADMIN_PERMISSIONS.keys())
ADMIN_FLOW_PERMS = {
    "reseller": "resellers",
    "price": "prices",
    "key_single": "keys",
    "key_bulk": "keys",
    "stock_dec": "keys",
    "cat_add": "cats",
    "cat_del": "cats",
    "prod_add": "products",
    "prod_del": "products",
    "balance": "balance",
    "user_lookup": "users",
    "ban_user": "users",
    "unban_user": "users",
}

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger("jerry-bayi-bot")

# =========================
# DİL SİSTEMİ
# =========================
TEXT: dict[str, dict[str, str]] = {
    "tr": {
        "start_title": "✨ <b>JERRY Bayi Paneli</b>",
        "start_body": "Telegram ID’n otomatik algılandı ve giriş yapıldı.\n\n🆔 ID: <code>{user_id}</code>\n👤 Rol: <b>{role}</b>\n💰 Bakiye: <b>${balance:.2f}</b>\n🖥 Görünüm: <b>{layout}</b>",

        "auth_title": "🔐 <b>JERRY Hesap Girişi</b>",
        "auth_body": "Devam etmek için kayıt ol veya mail/şifre ile giriş yap.\n\n🆔 Telegram ID: <code>{user_id}</code>",
        "auth_register": "Kayıt Ol",
        "auth_login": "Giriş Yap",
        "auth_forgot": "Şifremi Unuttum",
        "auth_email_prompt": "📧 Mail adresini yaz.\nÖrnek: <code>mail@example.com</code>",
        "auth_password_prompt": "🔑 Şifreni yaz.\nEn az 6 karakter olsun.",
        "auth_new_password_prompt": "🔄 Yeni şifreni yaz.\nBu işlem sadece bu Telegram hesabına bağlı hesap için yapılır.",
        "auth_registered_ok": "✅ Kayıt tamamlandı. Giriş yapıldı.",
        "auth_login_ok": "✅ Giriş başarılı.",
        "auth_reset_ok": "✅ Şifre sıfırlandı. Giriş yapıldı.",
        "auth_no_account": "Bu Telegram hesabına bağlı kayıt yok. Önce kayıt ol.",
        "auth_bad_email": "Mail formatı hatalı. Örnek: <code>mail@example.com</code>",
        "auth_email_used": "Bu mail başka bir Telegram hesabında kayıtlı.",
        "auth_bad_password": "Şifre en az 6 karakter olmalı.",
        "auth_login_failed": "Mail veya şifre hatalı.",
        "auth_required": "Devam etmek için giriş yapmalısın.",
        "auth_cancel": "Giriş ekranına dön",
        "blocked_logout": "Oturum kapalı. Devam etmek için giriş yap.",
        "main_menu": "🏠 Ana Menü",
        "buy_key": "Key Satın Alma",
        "categories": "Kategoriler",
        "products": "Ürünler",
        "prices": "Fiyatlar",
        "my_keys": "Key Geçmişi",
        "tx_history": "İşlem Geçmişi",
        "balance": "Bakiye",
        "layout": "PC / Mobil",
        "language": "Dil",
        "logout": "Çıkış Yap",
        "admin_panel": "Admin Panel",
        "back": "Geri",
        "home": "Ana Menü",
        "no_categories": "Henüz aktif kategori yok.",
        "select_category": "📦 Kategori seç:",
        "select_product": "🛒 Ürün seç:\nKategori: <b>{category}</b>",
        "no_products": "Bu kategoride aktif ürün yok.",
        "product_card": "🎮 <b>Satın Alma Detayı</b>\n\n🛒 Paket: <b>{name}</b>\n💵 Fiyat: <b>${price:.2f}</b>\n⏳ Süre: <b>{days} gün</b>\n📦 Stok: <b>{stock}</b>\n\n✅ Satın alınca key otomatik teslim edilir. Key üstüne basılı tutup kopyalayabilirsin.",
        "category_detail": "🎮 <b>{category}</b>\n\n🛒 <b>Ürünler</b>\n\n<b>Paketler:</b>\n{packages}",
        "package_daily": "Günlük",
        "package_weekly": "Haftalık",
        "package_monthly": "Aylık",
        "package_custom": "{days} Günlük",
        "no_packages": "Henüz paket yok.",
        "confirm_buy": "Satın Al",
        "insufficient": "Yetersiz bakiye. Gereken: ${price:.2f}, mevcut: ${balance:.2f}",
        "sold_out": "Bu üründe stok yok.",
        "purchase_ok": "✅ Satın alma başarılı!\n\nÜrün: <b>{product}</b>\nKey: <code>{key}</code>\nBitiş: <b>{expires}</b>\n\nKey’i kopyalamak için üzerine basılı tut.",
        "copy_key": "Key Göster / Kopyala",
        "key_info": "🔑 <b>Key Bilgisi</b>\n\nÜrün: <b>{product}</b>\nKey: <code>{key}</code>\nDurum: <b>{status}</b>\nBitiş: <b>{expires}</b>\nReset: <b>{reset_count}/{max_resets}</b>",
        "reset_key": "Key Resetle",
        "reset_ok": "✅ Key resetlendi.\nKey: <code>{key}</code>\nReset: {reset_count}/{max_resets}",
        "reset_limit": "Bu key için reset hakkı bitmiş.",
        "reset_request_sent": "✅ Key sıfırlama isteğin admine gönderildi. Onaylanınca sana mesaj gelecek.",
        "reset_request_pending": "⏳ Bu key için zaten bekleyen bir reset isteğin var. Admin onayını bekle.",
        "reset_admin_request": "🔄 <b>Key Reset İsteği</b>\n\nTalep ID: <code>{request_id}</code>\nKullanıcı: <code>{user_id}</code>\nMail: <code>{email}</code>\nÜrün: <b>{product}</b>\nKey: <code>{key}</code>\nReset: <b>{reset_count}/{max_resets}</b>\nTarih: <b>{date}</b>",
        "reset_approve": "Onayla",
        "reset_reject": "Reddet",
        "reset_request_approved_admin": "✅ Reset talebi onaylandı. Kullanıcıya mesaj gönderildi.\nTalep ID: <code>{request_id}</code>",
        "reset_request_rejected_admin": "❌ Reset talebi reddedildi. Kullanıcıya mesaj gönderildi.\nTalep ID: <code>{request_id}</code>",
        "reset_user_approved": "✅ Key sıfırlandı.\nKey: <code>{key}</code>\nReset: <b>{reset_count}/{max_resets}</b>",
        "reset_user_rejected": "❌ Key sıfırlama isteğin admin tarafından reddedildi.",
        "reset_request_not_found": "Bekleyen reset talebi bulunamadı.",
        "reset_requests": "Reset Talepleri",
        "reset_requests_empty": "Bekleyen reset talebi yok.",
        "reset_requests_title": "🔄 <b>Bekleyen Key Reset Talepleri</b>",
        "reset_request_line": "#{request_id} | Kullanıcı: <code>{user_id}</code> | Ürün: <b>{product}</b> | {date}",
        "no_keys": "Henüz satın aldığın key yok.",
        "history_empty": "İşlem geçmişi boş.",
        "tx_line": "#{id} | {type} | ${amount:.2f} | {date}\n{note}",
        "balance_card": "💰 <b>Bakiye</b>\n\nMevcut bakiye: <b>${balance:.2f}</b>",
        "layout_card": "🖥 <b>Görünüm</b>\n\nMevcut: <b>{layout}</b>\nMobil görünüm tek sütun, PC görünüm daha geniş buton düzeni kullanır.",
        "mobile": "Mobil",
        "pc": "PC",
        "layout_set": "Görünüm güncellendi: {layout}",
        "lang_card": "🌐 Dil seç:",
        "lang_set": "Dil güncellendi: Türkçe",
        "logged_out": "Çıkış yapıldı. Tekrar giriş için /start yaz.",
        "admin_only": "Bu alan sadece admin için.",
        "admin_title": "🛡 <b>JERRY Admin Panel</b>\n\n👥 Kullanıcı: <b>{users}</b>\n📦 Kategori: <b>{categories}</b>\n🛒 Ürün: <b>{products}</b>\n🔑 Stok Key: <b>{stock_keys}</b>\n✅ Satılan Key: <b>{sold_keys}</b>",
        "admin_resellers": "Alt-Satıcı Yönet",
        "admin_prices": "Özel Fiyatlar",
        "admin_keys": "Key/Stok Yönet",
        "admin_cats": "Kategori Yönet",
        "admin_products": "Ürün Yönet",
        "admin_balance": "Bakiye Ekle",
        "admin_history": "Ürün Geçmişi",
        "admin_users": "Kullanıcılar",
        "create_reseller": "Alt-Satıcı Oluştur",
        "list_resellers": "Satıcıları Listele",
        "prompt_reseller": "Şu formatta gönder:\n<code>telegram_id | rol | parent_id</code>\n\nRol: distributor / seller / sub_seller\nparent_id boş olabilir.\nÖrnek: <code>123456 | seller | 8587288454</code>",
        "reseller_ok": "✅ Bayi oluşturuldu/güncellendi.\nID: <code>{user_id}</code>\nRol: <b>{role}</b>\nParent: <code>{parent}</code>",
        "reseller_list_empty": "Bayi bulunamadı.",
        "set_custom_price": "Özel Fiyat Ayarla",
        "list_custom_prices": "Özel Fiyatları Listele",
        "prompt_price": "Şu formatta gönder:\n<code>scope | değer | product_id | fiyat</code>\n\nscope: user veya role\nrole değerleri: distributor / seller / sub_seller\nÖrnek: <code>role | seller | 2 | 14.99</code>\nÖrnek: <code>user | 123456 | 2 | 9.50</code>",
        "price_ok": "✅ Özel fiyat kaydedildi.\n{scope}: <code>{value}</code>\nÜrün ID: <code>{product_id}</code>\nFiyat: <b>${price:.2f}</b>",
        "manual_key": "Tekli Key Ekle",
        "bulk_keys": "Toplu Key Ekle",
        "decrease_stock": "Stok Düşür",
        "prompt_single_key": "Key eklemek için şu formatta gönder:\n<code>product_id | KEY GİR</code>\n\nÖrnek: <code>2 | JERRY-KEY-123</code>",
        "prompt_bulk_keys": "İlk satır product_id, sonraki satırlar key olacak şekilde gönder:\n<code>2\nKEY-1\nKEY-2\nKEY-3</code>",
        "prompt_decrease": "Şu formatta gönder:\n<code>product_id | adet | sebep</code>",
        "key_add_ok": "✅ {count} key stoğa eklendi. Atlanan/tekrar: {skipped}",
        "stock_dec_ok": "✅ Stoktan {count} key manuel düşürüldü.",
        "add_category": "Kategori Ekle",
        "delete_category": "Kategori Sil",
        "prompt_cat_add": "Kategori adını gönder.\n\nNot: Android / İOS / Emülatör-PC yazarsan ana platform güncellenir. Farklı isim yazarsan Ek Kategoriler altında görünür.\n\nÖrnek: <code>VIP Paketler</code>\nİstersen açıklama da ekleyebilirsin: <code>VIP Paketler | açıklama</code>",
        "prompt_cat_del": "Silinecek kategori ID gönder:",
        "cat_ok": "✅ Kategori kaydedildi. ID: <code>{id}</code>",
        "cat_deleted": "✅ Kategori pasifleştirildi.",
        "add_product": "Ürün Ekle",
        "delete_product": "Ürün Sil",
        "list_products": "Ürünleri Listele",
        "prompt_prod_add": "📦 Önce platformu seç. Sonra hile/ürün adını, paket süresini ve fiyatı bot tek tek soracak.",
        "prod_wizard_select_cat": "📦 <b>Ürün Ekle</b>\n\n1/4 - Ürün hangi platforma eklensin?",
        "prod_wizard_no_cat": "Önce aktif bir kategori eklemelisin.",
        "prod_wizard_name": "🛒 <b>Ürün Ekle</b>\n\n2/4 - Hile/ürün adını yaz.\nÖrnek: <code>King</code>",
        "prod_wizard_period": "⏳ <b>Ürün Ekle</b>\n\n3/4 - Paket süresini seç.\n\nAşağıdan günlük, haftalık veya aylık paket seçebilirsin. İstersen özel gün sayısı da yazabilirsin.",
        "prod_wizard_price": "💵 <b>Ürün Ekle</b>\n\n4/4 - Paket fiyatını seç veya yaz.\n\nHazır fiyat butonlarına basabilir ya da manuel fiyat gönderebilirsin.\nÖrnek: <code>14.99</code>",
        "prod_wizard_custom_days": "✍️ <b>Özel Süre</b>\n\nKaç gün geçerli olacağını yaz.\nÖrnek: <code>45</code>",
        "prod_wizard_desc": "📝 <b>Ürün Ekle</b>\n\nAçıklama adımı kaldırıldı. Ürün açıklamasız kaydedilecek.",
        "prod_wizard_daily": "Günlük - 1 Gün",
        "prod_wizard_weekly": "Haftalık - 7 Gün",
        "prod_wizard_monthly": "Aylık - 30 Gün",
        "prod_wizard_custom_period": "Özel Süre Yaz",
        "prod_wizard_custom_price": "Manuel Fiyat Yaz",
        "prod_wizard_skip_price": "Fiyatı Atla ($0)",
        "prod_wizard_skip_days": "Süreyi Atla (30 Gün)",
        "prod_wizard_skip_desc": "Açıklama Yok",
        "prod_wizard_confirm": "✅ <b>Ürünü onayla</b>\n\n📦 Platform: <b>{category}</b>\n🎯 Hile/Ürün: <b>{name}</b>\n📅 Paket: <b>{package}</b>\n💵 Fiyat: <b>${price:.2f}</b>\n⏳ Süre: <b>{days} gün</b>",
        "prod_wizard_save": "Kaydet",
        "prod_wizard_edit": "Baştan Başla",
        "prompt_prod_del": "Silinecek ürün ID gönder:",
        "prod_ok": "✅ Ürün kaydedildi. ID: <code>{id}</code>",
        "prod_deleted": "✅ Ürün silindi ve listeden kaldırıldı.",
        "prompt_balance": "Şu formatta gönder:\n<code>telegram_id | miktar | not</code>\nÖrnek: <code>123456 | 25 | Havale</code>",
        "balance_ok": "✅ Bakiye güncellendi.\nKullanıcı: <code>{user_id}</code>\nYeni bakiye: <b>${balance:.2f}</b>",
        "bad_format": "Format hatalı. Örneğe göre tekrar gönder.",
        "not_found": "Kayıt bulunamadı.",
        "cancel": "İptal",
        "cancelled": "İşlem iptal edildi.",
        "unknown": "Anlaşılmadı. /start yazıp menüden devam edebilirsin.",
        "seeded": "Demo kategori/ürün eklendi.",
        "seed_demo": "Demo Veri Ekle",
        "id_card": "🆔 Telegram ID: <code>{user_id}</code>",
        "admin_help": "Admin hızlı komutlar:\n/admin - panel\n/id - kendi ID\n/start - kullanıcı paneli",
    },
    "en": {
        "start_title": "✨ <b>JERRY Dealer Panel</b>",
        "start_body": "Your Telegram ID was detected and you are logged in.\n\n🆔 ID: <code>{user_id}</code>\n👤 Role: <b>{role}</b>\n💰 Balance: <b>${balance:.2f}</b>\n🖥 Layout: <b>{layout}</b>",

        "auth_title": "🔐 <b>JERRY Account Login</b>",
        "auth_body": "Register or log in with email/password to continue.\n\n🆔 Telegram ID: <code>{user_id}</code>",
        "auth_register": "Register",
        "auth_login": "Log In",
        "auth_forgot": "Forgot Password",
        "auth_email_prompt": "📧 Send your email address.\nExample: <code>mail@example.com</code>",
        "auth_password_prompt": "🔑 Send your password.\nUse at least 6 characters.",
        "auth_new_password_prompt": "🔄 Send your new password.\nThis only resets the account linked to this Telegram account.",
        "auth_registered_ok": "✅ Registration completed. You are logged in.",
        "auth_login_ok": "✅ Login successful.",
        "auth_reset_ok": "✅ Password reset. You are logged in.",
        "auth_no_account": "No account is linked to this Telegram account. Register first.",
        "auth_bad_email": "Invalid email format. Example: <code>mail@example.com</code>",
        "auth_email_used": "This email is already registered to another Telegram account.",
        "auth_bad_password": "Password must be at least 6 characters.",
        "auth_login_failed": "Email or password is incorrect.",
        "auth_required": "You must log in to continue.",
        "auth_cancel": "Back to login screen",
        "blocked_logout": "Session is closed. Send /start to continue.",
        "main_menu": "🏠 Main Menu",
        "buy_key": "Buy Key",
        "categories": "Categories",
        "products": "Products",
        "prices": "Prices",
        "my_keys": "Key History",
        "tx_history": "Transaction History",
        "balance": "Balance",
        "layout": "PC / Mobile",
        "language": "Language",
        "logout": "Logout",
        "admin_panel": "Admin Panel",
        "back": "Back",
        "home": "Main Menu",
        "no_categories": "No active categories yet.",
        "select_category": "📦 Select a category:",
        "select_product": "🛒 Select a product:\nCategory: <b>{category}</b>",
        "no_products": "No active products in this category.",
        "product_card": "🎮 <b>Purchase Details</b>\n\n🛒 Package: <b>{name}</b>\n💵 Price: <b>${price:.2f}</b>\n⏳ Duration: <b>{days} days</b>\n📦 Stock: <b>{stock}</b>\n\n✅ After purchase, the key is delivered automatically. Long press the key to copy it.",
        "category_detail": "🎮 <b>{category}</b>\n\n🛒 <b>Products</b>\n\n<b>Packages:</b>\n{packages}",
        "package_daily": "Daily",
        "package_weekly": "Weekly",
        "package_monthly": "Monthly",
        "package_custom": "{days} Days",
        "no_packages": "No packages yet.",
        "confirm_buy": "Buy",
        "insufficient": "Insufficient balance. Required: ${price:.2f}, current: ${balance:.2f}",
        "sold_out": "This product is out of stock.",
        "purchase_ok": "✅ Purchase successful!\n\nProduct: <b>{product}</b>\nKey: <code>{key}</code>\nExpires: <b>{expires}</b>\n\nLong press the key to copy it.",
        "copy_key": "Show / Copy Key",
        "key_info": "🔑 <b>Key Info</b>\n\nProduct: <b>{product}</b>\nKey: <code>{key}</code>\nStatus: <b>{status}</b>\nExpires: <b>{expires}</b>\nReset: <b>{reset_count}/{max_resets}</b>",
        "reset_key": "Reset Key",
        "reset_ok": "✅ Key reset completed.\nKey: <code>{key}</code>\nReset: {reset_count}/{max_resets}",
        "reset_limit": "Reset limit is over for this key.",
        "reset_request_sent": "✅ Your key reset request was sent to admin. You will get a message after approval.",
        "reset_request_pending": "⏳ You already have a pending reset request for this key. Wait for admin approval.",
        "reset_admin_request": "🔄 <b>Key Reset Request</b>\n\nRequest ID: <code>{request_id}</code>\nUser: <code>{user_id}</code>\nEmail: <code>{email}</code>\nProduct: <b>{product}</b>\nKey: <code>{key}</code>\nReset: <b>{reset_count}/{max_resets}</b>\nDate: <b>{date}</b>",
        "reset_approve": "Approve",
        "reset_reject": "Reject",
        "reset_request_approved_admin": "✅ Reset request approved. User was notified.\nRequest ID: <code>{request_id}</code>",
        "reset_request_rejected_admin": "❌ Reset request rejected. User was notified.\nRequest ID: <code>{request_id}</code>",
        "reset_user_approved": "✅ Key has been reset.\nKey: <code>{key}</code>\nReset: <b>{reset_count}/{max_resets}</b>",
        "reset_user_rejected": "❌ Your key reset request was rejected by admin.",
        "reset_request_not_found": "No pending reset request found.",
        "reset_requests": "Reset Requests",
        "reset_requests_empty": "No pending reset requests.",
        "reset_requests_title": "🔄 <b>Pending Key Reset Requests</b>",
        "reset_request_line": "#{request_id} | User: <code>{user_id}</code> | Product: <b>{product}</b> | {date}",
        "no_keys": "You have not purchased any keys yet.",
        "history_empty": "Transaction history is empty.",
        "tx_line": "#{id} | {type} | ${amount:.2f} | {date}\n{note}",
        "balance_card": "💰 <b>Balance</b>\n\nCurrent balance: <b>${balance:.2f}</b>",
        "layout_card": "🖥 <b>Layout</b>\n\nCurrent: <b>{layout}</b>\nMobile uses one column; PC uses wider button layout.",
        "mobile": "Mobile",
        "pc": "PC",
        "layout_set": "Layout updated: {layout}",
        "lang_card": "🌐 Select language:",
        "lang_set": "Language updated: English",
        "logged_out": "Logged out. Send /start to log in again.",
        "admin_only": "This area is admin only.",
        "admin_title": "🛡 <b>JERRY Admin Panel</b>\n\n👥 Users: <b>{users}</b>\n📦 Categories: <b>{categories}</b>\n🛒 Products: <b>{products}</b>\n🔑 Stock Keys: <b>{stock_keys}</b>\n✅ Sold Keys: <b>{sold_keys}</b>",
        "admin_resellers": "Reseller Management",
        "admin_prices": "Custom Prices",
        "admin_keys": "Key/Stock Management",
        "admin_cats": "Category Management",
        "admin_products": "Product Management",
        "admin_balance": "Add Balance",
        "admin_history": "Product History",
        "admin_users": "Users",
        "create_reseller": "Create Reseller",
        "list_resellers": "List Resellers",
        "prompt_reseller": "Send in this format:\n<code>telegram_id | role | parent_id</code>\n\nRole: distributor / seller / sub_seller\nparent_id can be empty.\nExample: <code>123456 | seller | 8587288454</code>",
        "reseller_ok": "✅ Reseller saved.\nID: <code>{user_id}</code>\nRole: <b>{role}</b>\nParent: <code>{parent}</code>",
        "reseller_list_empty": "No resellers found.",
        "set_custom_price": "Set Custom Price",
        "list_custom_prices": "List Custom Prices",
        "prompt_price": "Send in this format:\n<code>scope | value | product_id | price</code>\n\nscope: user or role\nrole values: distributor / seller / sub_seller\nExample: <code>role | seller | 2 | 14.99</code>\nExample: <code>user | 123456 | 2 | 9.50</code>",
        "price_ok": "✅ Custom price saved.\n{scope}: <code>{value}</code>\nProduct ID: <code>{product_id}</code>\nPrice: <b>${price:.2f}</b>",
        "manual_key": "Add Single Key",
        "bulk_keys": "Add Bulk Keys",
        "decrease_stock": "Decrease Stock",
        "prompt_single_key": "Send in this format:\n<code>product_id | ENTER KEY</code>\n\nExample: <code>2 | JERRY-KEY-123</code>",
        "prompt_bulk_keys": "First line product_id, next lines keys:\n<code>2\nKEY-1\nKEY-2\nKEY-3</code>",
        "prompt_decrease": "Send in this format:\n<code>product_id | qty | reason</code>",
        "key_add_ok": "✅ {count} keys added to stock. Skipped/duplicate: {skipped}",
        "stock_dec_ok": "✅ {count} keys manually removed from stock.",
        "add_category": "Add Category",
        "delete_category": "Delete Category",
        "prompt_cat_add": "Send the category name.\nExample: <code>iOS</code>\n\nOptional: <code>iOS | description</code>",
        "prompt_cat_del": "Send category ID to delete:",
        "cat_ok": "✅ Category saved. ID: <code>{id}</code>",
        "cat_deleted": "✅ Category disabled.",
        "add_product": "Add Product",
        "delete_product": "Delete Product",
        "list_products": "List Products",
        "prompt_prod_add": "📦 Select the platform first. The bot will ask the cheat/product name, package duration, and price step by step.",
        "prod_wizard_select_cat": "📦 <b>Add Product</b>\n\n1/4 - Which platform should this product use?",
        "prod_wizard_no_cat": "You need to add an active category first.",
        "prod_wizard_name": "🛒 <b>Add Product</b>\n\n2/4 - Send the cheat/product name.\nExample: <code>King</code>",
        "prod_wizard_period": "⏳ <b>Add Product</b>\n\n3/4 - Select the package duration.\n\nChoose daily, weekly, monthly, or enter a custom day count.",
        "prod_wizard_price": "💵 <b>Add Product</b>\n\n4/4 - Select or send the package price.\n\nYou can press a quick price button or send a custom price.\nExample: <code>14.99</code>",
        "prod_wizard_custom_days": "✍️ <b>Custom Duration</b>\n\nSend how many days the key should be valid.\nExample: <code>45</code>",
        "prod_wizard_desc": "📝 <b>Add Product</b>\n\nDescription step removed. The product will be saved without description.",
        "prod_wizard_daily": "Daily - 1 Day",
        "prod_wizard_weekly": "Weekly - 7 Days",
        "prod_wizard_monthly": "Monthly - 30 Days",
        "prod_wizard_custom_period": "Enter Custom Duration",
        "prod_wizard_custom_price": "Enter Custom Price",
        "prod_wizard_skip_price": "Skip Price ($0)",
        "prod_wizard_skip_days": "Skip Duration (30 Days)",
        "prod_wizard_skip_desc": "No Description",
        "prod_wizard_confirm": "✅ <b>Confirm Product</b>\n\n📦 Platform: <b>{category}</b>\n🎯 Cheat/Product: <b>{name}</b>\n📅 Package: <b>{package}</b>\n💵 Price: <b>${price:.2f}</b>\n⏳ Duration: <b>{days} days</b>",
        "prod_wizard_save": "Save",
        "prod_wizard_edit": "Start Over",
        "prompt_prod_del": "Send product ID to delete:",
        "prod_ok": "✅ Product saved. ID: <code>{id}</code>",
        "prod_deleted": "✅ Product deleted and hidden from the list.",
        "prompt_balance": "Send in this format:\n<code>telegram_id | amount | note</code>\nExample: <code>123456 | 25 | Bank transfer</code>",
        "balance_ok": "✅ Balance updated.\nUser: <code>{user_id}</code>\nNew balance: <b>${balance:.2f}</b>",
        "bad_format": "Bad format. Send again using the example.",
        "not_found": "Record not found.",
        "cancel": "Cancel",
        "cancelled": "Cancelled.",
        "unknown": "Not understood. Send /start and continue from the menu.",
        "seeded": "Demo category/product added.",
        "seed_demo": "Add Demo Data",
        "id_card": "🆔 Telegram ID: <code>{user_id}</code>",
        "admin_help": "Admin quick commands:\n/admin - panel\n/id - your ID\n/start - user panel",
    },
    "uz": {
        "start_title": "✨ <b>JERRY Diler Paneli</b>",
        "start_body": "Telegram ID avtomatik aniqlandi va tizimga kirdingiz.\n\n🆔 ID: <code>{user_id}</code>\n👤 Rol: <b>{role}</b>\n💰 Balans: <b>${balance:.2f}</b>\n🖥 Ko‘rinish: <b>{layout}</b>",

        "auth_title": "🔐 <b>JERRY Hisobga Kirish</b>",
        "auth_body": "Davom etish uchun ro'yxatdan o'ting yoki email/parol bilan kiring.\n\n🆔 Telegram ID: <code>{user_id}</code>",
        "auth_register": "Ro'yxatdan o'tish",
        "auth_login": "Kirish",
        "auth_forgot": "Parolni unutdim",
        "auth_email_prompt": "📧 Email manzilingizni yuboring.\nMisol: <code>mail@example.com</code>",
        "auth_password_prompt": "🔑 Parolingizni yuboring.\nKamida 6 belgi bo'lsin.",
        "auth_new_password_prompt": "🔄 Yangi parolni yuboring.\nBu faqat ushbu Telegram hisobiga bog'langan hisob uchun ishlaydi.",
        "auth_registered_ok": "✅ Ro'yxatdan o'tish tugadi. Kirildi.",
        "auth_login_ok": "✅ Kirish muvaffaqiyatli.",
        "auth_reset_ok": "✅ Parol tiklandi. Kirildi.",
        "auth_no_account": "Bu Telegram hisobiga bog'langan hisob yo'q. Avval ro'yxatdan o'ting.",
        "auth_bad_email": "Email formati noto'g'ri. Misol: <code>mail@example.com</code>",
        "auth_email_used": "Bu email boshqa Telegram hisobida ro'yxatdan o'tgan.",
        "auth_bad_password": "Parol kamida 6 belgi bo'lishi kerak.",
        "auth_login_failed": "Email yoki parol noto'g'ri.",
        "auth_required": "Davom etish uchun kirishingiz kerak.",
        "auth_cancel": "Kirish ekraniga qaytish",
        "blocked_logout": "Sessiya yopiq. Davom etish uchun /start yuboring.",
        "main_menu": "🏠 Bosh menyu",
        "buy_key": "Key sotib olish",
        "categories": "Kategoriyalar",
        "products": "Mahsulotlar",
        "prices": "Narxlar",
        "my_keys": "Key tarixi",
        "tx_history": "Tranzaksiya tarixi",
        "balance": "Balans",
        "layout": "PC / Mobil",
        "language": "Til",
        "logout": "Chiqish",
        "admin_panel": "Admin Panel",
        "back": "Orqaga",
        "home": "Bosh menyu",
        "no_categories": "Hali faol kategoriya yo‘q.",
        "select_category": "📦 Kategoriyani tanlang:",
        "select_product": "🛒 Mahsulotni tanlang:\nKategoriya: <b>{category}</b>",
        "no_products": "Bu kategoriyada faol mahsulot yo‘q.",
        "product_card": "🎮 <b>Xarid tafsiloti</b>\n\n🛒 Paket: <b>{name}</b>\n💵 Narx: <b>${price:.2f}</b>\n⏳ Muddat: <b>{days} kun</b>\n📦 Stok: <b>{stock}</b>\n\n✅ Xariddan keyin key avtomatik beriladi. Nusxalash uchun key ustiga bosib turing.",
        "category_detail": "🎮 <b>{category}</b>\n\n🛒 <b>Mahsulotlar</b>\n\n<b>Paketlar:</b>\n{packages}",
        "package_daily": "Kunlik",
        "package_weekly": "Haftalik",
        "package_monthly": "Oylik",
        "package_custom": "{days} kunlik",
        "no_packages": "Hali paket yo‘q.",
        "confirm_buy": "Sotib olish",
        "insufficient": "Balans yetarli emas. Kerak: ${price:.2f}, mavjud: ${balance:.2f}",
        "sold_out": "Bu mahsulotda stok yo‘q.",
        "purchase_ok": "✅ Xarid muvaffaqiyatli!\n\nMahsulot: <b>{product}</b>\nKey: <code>{key}</code>\nTugash: <b>{expires}</b>\n\nNusxalash uchun key ustiga bosib turing.",
        "copy_key": "Key ko‘rsatish / nusxalash",
        "key_info": "🔑 <b>Key ma’lumoti</b>\n\nMahsulot: <b>{product}</b>\nKey: <code>{key}</code>\nHolat: <b>{status}</b>\nTugash: <b>{expires}</b>\nReset: <b>{reset_count}/{max_resets}</b>",
        "reset_key": "Key reset",
        "reset_ok": "✅ Key reset qilindi.\nKey: <code>{key}</code>\nReset: {reset_count}/{max_resets}",
        "reset_limit": "Bu key uchun reset limiti tugagan.",
        "reset_request_sent": "✅ Key reset so‘rovingiz adminga yuborildi. Tasdiqlansa sizga xabar keladi.",
        "reset_request_pending": "⏳ Bu key uchun kutayotgan reset so‘rovingiz bor. Admin tasdiqlashini kuting.",
        "reset_admin_request": "🔄 <b>Key Reset So‘rovi</b>\n\nSo‘rov ID: <code>{request_id}</code>\nFoydalanuvchi: <code>{user_id}</code>\nEmail: <code>{email}</code>\nMahsulot: <b>{product}</b>\nKey: <code>{key}</code>\nReset: <b>{reset_count}/{max_resets}</b>\nSana: <b>{date}</b>",
        "reset_approve": "Tasdiqlash",
        "reset_reject": "Rad etish",
        "reset_request_approved_admin": "✅ Reset so‘rovi tasdiqlandi. Foydalanuvchiga xabar yuborildi.\nSo‘rov ID: <code>{request_id}</code>",
        "reset_request_rejected_admin": "❌ Reset so‘rovi rad etildi. Foydalanuvchiga xabar yuborildi.\nSo‘rov ID: <code>{request_id}</code>",
        "reset_user_approved": "✅ Key reset qilindi.\nKey: <code>{key}</code>\nReset: <b>{reset_count}/{max_resets}</b>",
        "reset_user_rejected": "❌ Key reset so‘rovingiz admin tomonidan rad etildi.",
        "reset_request_not_found": "Kutilayotgan reset so‘rovi topilmadi.",
        "reset_requests": "Reset so‘rovlari",
        "reset_requests_empty": "Kutilayotgan reset so‘rovi yo‘q.",
        "reset_requests_title": "🔄 <b>Kutilayotgan Key Reset So‘rovlari</b>",
        "reset_request_line": "#{request_id} | Foydalanuvchi: <code>{user_id}</code> | Mahsulot: <b>{product}</b> | {date}",
        "no_keys": "Hali key sotib olmadingiz.",
        "history_empty": "Tranzaksiya tarixi bo‘sh.",
        "tx_line": "#{id} | {type} | ${amount:.2f} | {date}\n{note}",
        "balance_card": "💰 <b>Balans</b>\n\nJoriy balans: <b>${balance:.2f}</b>",
        "layout_card": "🖥 <b>Ko‘rinish</b>\n\nJoriy: <b>{layout}</b>\nMobil bir ustun, PC kengroq tugmalar tartibini ishlatadi.",
        "mobile": "Mobil",
        "pc": "PC",
        "layout_set": "Ko‘rinish yangilandi: {layout}",
        "lang_card": "🌐 Tilni tanlang:",
        "lang_set": "Til yangilandi: O‘zbekcha",
        "logged_out": "Chiqildi. Qayta kirish uchun /start yuboring.",
        "admin_only": "Bu bo‘lim faqat admin uchun.",
        "admin_title": "🛡 <b>JERRY Admin Panel</b>\n\n👥 Foydalanuvchi: <b>{users}</b>\n📦 Kategoriya: <b>{categories}</b>\n🛒 Mahsulot: <b>{products}</b>\n🔑 Stok key: <b>{stock_keys}</b>\n✅ Sotilgan key: <b>{sold_keys}</b>",
        "admin_resellers": "Sub-sotuvchi boshqaruvi",
        "admin_prices": "Maxsus narxlar",
        "admin_keys": "Key/Stok boshqaruvi",
        "admin_cats": "Kategoriya boshqaruvi",
        "admin_products": "Mahsulot boshqaruvi",
        "admin_balance": "Balans qo‘shish",
        "admin_history": "Mahsulot tarixi",
        "admin_users": "Foydalanuvchilar",
        "create_reseller": "Sub-sotuvchi yaratish",
        "list_resellers": "Sotuvchilar ro‘yxati",
        "prompt_reseller": "Shu formatda yuboring:\n<code>telegram_id | rol | parent_id</code>\n\nRol: distributor / seller / sub_seller\nparent_id bo‘sh bo‘lishi mumkin.\nMisol: <code>123456 | seller | 8587288454</code>",
        "reseller_ok": "✅ Diler saqlandi.\nID: <code>{user_id}</code>\nRol: <b>{role}</b>\nParent: <code>{parent}</code>",
        "reseller_list_empty": "Diler topilmadi.",
        "set_custom_price": "Maxsus narx belgilash",
        "list_custom_prices": "Maxsus narxlar ro‘yxati",
        "prompt_price": "Shu formatda yuboring:\n<code>scope | qiymat | product_id | narx</code>\n\nscope: user yoki role\nrole qiymatlari: distributor / seller / sub_seller\nMisol: <code>role | seller | 2 | 14.99</code>\nMisol: <code>user | 123456 | 2 | 9.50</code>",
        "price_ok": "✅ Maxsus narx saqlandi.\n{scope}: <code>{value}</code>\nMahsulot ID: <code>{product_id}</code>\nNarx: <b>${price:.2f}</b>",
        "manual_key": "Bitta key qo‘shish",
        "bulk_keys": "Ko‘p key qo‘shish",
        "decrease_stock": "Stok kamaytirish",
        "prompt_single_key": "Shu formatda yuboring:\n<code>product_id | KEY KIRITING</code>\n\nMisol: <code>2 | JERRY-KEY-123</code>",
        "prompt_bulk_keys": "Birinchi satr product_id, keyingi satrlar key:\n<code>2\nKEY-1\nKEY-2\nKEY-3</code>",
        "prompt_decrease": "Shu formatda yuboring:\n<code>product_id | soni | sabab</code>",
        "key_add_ok": "✅ Stokka {count} key qo‘shildi. O‘tkazilgan/takror: {skipped}",
        "stock_dec_ok": "✅ Stokdan {count} key qo‘lda tushirildi.",
        "add_category": "Kategoriya qo‘shish",
        "delete_category": "Kategoriya o‘chirish",
        "prompt_cat_add": "Kategoriya nomini yuboring.\nMisol: <code>iOS</code>\n\nIxtiyoriy: <code>iOS | tavsif</code>",
        "prompt_cat_del": "O‘chiriladigan kategoriya ID yuboring:",
        "cat_ok": "✅ Kategoriya saqlandi. ID: <code>{id}</code>",
        "cat_deleted": "✅ Kategoriya o‘chirildi/faolsizlandi.",
        "add_product": "Mahsulot qo‘shish",
        "delete_product": "Mahsulot o‘chirish",
        "list_products": "Mahsulotlar ro‘yxati",
        "prompt_prod_add": "📦 Avval platformani tanlang. Bot cheat/mahsulot nomi, paket muddati va narxni bosqichma-bosqich so‘raydi.",
        "prod_wizard_select_cat": "📦 <b>Mahsulot qo‘shish</b>\n\n1/4 - Mahsulot qaysi platformaga qo‘shilsin?",
        "prod_wizard_no_cat": "Avval faol kategoriya qo‘shishingiz kerak.",
        "prod_wizard_name": "🛒 <b>Mahsulot qo‘shish</b>\n\n2/4 - Cheat/mahsulot nomini yuboring.\nMisol: <code>King</code>",
        "prod_wizard_period": "⏳ <b>Mahsulot qo‘shish</b>\n\n3/4 - Paket muddatini tanlang.\n\nKunlik, haftalik, oylik yoki maxsus kun sonini tanlashingiz mumkin.",
        "prod_wizard_price": "💵 <b>Mahsulot qo‘shish</b>\n\n4/4 - Paket narxini tanlang yoki yuboring.\n\nTayyor narx tugmasini bosishingiz yoki maxsus narx yuborishingiz mumkin.\nMisol: <code>14.99</code>",
        "prod_wizard_custom_days": "✍️ <b>Maxsus muddat</b>\n\nKey necha kun amal qilishini yuboring.\nMisol: <code>45</code>",
        "prod_wizard_desc": "📝 <b>Mahsulot qo‘shish</b>\n\nTavsif bosqichi olib tashlandi. Mahsulot tavsifsiz saqlanadi.",
        "prod_wizard_daily": "Kunlik - 1 kun",
        "prod_wizard_weekly": "Haftalik - 7 kun",
        "prod_wizard_monthly": "Oylik - 30 kun",
        "prod_wizard_custom_period": "Maxsus muddat yozish",
        "prod_wizard_custom_price": "Maxsus narx yozish",
        "prod_wizard_skip_price": "Narxni o‘tkazish ($0)",
        "prod_wizard_skip_days": "Muddatni o‘tkazish (30 kun)",
        "prod_wizard_skip_desc": "Tavsif yo‘q",
        "prod_wizard_confirm": "✅ <b>Mahsulotni tasdiqlang</b>\n\n📦 Platforma: <b>{category}</b>\n🎯 Cheat/Mahsulot: <b>{name}</b>\n📅 Paket: <b>{package}</b>\n💵 Narx: <b>${price:.2f}</b>\n⏳ Muddat: <b>{days} kun</b>",
        "prod_wizard_save": "Saqlash",
        "prod_wizard_edit": "Boshidan",
        "prompt_prod_del": "O‘chiriladigan mahsulot ID yuboring:",
        "prod_ok": "✅ Mahsulot saqlandi. ID: <code>{id}</code>",
        "prod_deleted": "✅ Mahsulot o‘chirildi va ro‘yxatdan olib tashlandi.",
        "prompt_balance": "Shu formatda yuboring:\n<code>telegram_id | miqdor | izoh</code>\nMisol: <code>123456 | 25 | To‘lov</code>",
        "balance_ok": "✅ Balans yangilandi.\nFoydalanuvchi: <code>{user_id}</code>\nYangi balans: <b>${balance:.2f}</b>",
        "bad_format": "Format xato. Misol bo‘yicha qayta yuboring.",
        "not_found": "Ma’lumot topilmadi.",
        "cancel": "Bekor qilish",
        "cancelled": "Bekor qilindi.",
        "unknown": "Tushunilmadi. /start yuborib menyudan davom eting.",
        "seeded": "Demo kategoriya/mahsulot qo‘shildi.",
        "seed_demo": "Demo ma’lumot qo‘shish",
        "id_card": "🆔 Telegram ID: <code>{user_id}</code>",
        "admin_help": "Admin tezkor komandalar:\n/admin - panel\n/id - ID\n/start - foydalanuvchi paneli",
    },
    "ru": {
        "start_title": "✨ <b>Панель дилера JERRY</b>",
        "start_body": "Ваш Telegram ID определён автоматически, вход выполнен.\n\n🆔 ID: <code>{user_id}</code>\n👤 Роль: <b>{role}</b>\n💰 Баланс: <b>${balance:.2f}</b>\n🖥 Вид: <b>{layout}</b>",

        "auth_title": "🔐 <b>Вход в аккаунт JERRY</b>",
        "auth_body": "Зарегистрируйтесь или войдите по email/паролю, чтобы продолжить.\n\n🆔 Telegram ID: <code>{user_id}</code>",
        "auth_register": "Регистрация",
        "auth_login": "Войти",
        "auth_forgot": "Забыли пароль",
        "auth_email_prompt": "📧 Отправьте email.\nПример: <code>mail@example.com</code>",
        "auth_password_prompt": "🔑 Отправьте пароль.\nМинимум 6 символов.",
        "auth_new_password_prompt": "🔄 Отправьте новый пароль.\nСброс доступен только для аккаунта, привязанного к этому Telegram.",
        "auth_registered_ok": "✅ Регистрация завершена. Вы вошли.",
        "auth_login_ok": "✅ Вход выполнен.",
        "auth_reset_ok": "✅ Пароль сброшен. Вы вошли.",
        "auth_no_account": "К этому Telegram не привязан аккаунт. Сначала зарегистрируйтесь.",
        "auth_bad_email": "Неверный формат email. Пример: <code>mail@example.com</code>",
        "auth_email_used": "Этот email уже зарегистрирован на другой Telegram аккаунт.",
        "auth_bad_password": "Пароль должен быть минимум 6 символов.",
        "auth_login_failed": "Email или пароль неверный.",
        "auth_required": "Чтобы продолжить, войдите в аккаунт.",
        "auth_cancel": "Назад к экрану входа",
        "blocked_logout": "Сессия закрыта. Отправьте /start для продолжения.",
        "main_menu": "🏠 Главное меню",
        "buy_key": "Купить ключ",
        "categories": "Категории",
        "products": "Товары",
        "prices": "Цены",
        "my_keys": "История ключей",
        "tx_history": "История операций",
        "balance": "Баланс",
        "layout": "PC / Mobile",
        "language": "Язык",
        "logout": "Выйти",
        "admin_panel": "Админ-панель",
        "back": "Назад",
        "home": "Главное меню",
        "no_categories": "Активных категорий пока нет.",
        "select_category": "📦 Выберите категорию:",
        "select_product": "🛒 Выберите товар:\nКатегория: <b>{category}</b>",
        "no_products": "В этой категории нет активных товаров.",
        "product_card": "🎮 <b>Детали покупки</b>\n\n🛒 Пакет: <b>{name}</b>\n💵 Цена: <b>${price:.2f}</b>\n⏳ Срок: <b>{days} дней</b>\n📦 Остаток: <b>{stock}</b>\n\n✅ После покупки ключ выдается автоматически. Для копирования удерживайте ключ.",
        "category_detail": "🎮 <b>{category}</b>\n\n🛒 <b>Товары</b>\n\n<b>Пакеты:</b>\n{packages}",
        "package_daily": "Дневной",
        "package_weekly": "Недельный",
        "package_monthly": "Месячный",
        "package_custom": "{days} дней",
        "no_packages": "Пакетов пока нет.",
        "confirm_buy": "Купить",
        "insufficient": "Недостаточно баланса. Нужно: ${price:.2f}, сейчас: ${balance:.2f}",
        "sold_out": "Нет ключей в наличии.",
        "purchase_ok": "✅ Покупка успешна!\n\nТовар: <b>{product}</b>\nКлюч: <code>{key}</code>\nИстекает: <b>{expires}</b>\n\nДля копирования удерживайте ключ.",
        "copy_key": "Показать / копировать ключ",
        "key_info": "🔑 <b>Информация о ключе</b>\n\nТовар: <b>{product}</b>\nКлюч: <code>{key}</code>\nСтатус: <b>{status}</b>\nИстекает: <b>{expires}</b>\nСброс: <b>{reset_count}/{max_resets}</b>",
        "reset_key": "Сбросить ключ",
        "reset_ok": "✅ Ключ сброшен.\nКлюч: <code>{key}</code>\nСброс: {reset_count}/{max_resets}",
        "reset_limit": "Лимит сброса для этого ключа закончился.",
        "reset_request_sent": "✅ Запрос на сброс ключа отправлен админу. После подтверждения придёт сообщение.",
        "reset_request_pending": "⏳ Для этого ключа уже есть ожидающий запрос. Ждите подтверждения админа.",
        "reset_admin_request": "🔄 <b>Запрос сброса ключа</b>\n\nID запроса: <code>{request_id}</code>\nПользователь: <code>{user_id}</code>\nEmail: <code>{email}</code>\nТовар: <b>{product}</b>\nКлюч: <code>{key}</code>\nСброс: <b>{reset_count}/{max_resets}</b>\nДата: <b>{date}</b>",
        "reset_approve": "Одобрить",
        "reset_reject": "Отклонить",
        "reset_request_approved_admin": "✅ Запрос сброса одобрен. Пользователю отправлено сообщение.\nID запроса: <code>{request_id}</code>",
        "reset_request_rejected_admin": "❌ Запрос сброса отклонён. Пользователю отправлено сообщение.\nID запроса: <code>{request_id}</code>",
        "reset_user_approved": "✅ Ключ сброшен.\nКлюч: <code>{key}</code>\nСброс: <b>{reset_count}/{max_resets}</b>",
        "reset_user_rejected": "❌ Ваш запрос на сброс ключа отклонён админом.",
        "reset_request_not_found": "Ожидающий запрос сброса не найден.",
        "reset_requests": "Запросы сброса",
        "reset_requests_empty": "Нет ожидающих запросов сброса.",
        "reset_requests_title": "🔄 <b>Ожидающие запросы сброса ключей</b>",
        "reset_request_line": "#{request_id} | Пользователь: <code>{user_id}</code> | Товар: <b>{product}</b> | {date}",
        "no_keys": "Вы ещё не покупали ключи.",
        "history_empty": "История операций пуста.",
        "tx_line": "#{id} | {type} | ${amount:.2f} | {date}\n{note}",
        "balance_card": "💰 <b>Баланс</b>\n\nТекущий баланс: <b>${balance:.2f}</b>",
        "layout_card": "🖥 <b>Вид</b>\n\nТекущий: <b>{layout}</b>\nMobile использует один столбец, PC — более широкую раскладку кнопок.",
        "mobile": "Mobile",
        "pc": "PC",
        "layout_set": "Вид обновлён: {layout}",
        "lang_card": "🌐 Выберите язык:",
        "lang_set": "Язык обновлён: Русский",
        "logged_out": "Вы вышли. Отправьте /start для нового входа.",
        "admin_only": "Этот раздел только для администратора.",
        "admin_title": "🛡 <b>Админ-панель JERRY</b>\n\n👥 Пользователи: <b>{users}</b>\n📦 Категории: <b>{categories}</b>\n🛒 Товары: <b>{products}</b>\n🔑 Ключи в наличии: <b>{stock_keys}</b>\n✅ Продано ключей: <b>{sold_keys}</b>",
        "admin_resellers": "Управление продавцами",
        "admin_prices": "Индивидуальные цены",
        "admin_keys": "Управление ключами/складом",
        "admin_cats": "Управление категориями",
        "admin_products": "Управление товарами",
        "admin_balance": "Добавить баланс",
        "admin_history": "История товара",
        "admin_users": "Пользователи",
        "create_reseller": "Создать продавца",
        "list_resellers": "Список продавцов",
        "prompt_reseller": "Отправьте в формате:\n<code>telegram_id | role | parent_id</code>\n\nRole: distributor / seller / sub_seller\nparent_id можно оставить пустым.\nПример: <code>123456 | seller | 8587288454</code>",
        "reseller_ok": "✅ Продавец сохранён.\nID: <code>{user_id}</code>\nРоль: <b>{role}</b>\nParent: <code>{parent}</code>",
        "reseller_list_empty": "Продавцы не найдены.",
        "set_custom_price": "Установить цену",
        "list_custom_prices": "Список цен",
        "prompt_price": "Отправьте в формате:\n<code>scope | value | product_id | price</code>\n\nscope: user или role\nrole: distributor / seller / sub_seller\nПример: <code>role | seller | 2 | 14.99</code>\nПример: <code>user | 123456 | 2 | 9.50</code>",
        "price_ok": "✅ Цена сохранена.\n{scope}: <code>{value}</code>\nID товара: <code>{product_id}</code>\nЦена: <b>${price:.2f}</b>",
        "manual_key": "Добавить один ключ",
        "bulk_keys": "Добавить ключи массово",
        "decrease_stock": "Уменьшить склад",
        "prompt_single_key": "Отправьте в формате:\n<code>product_id | ВВЕДИТЕ KEY</code>\n\nПример: <code>2 | JERRY-KEY-123</code>",
        "prompt_bulk_keys": "Первая строка product_id, следующие строки ключи:\n<code>2\nKEY-1\nKEY-2\nKEY-3</code>",
        "prompt_decrease": "Отправьте в формате:\n<code>product_id | qty | reason</code>",
        "key_add_ok": "✅ Добавлено ключей: {count}. Пропущено/дубликат: {skipped}",
        "stock_dec_ok": "✅ Вручную списано ключей: {count}.",
        "add_category": "Добавить категорию",
        "delete_category": "Удалить категорию",
        "prompt_cat_add": "Отправьте название категории.\nПример: <code>iOS</code>\n\nДополнительно: <code>iOS | описание</code>",
        "prompt_cat_del": "Отправьте ID категории для удаления:",
        "cat_ok": "✅ Категория сохранена. ID: <code>{id}</code>",
        "cat_deleted": "✅ Категория отключена.",
        "add_product": "Добавить товар",
        "delete_product": "Удалить товар",
        "list_products": "Список товаров",
        "prompt_prod_add": "📦 Сначала выберите платформу. Затем бот спросит название чита/товара, срок пакета и цену.",
        "prod_wizard_select_cat": "📦 <b>Добавить товар</b>\n\n1/4 - В какую платформу добавить товар?",
        "prod_wizard_no_cat": "Сначала нужно добавить активную категорию.",
        "prod_wizard_name": "🛒 <b>Добавить товар</b>\n\n2/4 - Отправьте название чита/товара.\nПример: <code>King</code>",
        "prod_wizard_period": "⏳ <b>Добавить товар</b>\n\n3/4 - Выберите срок пакета.\n\nМожно выбрать дневной, недельный, месячный или ввести свой срок.",
        "prod_wizard_price": "💵 <b>Добавить товар</b>\n\n4/4 - Выберите или отправьте цену пакета.\n\nМожно нажать готовую цену или отправить свою.\nПример: <code>14.99</code>",
        "prod_wizard_custom_days": "✍️ <b>Свой срок</b>\n\nОтправьте, сколько дней должен действовать ключ.\nПример: <code>45</code>",
        "prod_wizard_desc": "📝 <b>Добавить товар</b>\n\nШаг описания удалён. Товар будет сохранён без описания.",
        "prod_wizard_daily": "Дневной - 1 день",
        "prod_wizard_weekly": "Недельный - 7 дней",
        "prod_wizard_monthly": "Месячный - 30 дней",
        "prod_wizard_custom_period": "Ввести свой срок",
        "prod_wizard_custom_price": "Ввести свою цену",
        "prod_wizard_skip_price": "Пропустить цену ($0)",
        "prod_wizard_skip_days": "Пропустить срок (30 дней)",
        "prod_wizard_skip_desc": "Без описания",
        "prod_wizard_confirm": "✅ <b>Подтвердите товар</b>\n\n📦 Платформа: <b>{category}</b>\n🎯 Чит/Товар: <b>{name}</b>\n📅 Пакет: <b>{package}</b>\n💵 Цена: <b>${price:.2f}</b>\n⏳ Срок: <b>{days} дней</b>",
        "prod_wizard_save": "Сохранить",
        "prod_wizard_edit": "Сначала",
        "prompt_prod_del": "Отправьте ID товара для удаления:",
        "prod_ok": "✅ Товар сохранён. ID: <code>{id}</code>",
        "prod_deleted": "✅ Товар удалён и скрыт из списка.",
        "prompt_balance": "Отправьте в формате:\n<code>telegram_id | amount | note</code>\nПример: <code>123456 | 25 | Перевод</code>",
        "balance_ok": "✅ Баланс обновлён.\nПользователь: <code>{user_id}</code>\nНовый баланс: <b>${balance:.2f}</b>",
        "bad_format": "Неверный формат. Отправьте по примеру.",
        "not_found": "Запись не найдена.",
        "cancel": "Отмена",
        "cancelled": "Отменено.",
        "unknown": "Не понял. Отправьте /start и продолжайте через меню.",
        "seeded": "Демо категория/товар добавлены.",
        "seed_demo": "Добавить демо",
        "id_card": "🆔 Telegram ID: <code>{user_id}</code>",
        "admin_help": "Быстрые команды админа:\n/admin - панель\n/id - ваш ID\n/start - пользовательская панель",
    },
}

# Yeni admin/onay/ban/yetki metinleri. Eksik dillerde Türkçe ana metin güvenli yedek olarak kullanılır.
EXTRA_TEXT: dict[str, dict[str, str]] = {
    "tr": {
        "auth_pending": "⏳ <b>Hesabın beklemede.</b>\n\nKayıt tamamlandı ama botu kullanmak için owner/admin onayı gerekiyor. Telegram ID: <code>{user_id}</code>",
        "banned_msg": "⛔ <b>Bu Telegram hesabı bottan tamamen banlandı.</b>\n\nTelegram ID: <code>{user_id}</code>\nKayıtlı üyelik silindi. Sadece owner unban yaparsa tekrar kayıt olabilir.",
        "permission_denied": "⛔ Bu işlem için yetkin yok.",
        "admin_users_menu": "👤 <b>Kullanıcı Yönetimi</b>\n\nMail ile kayıtlı kullanıcıyı bulabilir, rol/onay verebilir, yönetici yetkilerini düzenleyebilir ve Telegram ID ile ban/unban yapabilirsin.",
        "manage_user_by_email": "Mailden Kullanıcı Bul",
        "list_users": "Kullanıcı Listesi",
        "ban_unban": "Ban / Unban",
        "prompt_user_email": "📧 Yetkilendirmek istediğin kayıtlı kullanıcının mailini yaz.\n\nÖrnek: <code>mail@example.com</code>",
        "user_not_found_email": "Bu mail ile kayıtlı kullanıcı bulunamadı.",
        "user_detail": "👤 <b>Kullanıcı Detayı</b>\n\n🆔 Telegram ID: <code>{user_id}</code>\n📧 Mail: <code>{email}</code>\n👤 Rol: <b>{role}</b>\n✅ Kullanım Onayı: <b>{approved}</b>\n💰 Bakiye: <b>${balance:.2f}</b>\n🔐 Admin Yetkileri: <b>{perms}</b>",
        "approved_yes": "Onaylı",
        "approved_no": "Onaysız",
        "approve_user": "Kullanımı Aç",
        "unapprove_user": "Kullanımı Kapat",
        "set_customer": "Müşteri Yap",
        "set_sub_seller": "Alt-Satıcı Yap",
        "set_seller": "Satıcı Yap",
        "set_distributor": "Distribütör Yap",
        "set_admin": "Yönetici Yap",
        "edit_permissions": "Yönetici Yetkileri",
        "user_updated": "✅ Kullanıcı güncellendi.",
        "permissions_title": "🔐 <b>Yönetici Yetkileri</b>\n\nKullanıcı: <code>{user_id}</code>\nMail: <code>{email}</code>\n\nButona basınca yetki açılır/kapanır.",
        "perm_on": "Açık",
        "perm_off": "Kapalı",
        "prompt_ban_user": "⛔ Banlanacak Telegram ID yaz. İstersen sebep de ekle.\n\nÖrnek: <code>123456789 | spam</code>\n\nBan atınca kayıtlı üyeliği de silinir.",
        "prompt_unban_user": "✅ Unban yapılacak Telegram ID yaz.\n\nÖrnek: <code>123456789</code>",
        "ban_ok": "⛔ Ban tamamlandı. Telegram ID: <code>{user_id}</code>\nKayıtlı üyelik silindi.",
        "unban_ok": "✅ Unban tamamlandı. Telegram ID: <code>{user_id}</code> artık tekrar kayıt olabilir.",
        "ban_list": "Ban Listesi",
        "ban_list_empty": "Ban listesi boş.",
        "owner_protected": "Ana owner hesabında bu işlem yapılamaz.",
        "not_owner_for_admin": "Yönetici yapma ve yönetici yetkisi düzenleme sadece ana owner hesabında açık.",
    },
    "en": {
        "auth_pending": "⏳ <b>Your account is pending approval.</b>\n\nRegistration is complete, but an owner/admin must approve you before you can use the bot. Telegram ID: <code>{user_id}</code>",
        "banned_msg": "⛔ <b>This Telegram account is banned from the bot.</b>\n\nTelegram ID: <code>{user_id}</code>\nThe registered membership was deleted. Only the owner can unban it.",
        "permission_denied": "⛔ You do not have permission for this action.",
        "admin_users_menu": "👤 <b>User Management</b>",
        "manage_user_by_email": "Find User by Email",
        "list_users": "User List",
        "ban_unban": "Ban / Unban",
        "prompt_user_email": "📧 Send the registered user's email. Example: <code>mail@example.com</code>",
        "user_not_found_email": "No registered user found with this email.",
        "approved_yes": "Approved",
        "approved_no": "Pending",
        "approve_user": "Approve Use",
        "unapprove_user": "Disable Use",
        "set_customer": "Make Customer",
        "set_sub_seller": "Make Sub-seller",
        "set_seller": "Make Seller",
        "set_distributor": "Make Distributor",
        "set_admin": "Make Manager",
        "edit_permissions": "Manager Permissions",
        "user_updated": "✅ User updated.",
        "prompt_ban_user": "⛔ Send Telegram ID to ban. Example: <code>123456789 | reason</code>",
        "prompt_unban_user": "✅ Send Telegram ID to unban. Example: <code>123456789</code>",
        "ban_ok": "⛔ Banned. Telegram ID: <code>{user_id}</code>",
        "unban_ok": "✅ Unbanned. Telegram ID: <code>{user_id}</code>",
        "ban_list": "Ban List",
        "ban_list_empty": "Ban list is empty.",
        "owner_protected": "This action cannot be done on the owner account.",
        "not_owner_for_admin": "Only the owner can promote managers or edit manager permissions.",
    },
}
for _lang in SUPPORTED_LANGS:
    base = EXTRA_TEXT.get(_lang, EXTRA_TEXT["tr"])
    TEXT.setdefault(_lang, {}).update(base)

PLATFORM_TEXT: dict[str, dict[str, str]] = {
    "tr": {
        "select_platform": "🎮 <b>Key Satın Alma</b>\n\nHangi platform için key satın almak istiyorsun?",
        "platform_android": "Android",
        "platform_ios": "İOS",
        "platform_emulator_pc": "Emülatör / PC",
        "admin_platforms_title": "📦 <b>Platform Kategorileri</b>\n\nKeyler artık 3 ana kategoriye ayrıldı. Admin panelden her platforma ayrı ayrı ürün/paket ekleyebilirsin.",
        "platform_product_add": "Ürün Ekle",
        "platform_protected": "Bu ana platform kategorisi silinemez. Ürünleri silmek için Ürün Yönetimi bölümünü kullan.",
        "select_product_group": "{category}\n\nİçindeki hile/ürün adını seç:",
        "product_group_detail": "🎮 <b>{product}</b>\n\nPlatform: <b>{category}</b>\n\n<b>Paketler:</b>\n{packages}",
        "product_group_button_suffix": "{count} paket",
        "product_group_empty": "Bu hile/ürün için aktif paket yok.",
    },
    "en": {
        "select_platform": "🎮 <b>Buy Key</b>\n\nWhich platform do you want to buy a key for?",
        "platform_android": "Android",
        "platform_ios": "iOS",
        "platform_emulator_pc": "Emulator / PC",
        "admin_platforms_title": "📦 <b>Platform Categories</b>\n\nKeys are now split into 3 main categories. You can add products/packages separately for each platform.",
        "platform_product_add": "Add Product",
        "platform_protected": "This main platform category cannot be deleted. Use Product Management to remove products.",
        "select_product_group": "{category}\n\nSelect a cheat/product name inside this platform:",
        "product_group_detail": "🎮 <b>{product}</b>\n\nPlatform: <b>{category}</b>\n\n<b>Packages:</b>\n{packages}",
        "product_group_button_suffix": "{count} packages",
        "product_group_empty": "No active package exists for this cheat/product.",
    },
    "uz": {
        "select_platform": "🎮 <b>Key sotib olish</b>\n\nQaysi platforma uchun key olmoqchisiz?",
        "platform_android": "Android",
        "platform_ios": "iOS",
        "platform_emulator_pc": "Emulyator / PC",
        "admin_platforms_title": "📦 <b>Platforma kategoriyalari</b>\n\nKeylar 3 asosiy kategoriyaga ajratildi. Har platformaga alohida mahsulot/paket qo‘shishingiz mumkin.",
        "platform_product_add": "Mahsulot qo‘shish",
        "platform_protected": "Bu asosiy platforma kategoriyasini o‘chirib bo‘lmaydi. Mahsulotlarni o‘chirish uchun Mahsulot boshqaruvidan foydalaning.",
        "select_product_group": "{category}\n\nUshbu platformadagi cheat/mahsulot nomini tanlang:",
        "product_group_detail": "🎮 <b>{product}</b>\n\nPlatforma: <b>{category}</b>\n\n<b>Paketlar:</b>\n{packages}",
        "product_group_button_suffix": "{count} paket",
        "product_group_empty": "Bu cheat/mahsulot uchun faol paket yo‘q.",
    },
    "ru": {
        "select_platform": "🎮 <b>Купить ключ</b>\n\nДля какой платформы нужен ключ?",
        "platform_android": "Android",
        "platform_ios": "iOS",
        "platform_emulator_pc": "Эмулятор / PC",
        "admin_platforms_title": "📦 <b>Категории платформ</b>\n\nКлючи разделены на 3 основные категории. Можно добавлять товары/пакеты отдельно для каждой платформы.",
        "platform_product_add": "Добавить товар",
        "platform_protected": "Эту основную категорию платформы нельзя удалить. Для удаления товаров используйте управление товарами.",
        "select_product_group": "{category}\n\nВыберите название чита/товара внутри платформы:",
        "product_group_detail": "🎮 <b>{product}</b>\n\nПлатформа: <b>{category}</b>\n\n<b>Пакеты:</b>\n{packages}",
        "product_group_button_suffix": "{count} пакета",
        "product_group_empty": "Для этого чита/товара нет активных пакетов.",
    },
}
for _lang in SUPPORTED_LANGS:
    TEXT.setdefault(_lang, {}).update(PLATFORM_TEXT.get(_lang, PLATFORM_TEXT["tr"]))

PRODUCT_EDIT_TEXT: dict[str, dict[str, str]] = {
    "tr": {
        "edit_product": "Ürün Düzenle",
        "prod_wizard_continue": "Devam",
        "prod_wizard_period_no_selection": "⚠️ En az bir paket seçmelisin. Günlük / Haftalık / Aylık seçeneklerinden istediğini seç, sonra Devam’a bas.",
        "prod_wizard_price_each": "💵 <b>{package} Fiyatı</b>\n\n📦 Platform: <b>{category}</b>\n🎯 Ürün: <b>{name}</b>\n\nBu paket için fiyat seç veya yaz.\nÖrnek: <code>1</code>",
        "prod_wizard_confirm_multi": "✅ <b>Paketleri onayla</b>\n\n📦 Platform: <b>{category}</b>\n🎯 Ürün: <b>{name}</b>\n\n{packages}",
        "prod_wizard_package_line": "{emoji} <b>{package}</b> — <b>${price:.2f}</b> — <b>{days} gün</b>",
        "prod_multi_ok": "✅ Paketler kaydedildi/güncellendi. Ürün ID: <code>{ids}</code>",
        "prod_edit_select_platform": "✏️ <b>Ürün Düzenle</b>\n\nÖnce platform seç.",
        "prod_edit_select_group": "{category}\n\nDüzenlenecek hile/ürünü seç:",
        "prod_edit_empty": "Düzenlenecek aktif ürün yok.",
        "prod_edit_group_title": "✏️ <b>Ürün Düzenle</b>\n\n📦 Platform: <b>{category}</b>\n🎯 Ürün: <b>{name}</b>\n\nGünlük / haftalık / aylık paket eklemek veya fiyat düzenlemek için butona bas.",
        "prod_edit_package_add": "Ekle",
        "prod_edit_package_edit": "Düzenle",
        "prod_edit_price_prompt": "💵 <b>{package} Paket Fiyatı</b>\n\n🎯 Ürün: <b>{name}</b>\nMevcut fiyat: <b>{current}</b>\n\nYeni fiyatı yaz veya hazır butona bas.",
        "prod_edit_saved": "✅ Ürün paketi kaydedildi/güncellendi.",
        "prod_edit_disabled": "✅ Paket pasifleştirildi.",
        "prod_edit_disable_package": "Paketi Kapat",
    },
    "en": {
        "edit_product": "Edit Product",
        "prod_wizard_continue": "Continue",
        "prod_wizard_period_no_selection": "⚠️ Select at least one package. Choose Daily / Weekly / Monthly, then press Continue.",
        "prod_wizard_price_each": "💵 <b>{package} Price</b>\n\n📦 Platform: <b>{category}</b>\n🎯 Product: <b>{name}</b>\n\nSelect or send the price for this package.\nExample: <code>1</code>",
        "prod_wizard_confirm_multi": "✅ <b>Confirm packages</b>\n\n📦 Platform: <b>{category}</b>\n🎯 Product: <b>{name}</b>\n\n{packages}",
        "prod_wizard_package_line": "{emoji} <b>{package}</b> — <b>${price:.2f}</b> — <b>{days} days</b>",
        "prod_multi_ok": "✅ Packages saved/updated. Product IDs: <code>{ids}</code>",
        "prod_edit_select_platform": "✏️ <b>Edit Product</b>\n\nSelect the platform first.",
        "prod_edit_select_group": "{category}\n\nSelect the cheat/product to edit:",
        "prod_edit_empty": "No active product to edit.",
        "prod_edit_group_title": "✏️ <b>Edit Product</b>\n\n📦 Platform: <b>{category}</b>\n🎯 Product: <b>{name}</b>\n\nTap a package to add daily/weekly/monthly or edit its price.",
        "prod_edit_package_add": "Add",
        "prod_edit_package_edit": "Edit",
        "prod_edit_price_prompt": "💵 <b>{package} Package Price</b>\n\n🎯 Product: <b>{name}</b>\nCurrent price: <b>{current}</b>\n\nSend the new price or press a quick button.",
        "prod_edit_saved": "✅ Product package saved/updated.",
        "prod_edit_disabled": "✅ Package disabled.",
        "prod_edit_disable_package": "Disable Package",
    },
    "uz": {
        "edit_product": "Mahsulotni tahrirlash",
        "prod_wizard_continue": "Davom etish",
        "prod_wizard_period_no_selection": "⚠️ Kamida bitta paket tanlang. Kunlik / Haftalik / Oylik variantlardan keraklisini tanlab, Davom etish tugmasini bosing.",
        "prod_wizard_price_each": "💵 <b>{package} narxi</b>\n\n📦 Platforma: <b>{category}</b>\n🎯 Mahsulot: <b>{name}</b>\n\nBu paket uchun narx tanlang yoki yuboring.\nMisol: <code>1</code>",
        "prod_wizard_confirm_multi": "✅ <b>Paketlarni tasdiqlang</b>\n\n📦 Platforma: <b>{category}</b>\n🎯 Mahsulot: <b>{name}</b>\n\n{packages}",
        "prod_wizard_package_line": "{emoji} <b>{package}</b> — <b>${price:.2f}</b> — <b>{days} kun</b>",
        "prod_multi_ok": "✅ Paketlar saqlandi/yangilandi. Mahsulot ID: <code>{ids}</code>",
        "prod_edit_select_platform": "✏️ <b>Mahsulotni tahrirlash</b>\n\nAvval platformani tanlang.",
        "prod_edit_select_group": "{category}\n\nTahrirlanadigan cheat/mahsulotni tanlang:",
        "prod_edit_empty": "Tahrirlash uchun faol mahsulot yo‘q.",
        "prod_edit_group_title": "✏️ <b>Mahsulotni tahrirlash</b>\n\n📦 Platforma: <b>{category}</b>\n🎯 Mahsulot: <b>{name}</b>\n\nKunlik / haftalik / oylik paket qo‘shish yoki narxini tahrirlash uchun tugmani bosing.",
        "prod_edit_package_add": "Qo‘shish",
        "prod_edit_package_edit": "Tahrirlash",
        "prod_edit_price_prompt": "💵 <b>{package} paket narxi</b>\n\n🎯 Mahsulot: <b>{name}</b>\nJoriy narx: <b>{current}</b>\n\nYangi narxni yuboring yoki tayyor tugmani bosing.",
        "prod_edit_saved": "✅ Mahsulot paketi saqlandi/yangilandi.",
        "prod_edit_disabled": "✅ Paket faolsizlandi.",
        "prod_edit_disable_package": "Paketni yopish",
    },
    "ru": {
        "edit_product": "Редактировать товар",
        "prod_wizard_continue": "Продолжить",
        "prod_wizard_period_no_selection": "⚠️ Выберите минимум один пакет. Включите дневной / недельный / месячный и нажмите Продолжить.",
        "prod_wizard_price_each": "💵 <b>Цена пакета: {package}</b>\n\n📦 Платформа: <b>{category}</b>\n🎯 Товар: <b>{name}</b>\n\nВыберите или отправьте цену для этого пакета.\nПример: <code>1</code>",
        "prod_wizard_confirm_multi": "✅ <b>Подтвердите пакеты</b>\n\n📦 Платформа: <b>{category}</b>\n🎯 Товар: <b>{name}</b>\n\n{packages}",
        "prod_wizard_package_line": "{emoji} <b>{package}</b> — <b>${price:.2f}</b> — <b>{days} дней</b>",
        "prod_multi_ok": "✅ Пакеты сохранены/обновлены. ID товаров: <code>{ids}</code>",
        "prod_edit_select_platform": "✏️ <b>Редактировать товар</b>\n\nСначала выберите платформу.",
        "prod_edit_select_group": "{category}\n\nВыберите чит/товар для редактирования:",
        "prod_edit_empty": "Нет активного товара для редактирования.",
        "prod_edit_group_title": "✏️ <b>Редактировать товар</b>\n\n📦 Платформа: <b>{category}</b>\n🎯 Товар: <b>{name}</b>\n\nНажмите пакет, чтобы добавить дневной/недельный/месячный или изменить цену.",
        "prod_edit_package_add": "Добавить",
        "prod_edit_package_edit": "Изменить",
        "prod_edit_price_prompt": "💵 <b>Цена пакета: {package}</b>\n\n🎯 Товар: <b>{name}</b>\nТекущая цена: <b>{current}</b>\n\nОтправьте новую цену или нажмите кнопку.",
        "prod_edit_saved": "✅ Пакет товара сохранён/обновлён.",
        "prod_edit_disabled": "✅ Пакет отключён.",
        "prod_edit_disable_package": "Отключить пакет",
    },
}
for _lang in SUPPORTED_LANGS:
    TEXT.setdefault(_lang, {}).update(PRODUCT_EDIT_TEXT.get(_lang, PRODUCT_EDIT_TEXT["tr"]))


STOCK_VIEW_TEXT: dict[str, dict[str, str]] = {
    "tr": {
        "view_stock_keys": "Stokları Gör",
        "stock_select_platform": "📦 <b>Stokları Gör</b>\n\nÖnce platform/kategori seç. Sadece stokta key olan bölümler gösterilir.",
        "stock_select_group": "{category}\n\nStok keylerini görmek istediğin hile/ürün başlığını seç:",
        "stock_select_package": "🔑 <b>Stok Paketleri</b>\n\n📦 Platform: <b>{category}</b>\n🎯 Ürün: <b>{name}</b>\n\nTXT almak istediğin paketi seç:",
        "stock_empty": "Bu bölümde stokta key yok.",
        "stock_keys_sent": "✅ TXT dosyası gönderildi.\n\n🎯 Ürün: <b>{product}</b>\n📦 Paket: <b>{package}</b>\n🔑 Stok: <b>{count}</b>",
        "stock_txt_caption": "✅ Stok key TXT hazır",
    },
    "en": {
        "view_stock_keys": "View Stock",
        "stock_select_platform": "📦 <b>View Stock</b>\n\nSelect a platform/category first. Only sections with keys in stock are shown.",
        "stock_select_group": "{category}\n\nSelect the cheat/product title whose stock keys you want to view:",
        "stock_select_package": "🔑 <b>Stock Packages</b>\n\n📦 Platform: <b>{category}</b>\n🎯 Product: <b>{name}</b>\n\nSelect the package to receive as TXT:",
        "stock_empty": "There are no keys in stock in this section.",
        "stock_keys_sent": "✅ TXT file sent.\n\n🎯 Product: <b>{product}</b>\n📦 Package: <b>{package}</b>\n🔑 Stock: <b>{count}</b>",
        "stock_txt_caption": "✅ Stock keys TXT is ready",
    },
    "uz": {
        "view_stock_keys": "Stoklarni ko‘rish",
        "stock_select_platform": "📦 <b>Stoklarni ko‘rish</b>\n\nAvval platforma/kategoriyani tanlang. Faqat stokda key bor bo‘limlar ko‘rsatiladi.",
        "stock_select_group": "{category}\n\nStok keylarini ko‘rmoqchi bo‘lgan cheat/mahsulot nomini tanlang:",
        "stock_select_package": "🔑 <b>Stok paketlari</b>\n\n📦 Platforma: <b>{category}</b>\n🎯 Mahsulot: <b>{name}</b>\n\nTXT olish uchun paketni tanlang:",
        "stock_empty": "Bu bo‘limda stokda key yo‘q.",
        "stock_keys_sent": "✅ TXT fayl yuborildi.\n\n🎯 Mahsulot: <b>{product}</b>\n📦 Paket: <b>{package}</b>\n🔑 Stok: <b>{count}</b>",
        "stock_txt_caption": "✅ Stok key TXT tayyor",
    },
    "ru": {
        "view_stock_keys": "Посмотреть склад",
        "stock_select_platform": "📦 <b>Посмотреть склад</b>\n\nСначала выберите платформу/категорию. Показываются только разделы с ключами в наличии.",
        "stock_select_group": "{category}\n\nВыберите название чита/товара, ключи которого нужно посмотреть:",
        "stock_select_package": "🔑 <b>Пакеты на складе</b>\n\n📦 Платформа: <b>{category}</b>\n🎯 Товар: <b>{name}</b>\n\nВыберите пакет для TXT:",
        "stock_empty": "В этом разделе нет ключей на складе.",
        "stock_keys_sent": "✅ TXT файл отправлен.\n\n🎯 Товар: <b>{product}</b>\n📦 Пакет: <b>{package}</b>\n🔑 Остаток: <b>{count}</b>",
        "stock_txt_caption": "✅ TXT со складскими ключами готов",
    },
}
for _lang in SUPPORTED_LANGS:
    TEXT.setdefault(_lang, {}).update(STOCK_VIEW_TEXT.get(_lang, STOCK_VIEW_TEXT["tr"]))



def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def platform_key_from_name(name: str) -> Optional[str]:
    normalized = re.sub(r"\s+", " ", str(name or "").strip().lower().replace("ı", "i"))
    normalized = normalized.replace("/", " / ")
    normalized = re.sub(r"\s+", " ", normalized).strip()
    if normalized in PLATFORM_ALIASES:
        return PLATFORM_ALIASES[normalized]
    compact = normalized.replace(" ", "")
    if compact in {"emulator/pc", "emülatör/pc", "emulatorpc", "emülatörpc"}:
        return "emulator_pc"
    return None


def platform_base_name(platform_key: str) -> str:
    for key, _emoji, name in PLATFORM_CATEGORIES:
        if key == platform_key:
            return name
    return platform_key


def platform_emoji(platform_key: Optional[str]) -> str:
    for key, emoji, _name in PLATFORM_CATEGORIES:
        if key == platform_key:
            return emoji
    return "📦"


def platform_label(user_id: int, platform_key: Optional[str], fallback_name: str = "") -> str:
    if platform_key in PLATFORM_KEY_ORDER:
        return tr(user_id, f"platform_{platform_key}")
    return fallback_name or "Kategori"


def platform_button_label(user_id: int, platform_key: Optional[str], fallback_name: str = "") -> str:
    return f"{platform_emoji(platform_key)} {platform_label(user_id, platform_key, fallback_name)}"


def ensure_platform_categories(conn: sqlite3.Connection) -> None:
    """Android / iOS / Emülatör-PC ana kategorilerini DB'de hazır tutar."""
    cols = {row[1] for row in conn.execute("PRAGMA table_info(categories)").fetchall()}
    if "platform_key" not in cols:
        conn.execute("ALTER TABLE categories ADD COLUMN platform_key TEXT")
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_categories_platform_key ON categories(platform_key) WHERE platform_key IS NOT NULL")

    rows = conn.execute("SELECT id, name, platform_key FROM categories").fetchall()
    for row in rows:
        if row["platform_key"]:
            continue
        detected = platform_key_from_name(row["name"])
        if detected and not conn.execute("SELECT 1 FROM categories WHERE platform_key=?", (detected,)).fetchone():
            conn.execute("UPDATE categories SET platform_key=?, active=1 WHERE id=?", (detected, row["id"]))

    ts = now_iso()
    for key, _emoji, name in PLATFORM_CATEGORIES:
        row = conn.execute("SELECT id FROM categories WHERE platform_key=?", (key,)).fetchone()
        if row:
            conn.execute("UPDATE categories SET name=?, active=1 WHERE id=?", (name, row["id"]))
        else:
            conn.execute(
                "INSERT INTO categories(name, description, active, created_at, platform_key) VALUES(?,?,1,?,?)",
                (name, f"{name} key kategorisi", ts, key),
            )


def platform_order_sql(alias: str = "c") -> str:
    return f"""
        CASE {alias}.platform_key
            WHEN 'android' THEN 1
            WHEN 'ios' THEN 2
            WHEN 'emulator_pc' THEN 3
            ELSE 50
        END
    """


def fmt_dt(value: Optional[str]) -> str:
    if not value:
        return "-"
    try:
        dt = datetime.fromisoformat(value)
        return dt.astimezone().strftime("%Y-%m-%d %H:%M")
    except Exception:
        return value


def clean(s: Any) -> str:
    return html.escape(str(s or ""), quote=False)


def split_pipe(text: str, min_parts: int = 1) -> list[str]:
    parts = [p.strip() for p in text.split("|")]
    if len(parts) < min_parts:
        raise ValueError("not enough parts")
    return parts


def normalize_role(role: str) -> str:
    role = role.strip().lower().replace("-", "_")
    aliases = {
        "alt_satici": "sub_seller",
        "altsatici": "sub_seller",
        "subseller": "sub_seller",
        "sub_seller": "sub_seller",
        "seller": "seller",
        "satici": "seller",
        "satıcı": "seller",
        "distributor": "distributor",
        "distibutor": "distributor",
        "distbütör": "distributor",
        "distribütör": "distributor",
        "admin": "admin",
        "customer": "customer",
        "user": "customer",
    }
    if role not in aliases:
        raise ValueError("bad role")
    return aliases[role]


# =========================
# VERİTABANI
# =========================
@contextmanager
def db() -> Iterable[sqlite3.Connection]:
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    with db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                role TEXT NOT NULL DEFAULT 'customer',
                parent_id INTEGER,
                balance REAL NOT NULL DEFAULT 0,
                active_session INTEGER NOT NULL DEFAULT 1,
                lang TEXT NOT NULL DEFAULT 'tr',
                layout TEXT NOT NULL DEFAULT 'mobile',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                platform_key TEXT
            );

            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category_id INTEGER NOT NULL REFERENCES categories(id),
                name TEXT NOT NULL,
                description TEXT,
                duration_days INTEGER NOT NULL DEFAULT 30,
                base_price REAL NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS product_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER,
                actor_id INTEGER,
                action TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL REFERENCES products(id),
                key_value TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL DEFAULT 'stock',
                owner_id INTEGER,
                sold_at TEXT,
                expires_at TEXT,
                reset_count INTEGER NOT NULL DEFAULT 0,
                max_resets INTEGER NOT NULL DEFAULT 0,
                notes TEXT,
                added_by INTEGER,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS key_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key_id INTEGER,
                user_id INTEGER,
                action TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS key_reset_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                product_id INTEGER,
                status TEXT NOT NULL DEFAULT 'pending',
                requested_at TEXT NOT NULL,
                processed_at TEXT,
                processed_by INTEGER,
                note TEXT
            );

            CREATE TABLE IF NOT EXISTS price_overrides (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scope_type TEXT NOT NULL,
                scope_value TEXT NOT NULL,
                product_id INTEGER NOT NULL REFERENCES products(id),
                price REAL NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                UNIQUE(scope_type, scope_value, product_id)
            );

            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                product_id INTEGER,
                key_id INTEGER,
                amount REAL NOT NULL DEFAULT 0,
                type TEXT NOT NULL,
                note TEXT,
                created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_keys_product_status ON keys(product_id, status);
            CREATE INDEX IF NOT EXISTS idx_keys_owner ON keys(owner_id);
            CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id, created_at);
            CREATE INDEX IF NOT EXISTS idx_price_product ON price_overrides(product_id);
            CREATE INDEX IF NOT EXISTS idx_reset_requests_status ON key_reset_requests(status, requested_at);
            CREATE INDEX IF NOT EXISTS idx_reset_requests_key_user ON key_reset_requests(key_id, user_id, status);

            CREATE TABLE IF NOT EXISTS banned_users (
                user_id INTEGER PRIMARY KEY,
                reason TEXT,
                banned_by INTEGER,
                created_at TEXT NOT NULL
            );
            """
        )
        existing_cols = {row[1] for row in conn.execute("PRAGMA table_info(users)").fetchall()}
        if "email" not in existing_cols:
            conn.execute("ALTER TABLE users ADD COLUMN email TEXT")
        if "password_hash" not in existing_cols:
            conn.execute("ALTER TABLE users ADD COLUMN password_hash TEXT")
        if "password_updated_at" not in existing_cols:
            conn.execute("ALTER TABLE users ADD COLUMN password_updated_at TEXT")
        if "last_login_at" not in existing_cols:
            conn.execute("ALTER TABLE users ADD COLUMN last_login_at TEXT")
        if "approved" not in existing_cols:
            conn.execute("ALTER TABLE users ADD COLUMN approved INTEGER NOT NULL DEFAULT 0")
        if "admin_permissions" not in existing_cols:
            conn.execute("ALTER TABLE users ADD COLUMN admin_permissions TEXT NOT NULL DEFAULT ''")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email_lower ON users(lower(email)) WHERE email IS NOT NULL")

        cat_cols = {row[1] for row in conn.execute("PRAGMA table_info(categories)").fetchall()}
        if "platform_key" not in cat_cols:
            conn.execute("ALTER TABLE categories ADD COLUMN platform_key TEXT")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_categories_platform_key ON categories(platform_key) WHERE platform_key IS NOT NULL")
        ensure_platform_categories(conn)

        for admin_id in ADMIN_IDS:
            upsert_user_raw(conn, admin_id, None, "Admin", role="admin", active_session=None)
            conn.execute(
                "UPDATE users SET role='admin', approved=1, admin_permissions=?, updated_at=? WHERE user_id=?",
                (','.join(PERMISSION_ORDER), now_iso(), admin_id),
            )


def upsert_user_raw(
    conn: sqlite3.Connection,
    user_id: int,
    username: Optional[str],
    first_name: Optional[str],
    role: Optional[str] = None,
    active_session: Optional[int] = 1,
) -> None:
    ts = now_iso()
    if user_id not in ADMIN_IDS and conn.execute("SELECT 1 FROM banned_users WHERE user_id=?", (user_id,)).fetchone():
        return
    current = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
    if current:
        final_role = role or current["role"]
        if user_id in ADMIN_IDS:
            final_role = "admin"
        final_session = int(current["active_session"]) if active_session is None else int(active_session)
        conn.execute(
            """
            UPDATE users
               SET username=COALESCE(?, username),
                   first_name=COALESCE(?, first_name),
                   role=?,
                   active_session=?,
                   updated_at=?
             WHERE user_id=?
            """,
            (username, first_name, final_role, final_session, ts, user_id),
        )
    else:
        final_role = role or ("admin" if user_id in ADMIN_IDS else "customer")
        final_session = 1 if active_session is None else int(active_session)
        approved = 1 if user_id in ADMIN_IDS else 0
        admin_permissions = ','.join(PERMISSION_ORDER) if user_id in ADMIN_IDS else ''
        conn.execute(
            """
            INSERT INTO users(user_id, username, first_name, role, balance, active_session, lang, layout, approved, admin_permissions, created_at, updated_at)
            VALUES(?, ?, ?, ?, 0, ?, ?, 'mobile', ?, ?, ?, ?)
            """,
            (user_id, username, first_name, final_role, final_session, DEFAULT_LANG, approved, admin_permissions, ts, ts),
        )


def ensure_user(update: Update, login: Optional[bool] = True) -> sqlite3.Row:
    tg_user = update.effective_user
    if tg_user is None:
        raise RuntimeError("No effective user")
    with db() as conn:
        upsert_user_raw(
            conn,
            tg_user.id,
            tg_user.username,
            tg_user.first_name,
            active_session=None if login is None else (1 if login else 0),
        )
        row = conn.execute("SELECT * FROM users WHERE user_id=?", (tg_user.id,)).fetchone()
        if row is None and conn.execute("SELECT 1 FROM banned_users WHERE user_id=?", (tg_user.id,)).fetchone():
            return {
                "user_id": tg_user.id,
                "username": tg_user.username,
                "first_name": tg_user.first_name,
                "role": "banned",
                "parent_id": None,
                "balance": 0,
                "active_session": 0,
                "lang": DEFAULT_LANG,
                "layout": "mobile",
                "email": None,
                "password_hash": None,
                "approved": 0,
                "admin_permissions": "",
            }
        assert row is not None
        return row


def get_user(user_id: int) -> Optional[sqlite3.Row]:
    with db() as conn:
        return conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()


def user_lang(user_id: int) -> str:
    row = get_user(user_id)
    if not row:
        return DEFAULT_LANG
    lang = row["lang"] or DEFAULT_LANG
    return lang if lang in SUPPORTED_LANGS else DEFAULT_LANG


def tr(_user_id: int, _text_key: str, **kwargs: Any) -> str:
    """Çeviri yardımcısı.

    Parametre adları özellikle _ ile başlıyor; çünkü metin şablonlarında
    {user_id} veya {key} gibi alanlar kullanıldığında Python'da
    `got multiple values for argument ...` hatası oluşmasın.
    """
    lang = user_lang(_user_id)
    template = TEXT.get(lang, TEXT[DEFAULT_LANG]).get(_text_key, TEXT[DEFAULT_LANG].get(_text_key, _text_key))
    return template.format(**kwargs) if kwargs else template


def is_owner(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def is_banned_id(user_id: int) -> bool:
    if user_id in ADMIN_IDS:
        return False
    with db() as conn:
        return bool(conn.execute("SELECT 1 FROM banned_users WHERE user_id=?", (user_id,)).fetchone())


def is_admin(user_id: int) -> bool:
    row = get_user(user_id)
    return user_id in ADMIN_IDS or bool(row and row["role"] == "admin")


def admin_perm_set(row: Optional[sqlite3.Row]) -> set[str]:
    if not row:
        return set()
    raw = row["admin_permissions"] if "admin_permissions" in row.keys() else ""
    return {p.strip() for p in str(raw or "").split(",") if p.strip()}


def has_admin_perm(user_id: int, perm: str) -> bool:
    if is_owner(user_id):
        return True
    row = get_user(user_id)
    if not row or row["role"] != "admin" or int(row["approved"] or 0) != 1:
        return False
    return perm in admin_perm_set(row)


def is_approved_user(user_id: int) -> bool:
    if is_owner(user_id):
        return True
    row = get_user(user_id)
    return bool(row and int(row["approved"] or 0) == 1)


def can_use_bot(user_id: int) -> bool:
    return (not is_banned_id(user_id)) and session_active(user_id) and is_approved_user(user_id)


def permission_names(raw: str) -> str:
    perms = [p for p in str(raw or "").split(",") if p in ADMIN_PERMISSIONS]
    if not perms:
        return "-"
    return ", ".join(ADMIN_PERMISSIONS[p] for p in perms)


async def deny_permission(update: Update, user_id: int) -> None:
    await send_or_edit(update, tr(user_id, "permission_denied"), back_home_kb(user_id, "admin"))


def normalize_email(email: str) -> str:
    return email.strip().lower()


def valid_email(email: str) -> bool:
    email = normalize_email(email)
    return bool(re.fullmatch(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}", email)) and len(email) <= 120


def hash_password(password: str) -> str:
    iterations = 150_000
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), iterations).hex()
    return f"pbkdf2_sha256${iterations}${salt}${digest}"


def verify_password(password: str, stored_hash: Optional[str]) -> bool:
    if not stored_hash:
        return False
    try:
        algo, iterations_s, salt, digest = stored_hash.split("$", 3)
        if algo != "pbkdf2_sha256":
            return False
        iterations = int(iterations_s)
        candidate = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), iterations).hex()
        return secrets.compare_digest(candidate, digest)
    except Exception:
        return False


def has_auth_account(row: Optional[sqlite3.Row]) -> bool:
    return bool(row and row["email"] and row["password_hash"])


def session_active(user_id: int) -> bool:
    row = get_user(user_id)
    return bool(row and row["active_session"] == 1 and has_auth_account(row))


def get_counts() -> dict[str, int]:
    with db() as conn:
        return {
            "users": conn.execute("SELECT COUNT(*) FROM users").fetchone()[0],
            "categories": conn.execute("SELECT COUNT(*) FROM categories WHERE active=1").fetchone()[0],
            "products": conn.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0],
            "stock_keys": conn.execute("SELECT COUNT(*) FROM keys WHERE status='stock'").fetchone()[0],
            "sold_keys": conn.execute("SELECT COUNT(*) FROM keys WHERE status='sold'").fetchone()[0],
        }


def stock_count(conn: sqlite3.Connection, product_id: int) -> int:
    return int(conn.execute("SELECT COUNT(*) FROM keys WHERE product_id=? AND status='stock'", (product_id,)).fetchone()[0])


def resolve_price(conn: sqlite3.Connection, user_id: int, product_id: int) -> float:
    user = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
    product = conn.execute("SELECT base_price FROM products WHERE id=?", (product_id,)).fetchone()
    if not product:
        raise ValueError("product not found")
    # Kullanıcıya özel fiyat en öncelikli
    row = conn.execute(
        "SELECT price FROM price_overrides WHERE scope_type='user' AND scope_value=? AND product_id=?",
        (str(user_id), product_id),
    ).fetchone()
    if row:
        return float(row["price"])
    if user:
        role = user["role"]
        row = conn.execute(
            "SELECT price FROM price_overrides WHERE scope_type='role' AND scope_value=? AND product_id=?",
            (role, product_id),
        ).fetchone()
        if row:
            return float(row["price"])
    return float(product["base_price"])


def package_label_for_days(user_id: int, days: int) -> str:
    days = int(days)
    if days == 1:
        return tr(user_id, "package_daily")
    if days == 7:
        return tr(user_id, "package_weekly")
    if days in (30, 31):
        return tr(user_id, "package_monthly")
    return tr(user_id, "package_custom", days=days)


def package_emoji(days: int) -> str:
    days = int(days)
    if days == 1:
        return "📅"
    if days == 7:
        return "🗓"
    if days in (30, 31):
        return "📆"
    return "⏳"


def product_group_base_name(name: str) -> str:
    """Ürün adından paket/süre kelimelerini temizler; King günlük/haftalık/aylık tek KING altında toplanır."""
    value = str(name or "").strip()
    value = re.sub(r"[•|/]+", " ", value)
    value = re.sub(
        r"(?iu)\b(1\s*paket|paket\s*1|daily|weekly|monthly|günlük|gunluk|haftalık|haftalik|aylık|aylik|kunlik|haftalik|oylik|дневной|недельный|месячный)\b",
        " ",
        value,
    )
    value = re.sub(r"(?iu)\b(1|7|30|31)\s*(gün|gun|day|days|kun|день|дня|дней)\b", " ", value)
    value = re.sub(r"\s*[-–—]+\s*$", "", value)
    value = re.sub(r"\s+", " ", value).strip(" -–—•|/")
    return value or str(name or "").strip()


def product_group_key(name: str) -> str:
    """Aynı hile/ürün adını paket listesinde tek buton altında toplar."""
    return re.sub(r"\s+", " ", product_group_base_name(name).strip().casefold())


def product_group_emoji(name: str) -> str:
    n = product_group_key(name).replace("ı", "i")
    if "king" in n or "kral" in n:
        return "👑"
    if "vip" in n or "premium" in n or "plus" in n:
        return "💎"
    if "pubg" in n or "mobile" in n:
        return "🎮"
    if "online" in n:
        return "🟢"
    if "ios" in n or "iphone" in n or "ipad" in n:
        return "🍎"
    if "android" in n:
        return "🤖"
    if "pc" in n or "emulator" in n or "emülatör" in n:
        return "🖥"
    if "hile" in n or "hack" in n or "cheat" in n:
        return "⚡"
    return "🧩"


def product_by_id(conn: sqlite3.Connection, product_id: int) -> Optional[sqlite3.Row]:
    return conn.execute(
        """
        SELECT p.*, c.name AS category_name
          FROM products p
          JOIN categories c ON c.id=p.category_id
         WHERE p.id=?
        """,
        (product_id,),
    ).fetchone()


def add_product_history(conn: sqlite3.Connection, product_id: Optional[int], actor_id: int, action: str, details: str = "") -> None:
    conn.execute(
        "INSERT INTO product_history(product_id, actor_id, action, details, created_at) VALUES(?,?,?,?,?)",
        (product_id, actor_id, action, details, now_iso()),
    )


def add_key_event(conn: sqlite3.Connection, key_id: Optional[int], user_id: int, action: str, details: str = "") -> None:
    conn.execute(
        "INSERT INTO key_events(key_id, user_id, action, details, created_at) VALUES(?,?,?,?,?)",
        (key_id, user_id, action, details, now_iso()),
    )


# =========================
# KLAVYE YARDIMCILARI
# =========================
def kb(rows: list[list[tuple[str, str]]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton(text, callback_data=data) for text, data in row] for row in rows])


def chunk_buttons(buttons: list[tuple[str, str]], cols: int) -> list[list[tuple[str, str]]]:
    return [buttons[i : i + cols] for i in range(0, len(buttons), cols)]


def user_cols(user_id: int) -> int:
    row = get_user(user_id)
    return 2 if row and row["layout"] == "pc" else 1


def main_menu_kb(user_id: int) -> InlineKeyboardMarkup:
    # Ana menü sade tutuldu: kullanıcı tarafında Fiyatlar ve Bakiye butonları gösterilmez.
    # İlgili işlemler admin panelinde durmaya devam eder.
    buttons = [
        ("🛒 " + tr(user_id, "buy_key"), "buy"),
        ("🔑 " + tr(user_id, "my_keys"), "my_keys"),
        ("🧾 " + tr(user_id, "tx_history"), "tx_history"),
        ("🖥 " + tr(user_id, "layout"), "layout"),
        ("🌐 " + tr(user_id, "language"), "language"),
        ("🚪 " + tr(user_id, "logout"), "logout"),
    ]
    tuple_rows = chunk_buttons(buttons, user_cols(user_id))
    rows = [[InlineKeyboardButton(text, callback_data=data) for text, data in row] for row in tuple_rows]

    # Telegram Mini App butonu. MINIAPP_URL ortam değişkeni HTTPS bir adres olursa görünür.
    if MINIAPP_URL:
        rows.insert(0, [InlineKeyboardButton("🌐 MiniApp / Web Panel", web_app=WebAppInfo(url=MINIAPP_URL))])
    if is_admin(user_id):
        rows.insert(0, [InlineKeyboardButton("🛡 " + tr(user_id, "admin_panel"), callback_data="admin")])
    return InlineKeyboardMarkup(rows)


def back_home_kb(user_id: int, back_cb: str = "home") -> InlineKeyboardMarkup:
    return kb([[("⬅️ " + tr(user_id, "back"), back_cb), ("🏠 " + tr(user_id, "home"), "home")]])


def cancel_kb(user_id: int) -> InlineKeyboardMarkup:
    return kb([[("❌ " + tr(user_id, "cancel"), "cancel_flow")], [("🏠 " + tr(user_id, "home"), "home")]])


def auth_kb(user_id: int) -> InlineKeyboardMarkup:
    return kb([
        [("🆕 " + tr(user_id, "auth_register"), "auth_register"), ("🔓 " + tr(user_id, "auth_login"), "auth_login")],
        [("♻️ " + tr(user_id, "auth_forgot"), "auth_forgot")],
        [("🌐 " + tr(user_id, "language"), "language")],
    ])


def auth_cancel_kb(user_id: int) -> InlineKeyboardMarkup:
    return kb([[("⬅️ " + tr(user_id, "auth_cancel"), "auth")]])


async def show_auth_screen(update: Update, context: ContextTypes.DEFAULT_TYPE, note_key: Optional[str] = None) -> None:
    row = ensure_user(update, login=None)
    user_id = int(row["user_id"])
    context.user_data.clear()
    if is_banned_id(user_id):
        await send_or_edit(update, tr(user_id, "banned_msg", user_id=user_id))
        return
    text = tr(user_id, "auth_title") + "\n\n" + tr(user_id, "auth_body", user_id=user_id)
    if note_key:
        text += "\n\n" + tr(user_id, note_key)
    await send_or_edit(update, text, auth_kb(user_id))


async def start_auth_register(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    row = ensure_user(update, login=None)
    user_id = int(row["user_id"])
    context.user_data.clear()
    context.user_data["flow"] = "auth_register_email"
    await send_or_edit(update, tr(user_id, "auth_email_prompt"), auth_cancel_kb(user_id))


async def start_auth_login(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    row = ensure_user(update, login=None)
    user_id = int(row["user_id"])
    context.user_data.clear()
    context.user_data["flow"] = "auth_login_email"
    await send_or_edit(update, tr(user_id, "auth_email_prompt"), auth_cancel_kb(user_id))


async def start_auth_forgot(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    row = ensure_user(update, login=None)
    user_id = int(row["user_id"])
    if not has_auth_account(row):
        await show_auth_screen(update, context, "auth_no_account")
        return
    context.user_data.clear()
    context.user_data["flow"] = "auth_forgot_newpass"
    await send_or_edit(update, tr(user_id, "auth_new_password_prompt"), auth_cancel_kb(user_id))


def admin_menu_kb(user_id: int) -> InlineKeyboardMarkup:
    rows: list[list[tuple[str, str]]] = []
    r1: list[tuple[str, str]] = []
    if has_admin_perm(user_id, "resellers"):
        r1.append(("👥 " + tr(user_id, "admin_resellers"), "adm_resellers"))
    if has_admin_perm(user_id, "prices"):
        r1.append(("💵 " + tr(user_id, "admin_prices"), "adm_prices"))
    if r1:
        rows.append(r1)
    r2: list[tuple[str, str]] = []
    if has_admin_perm(user_id, "keys"):
        r2.append(("🔑 " + tr(user_id, "admin_keys"), "adm_keys"))
    if has_admin_perm(user_id, "cats"):
        r2.append(("📦 " + tr(user_id, "admin_cats"), "adm_cats"))
    if r2:
        rows.append(r2)
    r3: list[tuple[str, str]] = []
    if has_admin_perm(user_id, "products"):
        r3.append(("🛒 " + tr(user_id, "admin_products"), "adm_products"))
    if has_admin_perm(user_id, "balance"):
        r3.append(("💰 " + tr(user_id, "admin_balance"), "adm_balance"))
    if r3:
        rows.append(r3)
    r4: list[tuple[str, str]] = []
    if has_admin_perm(user_id, "history"):
        r4.append(("📜 " + tr(user_id, "admin_history"), "adm_history"))
    if has_admin_perm(user_id, "users"):
        r4.append(("👤 " + tr(user_id, "admin_users"), "adm_users"))
    if r4:
        rows.append(r4)
    r5: list[tuple[str, str]] = []
    if has_admin_perm(user_id, "seed"):
        r5.append(("🧪 " + tr(user_id, "seed_demo"), "adm_seed"))
    r5.append(("🏠 " + tr(user_id, "home"), "home"))
    rows.append(r5)
    return kb(rows)


# =========================
# GÖNDERME / DÜZENLEME
# =========================
async def send_or_edit(update: Update, text: str, reply_markup: Optional[InlineKeyboardMarkup] = None) -> None:
    if update.callback_query:
        query = update.callback_query
        try:
            await query.edit_message_text(text=text, reply_markup=reply_markup, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
        except BadRequest as exc:
            if "Message is not modified" not in str(exc):
                await query.message.reply_text(text=text, reply_markup=reply_markup, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
    elif update.effective_message:
        await update.effective_message.reply_text(text=text, reply_markup=reply_markup, parse_mode=ParseMode.HTML, disable_web_page_preview=True)


async def safe_answer(update: Update) -> None:
    if update.callback_query:
        try:
            await update.callback_query.answer()
        except TelegramError:
            pass


# =========================
# USER SAYFALARI
# =========================
async def show_home(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    row = ensure_user(update, login=None)
    user_id = row["user_id"]
    if is_banned_id(user_id):
        await send_or_edit(update, tr(user_id, "banned_msg", user_id=user_id))
        return
    if not session_active(user_id):
        await show_auth_screen(update, context, "auth_required")
        return
    if not is_approved_user(user_id):
        await send_or_edit(update, tr(user_id, "auth_pending", user_id=user_id), kb([[ ("🚪 " + tr(user_id, "logout"), "logout"), ("🌐 " + tr(user_id, "language"), "language") ]]))
        return
    layout_text = tr(user_id, "pc") if row["layout"] == "pc" else tr(user_id, "mobile")
    text = tr(user_id, "start_title") + "\n\n" + tr(
        user_id,
        "start_body",
        user_id=user_id,
        role=clean(row["role"]),
        balance=float(row["balance"]),
        layout=layout_text,
    )
    await send_or_edit(update, text, main_menu_kb(user_id))


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    context.user_data.clear()
    await show_home(update, context)


async def cmd_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await show_home(update, context)


async def cmd_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    row = ensure_user(update, login=None)
    user_id = int(row["user_id"])
    if is_banned_id(user_id):
        await send_or_edit(update, tr(user_id, "banned_msg", user_id=user_id))
        return
    await send_or_edit(update, tr(user_id, "id_card", user_id=user_id), auth_kb(user_id) if not session_active(user_id) else main_menu_kb(user_id))


async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    ensure_user(update, login=None)
    user_id = update.effective_user.id
    if is_banned_id(user_id):
        await send_or_edit(update, tr(user_id, "banned_msg", user_id=user_id))
        return
    if not session_active(user_id):
        await show_auth_screen(update, context, "auth_required")
        return
    if not is_approved_user(user_id):
        await send_or_edit(update, tr(user_id, "auth_pending", user_id=user_id))
        return
    if not is_admin(user_id):
        await send_or_edit(update, tr(user_id, "admin_only"), main_menu_kb(user_id))
        return
    await show_admin(update, context)


async def cmd_logout(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    with db() as conn:
        conn.execute("UPDATE users SET active_session=0, updated_at=? WHERE user_id=?", (now_iso(), user_id))
    context.user_data.clear()
    await send_or_edit(update, tr(user_id, "logged_out"))


async def show_categories(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not session_active(user_id):
        await send_or_edit(update, tr(user_id, "blocked_logout"))
        return
    with db() as conn:
        ensure_platform_categories(conn)
        cats = conn.execute(
            f"""
            SELECT *
              FROM categories
             WHERE active=1
             ORDER BY {platform_order_sql('categories')}, lower(trim(name)) ASC, id ASC
            """
        ).fetchall()
    if not cats:
        await send_or_edit(update, tr(user_id, "no_categories"), back_home_kb(user_id))
        return
    rows = [[(platform_button_label(user_id, c["platform_key"] if "platform_key" in c.keys() else None, c["name"]), f"cat:{c['id']}")] for c in cats]
    rows.append([("🏠 " + tr(user_id, "home"), "home")])
    await send_or_edit(update, tr(user_id, "select_platform"), kb(rows))


async def show_products(update: Update, context: ContextTypes.DEFAULT_TYPE, category_id: int) -> None:
    """Platform içine girince önce hile/ürün adlarını gösterir.

    Örnek akış:
    Key Satın Alma -> 🍎 iOS -> 👑 King -> 📅 Günlük / 🗓 Haftalık / 📆 Aylık
    """
    user_id = update.effective_user.id
    with db() as conn:
        cat = conn.execute("SELECT * FROM categories WHERE id=? AND active=1", (category_id,)).fetchone()
        products = conn.execute(
            """
            SELECT p.*,
                   (SELECT COUNT(*) FROM keys k WHERE k.product_id=p.id AND k.status='stock') AS stock
              FROM products p
             WHERE p.category_id=? AND p.active=1
             ORDER BY lower(trim(p.name)) ASC,
                CASE
                    WHEN p.duration_days=1 THEN 1
                    WHEN p.duration_days=7 THEN 2
                    WHEN p.duration_days IN (30,31) THEN 3
                    ELSE 4
                END, p.base_price ASC, p.id ASC
            """,
            (category_id,),
        ).fetchall()
        prices = {int(p["id"]): resolve_price(conn, user_id, int(p["id"])) for p in products}
    if not cat:
        await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id, "buy"))
        return
    if not products:
        cat_title = platform_button_label(user_id, cat["platform_key"] if "platform_key" in cat.keys() else None, cat["name"])
        text = tr(user_id, "category_detail", category=clean(cat_title), description=clean(cat["description"] or "-"), packages=tr(user_id, "no_packages"))
        await send_or_edit(update, text, back_home_kb(user_id, "buy"))
        return

    grouped: dict[str, dict[str, Any]] = {}
    for p in products:
        gkey = product_group_key(str(p["name"]))
        group = grouped.setdefault(
            gkey,
            {
                "name": str(p["name"]),
                "first_id": int(p["id"]),
                "package_keys": set(),
                "stock": 0,
                "prices": [],
            },
        )
        days = int(p["duration_days"] or 0)
        package_key = 30 if days in (30, 31) else days
        group["package_keys"].add(package_key)
        group["stock"] += int(p["stock"] or 0)
        group["prices"].append(float(prices[int(p["id"])]))

    rows: list[list[tuple[str, str]]] = []
    for group in sorted(grouped.values(), key=lambda g: product_group_key(g["name"])):
        name = str(group["name"])
        min_price = min(group["prices"]) if group["prices"] else 0.0
        max_price = max(group["prices"]) if group["prices"] else min_price
        package_count = len(group["package_keys"])
        label = f"{product_group_emoji(name)} {name} ({package_count})"
        rows.append([(label, f"grp:{category_id}:{int(group['first_id'])}")])

    cat_title = platform_button_label(user_id, cat["platform_key"] if "platform_key" in cat.keys() else None, cat["name"])
    rows.append([("⬅️ " + tr(user_id, "back"), "buy"), ("🏠 " + tr(user_id, "home"), "home")])
    await send_or_edit(update, tr(user_id, "select_product_group", category=clean(cat_title)), kb(rows))


async def show_product_group(update: Update, context: ContextTypes.DEFAULT_TYPE, category_id: int, sample_product_id: int) -> None:
    """Seçilen hile/ürün adının günlük/haftalık/aylık paketlerini gösterir."""
    user_id = update.effective_user.id
    with db() as conn:
        sample = conn.execute(
            "SELECT * FROM products WHERE id=? AND category_id=? AND active=1",
            (sample_product_id, category_id),
        ).fetchone()
        cat = conn.execute("SELECT * FROM categories WHERE id=? AND active=1", (category_id,)).fetchone()
        if not sample or not cat:
            await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id, f"cat:{category_id}"))
            return
        group_name = str(sample["name"])
        products = conn.execute(
            """
            SELECT p.*,
                   (SELECT COUNT(*) FROM keys k WHERE k.product_id=p.id AND k.status='stock') AS stock
              FROM products p
             WHERE p.category_id=? AND p.active=1 AND lower(trim(p.name))=lower(trim(?))
             ORDER BY
                CASE
                    WHEN p.duration_days=1 THEN 1
                    WHEN p.duration_days=7 THEN 2
                    WHEN p.duration_days IN (30,31) THEN 3
                    ELSE 4
                END, p.base_price ASC, p.id ASC
            """,
            (category_id, group_name),
        ).fetchall()
        prices = {int(p["id"]): resolve_price(conn, user_id, int(p["id"])) for p in products}

    if not products:
        await send_or_edit(update, tr(user_id, "product_group_empty"), back_home_kb(user_id, f"cat:{category_id}"))
        return

    package_lines: list[str] = []
    button_rows: list[list[tuple[str, str]]] = []
    for p in products:
        pid = int(p["id"])
        days = int(p["duration_days"])
        label = package_label_for_days(user_id, days)
        emoji = package_emoji(days)
        stock = int(p["stock"] or 0)
        price = float(prices[pid])
        package_lines.append(f"{emoji} <b>{label}</b> — <b>${price:.2f}</b> — Stok: <b>{stock}</b>")
        button_rows.append([(f"{emoji} {label} • ${price:.2f} • Stok:{stock}", f"prod:{pid}")])

    cat_title = platform_button_label(user_id, cat["platform_key"] if "platform_key" in cat.keys() else None, cat["name"])
    product_title = f"{product_group_emoji(group_name)} {clean(group_name)}"
    text = tr(
        user_id,
        "product_group_detail",
        product=product_title,
        category=clean(cat_title),
        packages="\n".join(package_lines),
    )
    button_rows.append([("⬅️ " + tr(user_id, "back"), f"cat:{category_id}"), ("🏠 " + tr(user_id, "home"), "home")])
    await send_or_edit(update, text, kb(button_rows))


async def show_product(update: Update, context: ContextTypes.DEFAULT_TYPE, product_id: int) -> None:
    user_id = update.effective_user.id
    with db() as conn:
        p = product_by_id(conn, product_id)
        if not p or not p["active"]:
            await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id, "buy"))
            return
        price = resolve_price(conn, user_id, product_id)
        stock = stock_count(conn, product_id)
    days = int(p["duration_days"])
    package_label = package_label_for_days(user_id, days)
    display_name = f"{clean(p['name'])} / {clean(package_label)}"
    text = tr(
        user_id,
        "product_card",
        name=display_name,
        price=price,
        days=days,
        stock=stock,
        description=clean(p["description"] or "-"),
    )
    rows = [
        [("✅ " + tr(user_id, "confirm_buy"), f"buy_confirm:{product_id}")],
        [("⬅️ " + tr(user_id, "back"), f"grp:{p['category_id']}:{product_id}"), ("🏠 " + tr(user_id, "home"), "home")],
    ]
    await send_or_edit(update, text, kb(rows))


def purchase_key(user_id: int, product_id: int) -> tuple[bool, str, Optional[dict[str, Any]]]:
    conn = sqlite3.connect(DB_PATH, timeout=30, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        conn.execute("BEGIN IMMEDIATE")
        user = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        product = product_by_id(conn, product_id)
        if not user or not product or not product["active"]:
            conn.execute("ROLLBACK")
            return False, "not_found", None
        price = resolve_price(conn, user_id, product_id)
        if float(user["balance"]) + 1e-9 < price:
            conn.execute("ROLLBACK")
            return False, "insufficient", {"price": price, "balance": float(user["balance"])}
        key = conn.execute(
            "SELECT * FROM keys WHERE product_id=? AND status='stock' ORDER BY id ASC LIMIT 1",
            (product_id,),
        ).fetchone()
        if not key:
            conn.execute("ROLLBACK")
            return False, "sold_out", None
        sold_at = now_iso()
        expires = (datetime.now(timezone.utc) + timedelta(days=int(product["duration_days"]))).replace(microsecond=0).isoformat()
        conn.execute(
            """
            UPDATE keys
               SET status='sold', owner_id=?, sold_at=?, expires_at=?, updated_at=?
             WHERE id=? AND status='stock'
            """,
            (user_id, sold_at, expires, sold_at, key["id"]),
        )
        conn.execute("UPDATE users SET balance=balance-?, updated_at=? WHERE user_id=?", (price, sold_at, user_id))
        conn.execute(
            "INSERT INTO transactions(user_id, product_id, key_id, amount, type, note, created_at) VALUES(?,?,?,?,?,?,?)",
            (user_id, product_id, key["id"], -price, "purchase", f"Purchased {product['name']}", sold_at),
        )
        add_key_event(conn, key["id"], user_id, "sold", f"Product={product['name']} Price={price}")
        add_product_history(conn, product_id, user_id, "purchase", f"Key ID {key['id']} sold to {user_id} for ${price:.2f}")
        conn.execute("COMMIT")
        return True, "ok", {"key_id": key["id"], "key": key["key_value"], "product": product["name"], "expires": expires, "price": price}
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except Exception:
            pass
        logger.exception("purchase failed")
        raise
    finally:
        conn.close()


async def do_purchase(update: Update, context: ContextTypes.DEFAULT_TYPE, product_id: int) -> None:
    user_id = update.effective_user.id
    ok, code, data = purchase_key(user_id, product_id)
    if not ok:
        if code == "insufficient" and data:
            await send_or_edit(update, tr(user_id, "insufficient", price=data["price"], balance=data["balance"]), back_home_kb(user_id, f"prod:{product_id}"))
        elif code == "sold_out":
            await send_or_edit(update, tr(user_id, "sold_out"), back_home_kb(user_id, f"prod:{product_id}"))
        else:
            await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id, "buy"))
        return
    assert data
    text = tr(
        user_id,
        "purchase_ok",
        product=clean(data["product"]),
        key=clean(data["key"]),
        expires=fmt_dt(data["expires"]),
    )
    await send_or_edit(update, text, kb([[("🔑 " + tr(user_id, "copy_key"), f"key:{data['key_id']}")], [("🏠 " + tr(user_id, "home"), "home")]]))


async def show_my_keys(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    with db() as conn:
        rows = conn.execute(
            """
            SELECT k.*, p.name AS product_name
              FROM keys k
              JOIN products p ON p.id=k.product_id
             WHERE k.owner_id=?
             ORDER BY k.sold_at DESC, k.id DESC
             LIMIT 20
            """,
            (user_id,),
        ).fetchall()
    if not rows:
        await send_or_edit(update, tr(user_id, "no_keys"), back_home_kb(user_id))
        return
    btns = []
    text_lines = ["🔑 <b>" + tr(user_id, "my_keys") + "</b>"]
    for r in rows:
        text_lines.append(f"\n#{r['id']} | <b>{clean(r['product_name'])}</b> | {clean(r['status'])} | {fmt_dt(r['expires_at'])}")
        btns.append([(f"🔑 #{r['id']} {clean(r['product_name'])}", f"key:{r['id']}")])
    btns.append([("🏠 " + tr(user_id, "home"), "home")])
    await send_or_edit(update, "\n".join(text_lines), kb(btns))


async def show_key(update: Update, context: ContextTypes.DEFAULT_TYPE, key_id: int) -> None:
    user_id = update.effective_user.id
    with db() as conn:
        r = conn.execute(
            """
            SELECT k.*, p.name AS product_name
              FROM keys k JOIN products p ON p.id=k.product_id
             WHERE k.id=? AND (k.owner_id=? OR ?=1)
            """,
            (key_id, user_id, 1 if is_admin(user_id) else 0),
        ).fetchone()
    if not r:
        await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id))
        return
    text = tr(
        user_id,
        "key_info",
        product=clean(r["product_name"]),
        key=clean(r["key_value"]),
        status=clean(r["status"]),
        expires=fmt_dt(r["expires_at"]),
        reset_count=int(r["reset_count"]),
        max_resets="∞",
    )
    rows = []
    if r["status"] == "sold" and r["owner_id"] == user_id:
        rows.append([("🔄 " + tr(user_id, "reset_key"), f"key_reset:{key_id}")])
    rows.append([("⬅️ " + tr(user_id, "back"), "my_keys"), ("🏠 " + tr(user_id, "home"), "home")])
    await send_or_edit(update, text, kb(rows))


def reset_request_admin_ids(conn: sqlite3.Connection) -> set[int]:
    ids = set(ADMIN_IDS)
    try:
        rows = conn.execute("SELECT user_id, admin_permissions FROM users WHERE role='admin' AND approved=1").fetchall()
    except Exception:
        return ids
    for row in rows:
        uid = int(row["user_id"])
        if uid in ADMIN_IDS:
            ids.add(uid)
            continue
        perms = {p.strip() for p in str(row["admin_permissions"] or "").split(",") if p.strip()}
        if "keys" in perms or "users" in perms:
            ids.add(uid)
    return ids


async def notify_reset_request_admins(context: ContextTypes.DEFAULT_TYPE, request_id: int) -> None:
    with db() as conn:
        row = conn.execute(
            """
            SELECT rr.*, k.key_value, k.reset_count, k.max_resets, p.name AS product_name, u.email
              FROM key_reset_requests rr
              JOIN keys k ON k.id=rr.key_id
              JOIN products p ON p.id=rr.product_id
              LEFT JOIN users u ON u.user_id=rr.user_id
             WHERE rr.id=?
            """,
            (request_id,),
        ).fetchone()
        admin_ids = reset_request_admin_ids(conn)
    if not row:
        return
    # Her adminin diline göre mesaj atmak için butonları her döngüde yeniden oluşturuyoruz.
    for admin_id in admin_ids:
        try:
            text = tr(
                int(admin_id),
                "reset_admin_request",
                request_id=request_id,
                user_id=int(row["user_id"]),
                email=clean(row["email"] or "-"),
                product=clean(row["product_name"]),
                key=clean(row["key_value"]),
                reset_count=int(row["reset_count"]),
                max_resets="∞",
                date=fmt_dt(row["requested_at"]),
            )
            markup = kb([[('✅ ' + tr(int(admin_id), 'reset_approve'), f'reset_approve:{request_id}'), ('❌ ' + tr(int(admin_id), 'reset_reject'), f'reset_reject:{request_id}')]])
            await context.bot.send_message(chat_id=int(admin_id), text=text, reply_markup=markup, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
        except Exception as exc:
            logger.warning("reset request admin notify failed admin=%s request=%s err=%s", admin_id, request_id, exc)


async def request_key_reset(update: Update, context: ContextTypes.DEFAULT_TYPE, key_id: int) -> None:
    user_id = update.effective_user.id
    with db() as conn:
        r = conn.execute(
            """
            SELECT k.*, p.name AS product_name
              FROM keys k JOIN products p ON p.id=k.product_id
             WHERE k.id=? AND k.owner_id=? AND k.status='sold'
            """,
            (key_id, user_id),
        ).fetchone()
        if not r:
            await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id, "my_keys"))
            return
        # Reset limiti kaldırıldı: kullanıcı her seferinde yeni reset talebi açabilir.
        pending = conn.execute(
            "SELECT id FROM key_reset_requests WHERE key_id=? AND user_id=? AND status='pending' ORDER BY id DESC LIMIT 1",
            (key_id, user_id),
        ).fetchone()
        if pending:
            await send_or_edit(update, tr(user_id, "reset_request_pending"), back_home_kb(user_id, f"key:{key_id}"))
            return
        ts = now_iso()
        cur = conn.execute(
            """
            INSERT INTO key_reset_requests(key_id, user_id, product_id, status, requested_at, note)
            VALUES(?,?,?,?,?,?)
            """,
            (key_id, user_id, int(r["product_id"]), "pending", ts, "user requested key reset"),
        )
        request_id = int(cur.lastrowid)
        add_key_event(conn, key_id, user_id, "reset_request", f"Request #{request_id} pending")
    await send_or_edit(update, tr(user_id, "reset_request_sent"), back_home_kb(user_id, f"key:{key_id}"))
    await notify_reset_request_admins(context, request_id)


async def list_reset_requests_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "keys"):
        await deny_permission(update, actor)
        return
    with db() as conn:
        rows = conn.execute(
            """
            SELECT rr.*, p.name AS product_name
              FROM key_reset_requests rr
              JOIN products p ON p.id=rr.product_id
             WHERE rr.status='pending'
             ORDER BY rr.id DESC
             LIMIT 20
            """
        ).fetchall()
    if not rows:
        await send_or_edit(update, tr(actor, "reset_requests_empty"), back_home_kb(actor, "adm_keys"))
        return
    lines = [tr(actor, "reset_requests_title")]
    btns: list[list[tuple[str, str]]] = []
    for r in rows:
        lines.append(tr(actor, "reset_request_line", request_id=int(r["id"]), user_id=int(r["user_id"]), product=clean(r["product_name"]), date=fmt_dt(r["requested_at"])))
        btns.append([("✅ " + tr(actor, "reset_approve") + f" #{r['id']}", f"reset_approve:{r['id']}"), ("❌ " + tr(actor, "reset_reject"), f"reset_reject:{r['id']}")])
    btns.append([("⬅️ " + tr(actor, "back"), "adm_keys"), ("🏠 " + tr(actor, "home"), "home")])
    await send_or_edit(update, "\n".join(lines), kb(btns))


async def approve_reset_request(update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: int) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "keys"):
        await deny_permission(update, actor)
        return
    with db() as conn:
        r = conn.execute(
            """
            SELECT rr.*, k.key_value, k.status AS key_status, k.owner_id, k.reset_count, k.max_resets, p.name AS product_name
              FROM key_reset_requests rr
              JOIN keys k ON k.id=rr.key_id
              JOIN products p ON p.id=rr.product_id
             WHERE rr.id=? AND rr.status='pending'
            """,
            (request_id,),
        ).fetchone()
        if not r:
            await send_or_edit(update, tr(actor, "reset_request_not_found"), back_home_kb(actor, "adm_keys"))
            return
        if r["key_status"] != "sold" or int(r["owner_id"] or 0) != int(r["user_id"]):
            conn.execute("UPDATE key_reset_requests SET status='rejected', processed_at=?, processed_by=?, note=? WHERE id=?", (now_iso(), actor, "key owner/status mismatch", request_id))
            await send_or_edit(update, tr(actor, "reset_request_not_found"), back_home_kb(actor, "adm_keys"))
            return
        # Reset limiti kaldırıldı: admin onayında reset sayısı sınırsız artırılır.
        new_count = int(r["reset_count"]) + 1
        ts = now_iso()
        conn.execute("UPDATE keys SET reset_count=?, updated_at=? WHERE id=?", (new_count, ts, int(r["key_id"])))
        conn.execute("UPDATE key_reset_requests SET status='approved', processed_at=?, processed_by=?, note=? WHERE id=?", (ts, actor, "approved", request_id))
        conn.execute(
            "INSERT INTO transactions(user_id, product_id, key_id, amount, type, note, created_at) VALUES(?,?,?,?,?,?,?)",
            (int(r["user_id"]), int(r["product_id"]), int(r["key_id"]), 0, "key_reset", f"Reset {new_count}/∞ approved by {actor}", ts),
        )
        add_key_event(conn, int(r["key_id"]), int(r["user_id"]), "reset_approved", f"Request #{request_id}; Reset {new_count}/∞; admin={actor}")
    try:
        await context.bot.send_message(
            chat_id=int(r["user_id"]),
            text=tr(int(r["user_id"]), "reset_user_approved", key=clean(r["key_value"]), reset_count=new_count, max_resets="∞"),
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True,
        )
    except Exception as exc:
        logger.warning("reset approve notify user failed user=%s request=%s err=%s", r["user_id"], request_id, exc)
    await send_or_edit(update, tr(actor, "reset_request_approved_admin", request_id=request_id), back_home_kb(actor, "adm_keys"))


async def reject_reset_request(update: Update, context: ContextTypes.DEFAULT_TYPE, request_id: int) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "keys"):
        await deny_permission(update, actor)
        return
    with db() as conn:
        r = conn.execute("SELECT * FROM key_reset_requests WHERE id=? AND status='pending'", (request_id,)).fetchone()
        if not r:
            await send_or_edit(update, tr(actor, "reset_request_not_found"), back_home_kb(actor, "adm_keys"))
            return
        ts = now_iso()
        conn.execute("UPDATE key_reset_requests SET status='rejected', processed_at=?, processed_by=?, note=? WHERE id=?", (ts, actor, "rejected", request_id))
        add_key_event(conn, int(r["key_id"]), int(r["user_id"]), "reset_rejected", f"Request #{request_id}; admin={actor}")
    try:
        await context.bot.send_message(chat_id=int(r["user_id"]), text=tr(int(r["user_id"]), "reset_user_rejected"), parse_mode=ParseMode.HTML)
    except Exception as exc:
        logger.warning("reset reject notify user failed user=%s request=%s err=%s", r["user_id"], request_id, exc)
    await send_or_edit(update, tr(actor, "reset_request_rejected_admin", request_id=request_id), back_home_kb(actor, "adm_keys"))

async def show_transactions(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 20",
            (user_id,),
        ).fetchall()
    if not rows:
        await send_or_edit(update, tr(user_id, "history_empty"), back_home_kb(user_id))
        return
    lines = ["🧾 <b>" + tr(user_id, "tx_history") + "</b>"]
    for r in rows:
        lines.append("\n" + tr(user_id, "tx_line", id=r["id"], type=clean(r["type"]), amount=float(r["amount"]), date=fmt_dt(r["created_at"]), note=clean(r["note"] or "-")))
    await send_or_edit(update, "\n".join(lines), back_home_kb(user_id))


async def show_balance(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    row = get_user(user_id)
    bal = float(row["balance"]) if row else 0.0
    await send_or_edit(update, tr(user_id, "balance_card", balance=bal), back_home_kb(user_id))


async def show_price_list(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    with db() as conn:
        rows = conn.execute(
            f"""
            SELECT p.*, c.name AS category_name, c.platform_key AS platform_key,
                   (SELECT COUNT(*) FROM keys k WHERE k.product_id=p.id AND k.status='stock') AS stock
              FROM products p
              JOIN categories c ON c.id=p.category_id
             WHERE p.active=1 AND c.active=1
             ORDER BY {platform_order_sql('c')}, c.id DESC, p.id DESC
             LIMIT 80
            """
        ).fetchall()
        prices = {int(r["id"]): resolve_price(conn, user_id, int(r["id"])) for r in rows}
    if not rows:
        await send_or_edit(update, tr(user_id, "no_products"), back_home_kb(user_id))
        return
    lines = ["💵 <b>" + tr(user_id, "prices") + "</b>"]
    buttons = []
    for r in rows:
        pid = int(r["id"])
        lines.append(
            f"\n#{pid} | <b>{clean(r['name'])}</b> | {clean(platform_button_label(user_id, r['platform_key'] if 'platform_key' in r.keys() else None, r['category_name']))} | "
            f"<b>${prices[pid]:.2f}</b> | {int(r['duration_days'])} gün | Stok: {int(r['stock'])}"
        )
        buttons.append([(f"🛒 #{pid} {clean(r['name'])}", f"prod:{pid}")])
    buttons.append([("🏠 " + tr(user_id, "home"), "home")])
    await send_or_edit(update, "\n".join(lines), kb(buttons))


async def show_layout(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    row = get_user(user_id)
    current = row["layout"] if row else "mobile"
    current_label = tr(user_id, "pc") if current == "pc" else tr(user_id, "mobile")
    await send_or_edit(
        update,
        tr(user_id, "layout_card", layout=current_label),
        kb([
            [("📱 " + tr(user_id, "mobile"), "set_layout:mobile"), ("💻 " + tr(user_id, "pc"), "set_layout:pc")],
            [("🏠 " + tr(user_id, "home"), "home")],
        ]),
    )


async def set_layout(update: Update, context: ContextTypes.DEFAULT_TYPE, layout: str) -> None:
    user_id = update.effective_user.id
    if layout not in ("mobile", "pc"):
        layout = "mobile"
    with db() as conn:
        conn.execute("UPDATE users SET layout=?, updated_at=? WHERE user_id=?", (layout, now_iso(), user_id))
    await send_or_edit(update, tr(user_id, "layout_set", layout=(tr(user_id, "pc") if layout == "pc" else tr(user_id, "mobile"))), main_menu_kb(user_id))


async def show_language(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    await send_or_edit(
        update,
        tr(user_id, "lang_card"),
        kb([
            [("🇹🇷 Türkçe", "set_lang:tr"), ("🇬🇧 English", "set_lang:en")],
            [("🇺🇿 O‘zbekcha", "set_lang:uz"), ("🇷🇺 Русский", "set_lang:ru")],
            [("🏠 " + tr(user_id, "home"), "home")],
        ]),
    )


async def set_language(update: Update, context: ContextTypes.DEFAULT_TYPE, lang: str) -> None:
    user_id = update.effective_user.id
    if lang not in SUPPORTED_LANGS:
        lang = DEFAULT_LANG
    with db() as conn:
        conn.execute("UPDATE users SET lang=?, updated_at=? WHERE user_id=?", (lang, now_iso(), user_id))
    if not session_active(user_id):
        await show_auth_screen(update, context)
        return
    await send_or_edit(update, tr(user_id, "lang_set"), main_menu_kb(user_id))


async def do_logout(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    with db() as conn:
        conn.execute("UPDATE users SET active_session=0, updated_at=? WHERE user_id=?", (now_iso(), user_id))
    context.user_data.clear()
    await send_or_edit(update, tr(user_id, "logged_out"))


# =========================
# ADMIN SAYFALARI
# =========================
async def show_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await send_or_edit(update, tr(user_id, "admin_only"), main_menu_kb(user_id))
        return
    counts = get_counts()
    await send_or_edit(update, tr(user_id, "admin_title", **counts), admin_menu_kb(user_id))


async def admin_resellers(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "resellers"):
        await deny_permission(update, user_id)
        return
    await send_or_edit(update, "👥 <b>" + tr(user_id, "admin_resellers") + "</b>", kb([
        [("➕ " + tr(user_id, "create_reseller"), "flow:reseller")],
        [("📋 " + tr(user_id, "list_resellers"), "adm_reseller_list")],
        [("⬅️ " + tr(user_id, "back"), "admin")],
    ]))


async def admin_prices(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "prices"):
        await deny_permission(update, user_id)
        return
    await send_or_edit(update, "💵 <b>" + tr(user_id, "admin_prices") + "</b>", kb([
        [("➕ " + tr(user_id, "set_custom_price"), "flow:price")],
        [("📋 " + tr(user_id, "list_custom_prices"), "adm_price_list")],
        [("⬅️ " + tr(user_id, "back"), "admin")],
    ]))


async def admin_keys(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "keys"):
        await deny_permission(update, user_id)
        return
    await send_or_edit(update, "🔑 <b>" + tr(user_id, "admin_keys") + "</b>", kb([
        [("➕ " + tr(user_id, "manual_key"), "flow:key_single"), ("📚 " + tr(user_id, "bulk_keys"), "flow:key_bulk")],
        [("📦 " + tr(user_id, "view_stock_keys"), "stock_platforms")],
        [("➖ " + tr(user_id, "decrease_stock"), "flow:stock_dec")],
        [("🔄 " + tr(user_id, "reset_requests"), "adm_reset_requests")],
        [("⬅️ " + tr(user_id, "back"), "admin")],
    ]))


async def admin_cats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "cats"):
        await deny_permission(update, user_id)
        return
    notice = context.user_data.pop("cat_notice", None)
    with db() as conn:
        ensure_platform_categories(conn)
        cats = conn.execute(
            f"""
            SELECT c.id, c.name, c.platform_key,
                   (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id AND p.active=1) AS product_count,
                   (SELECT COUNT(*) FROM products p JOIN keys k ON k.product_id=p.id WHERE p.category_id=c.id AND p.active=1 AND k.status='stock') AS stock_count
              FROM categories c
             WHERE c.active=1
             ORDER BY {platform_order_sql('c')}, lower(trim(c.name)) ASC, c.id ASC
            """
        ).fetchall()
    platforms = [c for c in cats if c["platform_key"]]
    custom_cats = [c for c in cats if not c["platform_key"]]

    lines: list[str] = []
    if notice:
        lines.append(notice)
        lines.append("")
    lines.append(tr(user_id, "admin_platforms_title"))
    for c in platforms:
        lines.append(
            f"\n{platform_button_label(user_id, c['platform_key'], c['name'])} | "
            f"Ürün: <b>{int(c['product_count'] or 0)}</b> | Stok key: <b>{int(c['stock_count'] or 0)}</b>"
        )
    if custom_cats:
        lines.append("\n\n📁 <b>Ek Kategoriler</b>")
        for c in custom_cats:
            lines.append(
                f"\n#<code>{int(c['id'])}</code> • {platform_button_label(user_id, None, c['name'])} | "
                f"Ürün: <b>{int(c['product_count'] or 0)}</b> | Stok key: <b>{int(c['stock_count'] or 0)}</b>"
            )
    else:
        lines.append("\n\n📁 <b>Ek Kategoriler</b>\nHenüz ek kategori yok.")

    rows: list[list[tuple[str, str]]] = []
    if has_admin_perm(user_id, "products"):
        for c in platforms:
            rows.append([(f"➕ {platform_button_label(user_id, c['platform_key'], c['name'])} • {tr(user_id, 'platform_product_add')}", f"prodadd_cat:{c['id']}")])
        for c in custom_cats:
            rows.append([(f"➕ #{int(c['id'])} • {platform_button_label(user_id, None, c['name'])} • {tr(user_id, 'platform_product_add')}", f"prodadd_cat:{c['id']}")])
    rows.append([("➕ " + tr(user_id, "add_category"), "flow:cat_add"), ("🗑 " + tr(user_id, "delete_category"), "flow:cat_del")])
    rows.append([("⬅️ " + tr(user_id, "back"), "admin")])
    await send_or_edit(update, "\n".join(lines), kb(rows))

async def admin_products(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "products"):
        await deny_permission(update, user_id)
        return
    await send_or_edit(update, "🛒 <b>" + tr(user_id, "admin_products") + "</b>", kb([
        [("➕ " + tr(user_id, "add_product"), "flow:prod_add"), ("✏️ " + tr(user_id, "edit_product"), "prodedit_start")],
        [("🗑 " + tr(user_id, "delete_product"), "flow:prod_del"), ("📋 " + tr(user_id, "list_products"), "adm_product_list")],
        [("⬅️ " + tr(user_id, "back"), "admin")],
    ]))


async def admin_balance(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await start_flow(update, context, "balance")


async def start_flow(update: Update, context: ContextTypes.DEFAULT_TYPE, flow: str) -> None:
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await send_or_edit(update, tr(user_id, "admin_only"), main_menu_kb(user_id))
        return
    prompts = {
        "reseller": "prompt_reseller",
        "price": "prompt_price",
        "key_single": "prompt_single_key",
        "key_bulk": "prompt_bulk_keys",
        "stock_dec": "prompt_decrease",
        "cat_add": "prompt_cat_add",
        "cat_del": "prompt_cat_del",
        "prod_add": "prompt_prod_add",
        "prod_del": "prompt_prod_del",
        "balance": "prompt_balance",
        "user_lookup": "prompt_user_email",
        "ban_user": "prompt_ban_user",
        "unban_user": "prompt_unban_user",
    }
    if flow not in prompts:
        await show_admin(update, context)
        return
    perm = ADMIN_FLOW_PERMS.get(flow)
    if perm and not has_admin_perm(user_id, perm):
        await deny_permission(update, user_id)
        return
    if flow == "prod_add":
        await start_product_add_wizard(update, context)
        return
    context.user_data["flow"] = flow
    await send_or_edit(update, tr(user_id, prompts[flow]), cancel_kb(user_id))


async def list_resellers(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    with db() as conn:
        rows = conn.execute(
            "SELECT user_id, username, first_name, role, parent_id, balance FROM users WHERE role IN ('distributor','seller','sub_seller') ORDER BY role, user_id LIMIT 50"
        ).fetchall()
    if not rows:
        await send_or_edit(update, tr(user_id, "reseller_list_empty"), back_home_kb(user_id, "adm_resellers"))
        return
    lines = ["👥 <b>" + tr(user_id, "list_resellers") + "</b>"]
    for r in rows:
        name = clean(r["username"] or r["first_name"] or "-")
        lines.append(f"\n<code>{r['user_id']}</code> | <b>{clean(r['role'])}</b> | @{name} | Parent: <code>{clean(r['parent_id'] or '-')}</code> | ${float(r['balance']):.2f}")
    await send_or_edit(update, "\n".join(lines), back_home_kb(user_id, "adm_resellers"))


async def list_prices(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    with db() as conn:
        rows = conn.execute(
            """
            SELECT po.*, p.name AS product_name
              FROM price_overrides po
              JOIN products p ON p.id=po.product_id
             ORDER BY po.id DESC LIMIT 50
            """
        ).fetchall()
    if not rows:
        await send_or_edit(update, tr(user_id, "history_empty"), back_home_kb(user_id, "adm_prices"))
        return
    lines = ["💵 <b>" + tr(user_id, "list_custom_prices") + "</b>"]
    for r in rows:
        lines.append(f"\n#{r['id']} | {clean(r['scope_type'])}:{clean(r['scope_value'])} | Ürün #{r['product_id']} {clean(r['product_name'])} | <b>${float(r['price']):.2f}</b>")
    await send_or_edit(update, "\n".join(lines), back_home_kb(user_id, "adm_prices"))


def safe_filename_part(value: str, fallback: str = "stok") -> str:
    """Telegram'a gönderilecek dosya adını sade ve güvenli hale getirir."""
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value or "").strip())
    value = value.strip("._-")[:60]
    return value or fallback


async def show_stock_platforms_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "keys"):
        await deny_permission(update, user_id)
        return
    with db() as conn:
        ensure_platform_categories(conn)
        rows_db = conn.execute(
            f"""
            SELECT c.id, c.name, c.platform_key,
                   (SELECT COUNT(*)
                      FROM products p
                      JOIN keys k ON k.product_id=p.id
                     WHERE p.category_id=c.id
                       AND p.active=1
                       AND k.status='stock') AS stock_count,
                   (SELECT COUNT(*)
                      FROM products p
                     WHERE p.category_id=c.id
                       AND p.active=1) AS product_count
              FROM categories c
             WHERE c.active=1
             ORDER BY {platform_order_sql('c')}, lower(trim(c.name)) ASC, c.id ASC
            """
        ).fetchall()
    buttons: list[list[tuple[str, str]]] = []
    for c in rows_db:
        stock = int(c["stock_count"] or 0)
        if stock <= 0:
            continue
        label = platform_button_label(user_id, c["platform_key"] if "platform_key" in c.keys() else None, c["name"])
        buttons.append([(f"{label} • 🔑 {stock}", f"stock_cat:{int(c['id'])}")])
    if not buttons:
        await send_or_edit(update, tr(user_id, "stock_empty"), back_home_kb(user_id, "adm_keys"))
        return
    buttons.append([("⬅️ " + tr(user_id, "back"), "adm_keys"), ("🏠 " + tr(user_id, "home"), "home")])
    await send_or_edit(update, tr(user_id, "stock_select_platform"), kb(buttons))


async def show_stock_groups_admin(update: Update, context: ContextTypes.DEFAULT_TYPE, category_id: int) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "keys"):
        await deny_permission(update, user_id)
        return
    with db() as conn:
        cat = conn.execute("SELECT id, name, platform_key FROM categories WHERE id=? AND active=1", (category_id,)).fetchone()
        products = conn.execute(
            """
            SELECT p.*,
                   (SELECT COUNT(*) FROM keys k WHERE k.product_id=p.id AND k.status='stock') AS stock
              FROM products p
             WHERE p.category_id=? AND p.active=1
             ORDER BY lower(trim(p.name)) ASC, p.duration_days ASC, p.id ASC
            """,
            (category_id,),
        ).fetchall()
    if not cat:
        await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id, "stock_platforms"))
        return
    grouped: dict[str, dict[str, Any]] = {}
    for p in products:
        stock = int(p["stock"] or 0)
        if stock <= 0:
            continue
        base = product_group_base_name(str(p["name"]))
        gkey = product_group_key(base)
        group = grouped.setdefault(gkey, {"name": base, "first_id": int(p["id"]), "packages": set(), "stock": 0})
        group["packages"].add(duration_key(int(p["duration_days"])))
        group["stock"] += stock
    if not grouped:
        await send_or_edit(update, tr(user_id, "stock_empty"), back_home_kb(user_id, "stock_platforms"))
        return
    rows: list[list[tuple[str, str]]] = []
    for group in sorted(grouped.values(), key=lambda g: product_group_key(g["name"])):
        name = str(group["name"])
        package_text = tr(user_id, "product_group_button_suffix", count=len(group["packages"]))
        label = f"{product_group_emoji(name)} {name} • 🔑 {int(group['stock'])} • {package_text}"
        rows.append([(label, f"stock_group:{category_id}:{int(group['first_id'])}")])
    cat_title = platform_button_label(user_id, cat["platform_key"] if "platform_key" in cat.keys() else None, cat["name"])
    rows.append([("⬅️ " + tr(user_id, "back"), "stock_platforms"), ("🏠 " + tr(user_id, "home"), "home")])
    await send_or_edit(update, tr(user_id, "stock_select_group", category=clean(cat_title)), kb(rows))


def get_stock_group_products(conn: sqlite3.Connection, category_id: int, sample_product_id: int) -> tuple[sqlite3.Row, sqlite3.Row, str, list[sqlite3.Row]]:
    sample = conn.execute("SELECT * FROM products WHERE id=? AND category_id=? AND active=1", (sample_product_id, category_id)).fetchone()
    cat = conn.execute("SELECT id, name, platform_key FROM categories WHERE id=? AND active=1", (category_id,)).fetchone()
    if not sample or not cat:
        raise ValueError("not found")
    group_name = product_group_base_name(str(sample["name"]))
    all_products = conn.execute(
        """
        SELECT p.*,
               (SELECT COUNT(*) FROM keys k WHERE k.product_id=p.id AND k.status='stock') AS stock
          FROM products p
         WHERE p.category_id=? AND p.active=1
         ORDER BY
            CASE
                WHEN p.duration_days=1 THEN 1
                WHEN p.duration_days=7 THEN 2
                WHEN p.duration_days IN (30,31) THEN 3
                ELSE 4
            END, p.duration_days ASC, p.id ASC
        """,
        (category_id,),
    ).fetchall()
    products = [p for p in all_products if product_group_key(str(p["name"])) == product_group_key(group_name) and int(p["stock"] or 0) > 0]
    return cat, sample, group_name, products


async def show_stock_packages_admin(update: Update, context: ContextTypes.DEFAULT_TYPE, category_id: int, sample_product_id: int) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "keys"):
        await deny_permission(update, user_id)
        return
    try:
        with db() as conn:
            cat, _sample, group_name, products = get_stock_group_products(conn, category_id, sample_product_id)
    except Exception:
        await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id, f"stock_cat:{category_id}"))
        return
    if not products:
        await send_or_edit(update, tr(user_id, "stock_empty"), back_home_kb(user_id, f"stock_cat:{category_id}"))
        return
    rows: list[list[tuple[str, str]]] = []
    for p in products:
        days = int(p["duration_days"])
        label = package_label_for_days(user_id, days)
        stock = int(p["stock"] or 0)
        rows.append([(f"{package_emoji(days)} {label} • 🔑 {stock} • TXT", f"stock_pkg:{int(p['id'])}")])
    cat_title = platform_button_label(user_id, cat["platform_key"] if "platform_key" in cat.keys() else None, cat["name"])
    rows.append([("⬅️ " + tr(user_id, "back"), f"stock_cat:{category_id}"), ("🏠 " + tr(user_id, "home"), "home")])
    await send_or_edit(
        update,
        tr(user_id, "stock_select_package", category=clean(cat_title), name=clean(f"{product_group_emoji(group_name)} {group_name}")),
        kb(rows),
    )


async def send_stock_keys_txt_admin(update: Update, context: ContextTypes.DEFAULT_TYPE, product_id: int) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "keys"):
        await deny_permission(update, user_id)
        return
    with db() as conn:
        product = conn.execute(
            """
            SELECT p.*, c.name AS category_name, c.platform_key AS platform_key
              FROM products p
              JOIN categories c ON c.id=p.category_id
             WHERE p.id=? AND p.active=1 AND c.active=1
            """,
            (product_id,),
        ).fetchone()
        key_rows = conn.execute(
            """
            SELECT id, key_value, created_at, added_by
              FROM keys
             WHERE product_id=? AND status='stock'
             ORDER BY id ASC
            """,
            (product_id,),
        ).fetchall()
    if not product:
        await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id, "adm_keys"))
        return
    if not key_rows:
        await send_or_edit(update, tr(user_id, "stock_empty"), back_home_kb(user_id, "adm_keys"))
        return

    days = int(product["duration_days"])
    package = package_label_for_days(user_id, days)
    category = platform_button_label(user_id, product["platform_key"] if "platform_key" in product.keys() else None, product["category_name"])
    product_name = product_group_base_name(str(product["name"]))
    generated = fmt_dt(now_iso())
    header = [
        "JERRY BOT - STOK KEY LISTESI",
        f"Platform/Kategori: {category}",
        f"Urun: {product_name}",
        f"Paket: {package} ({days} gun)",
        f"Product ID: {product_id}",
        f"Stok Adedi: {len(key_rows)}",
        f"Olusturma: {generated}",
        "",
        "KEYLER",
        "------",
    ]
    body = [f"{idx}. {row['key_value']}" for idx, row in enumerate(key_rows, start=1)]
    txt = "\n".join(header + body) + "\n"
    filename = f"stok_{safe_filename_part(category, 'kategori')}_{safe_filename_part(product_name, 'urun')}_{safe_filename_part(package, 'paket')}_p{product_id}.txt"
    payload = io.BytesIO(txt.encode("utf-8"))
    payload.name = filename

    caption = tr(user_id, "stock_txt_caption")
    target_message = update.callback_query.message if update.callback_query else update.effective_message
    if target_message:
        await target_message.reply_document(document=payload, filename=filename, caption=caption)
    await send_or_edit(
        update,
        tr(user_id, "stock_keys_sent", product=clean(product_name), package=clean(package), count=len(key_rows)),
        kb([
            [("⬅️ " + tr(user_id, "back"), f"stock_group:{int(product['category_id'])}:{product_id}")],
            [("📦 " + tr(user_id, "view_stock_keys"), "stock_platforms"), ("🏠 " + tr(user_id, "home"), "home")],
        ]),
    )


async def list_products_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    with db() as conn:
        rows = conn.execute(
            """
            SELECT p.*, c.name AS category_name, c.platform_key AS platform_key,
                   (SELECT COUNT(*) FROM keys k WHERE k.product_id=p.id AND k.status='stock') AS stock
              FROM products p JOIN categories c ON c.id=p.category_id
             WHERE p.active=1 AND c.active=1
             ORDER BY p.id DESC LIMIT 60
            """
        ).fetchall()
    if not rows:
        await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id, "adm_products"))
        return
    lines = ["🛒 <b>" + tr(user_id, "list_products") + "</b>"]
    for r in rows:
        cat_name = platform_button_label(user_id, r["platform_key"] if "platform_key" in r.keys() else None, r["category_name"])
        lines.append(f"\n✅ ID <code>{r['id']}</code> | {clean(r['name'])} | Cat: {clean(cat_name)} | ${float(r['base_price']):.2f} | {int(r['duration_days'])}g | Stok: {r['stock']}")
    await send_or_edit(update, "\n".join(lines), back_home_kb(user_id, "adm_products"))


async def product_history_admin(update: Update, context: ContextTypes.DEFAULT_TYPE, page: int = 0) -> None:
    """Admin ürün geçmişini Telegram mesaj limitine takılmadan sayfalı gösterir."""
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "history"):
        await deny_permission(update, user_id)
        return

    page = max(0, int(page or 0))
    per_page = 12
    offset = page * per_page

    try:
        with db() as conn:
            total = int(conn.execute("SELECT COUNT(*) FROM product_history").fetchone()[0])
            rows = conn.execute(
                """
                SELECT id, product_id, actor_id, action, details, created_at
                  FROM product_history
                 ORDER BY id DESC
                 LIMIT ? OFFSET ?
                """,
                (per_page, offset),
            ).fetchall()
    except sqlite3.Error as exc:
        logger.exception("Product history could not be loaded")
        await send_or_edit(
            update,
            "📜 <b>" + tr(user_id, "admin_history") + "</b>\n\n"
            "⚠️ Ürün geçmişi okunamadı. Veritabanı tablosu eksik veya eski olabilir.\n"
            f"Hata: <code>{clean(exc)}</code>",
            back_home_kb(user_id, "admin"),
        )
        return

    if total <= 0 or not rows:
        await send_or_edit(update, tr(user_id, "history_empty"), back_home_kb(user_id, "admin"))
        return

    max_page = max(0, (total - 1) // per_page)
    if page > max_page:
        await product_history_admin(update, context, max_page)
        return

    lines = [
        "📜 <b>" + tr(user_id, "admin_history") + "</b>",
        f"Sayfa: <b>{page + 1}/{max_page + 1}</b> | Toplam kayıt: <b>{total}</b>",
    ]
    for r in rows:
        product_id = clean(r["product_id"] if r["product_id"] is not None else "-")
        actor_id = clean(r["actor_id"] if r["actor_id"] is not None else "-")
        details = clean(r["details"] or "-")
        if len(details) > 180:
            details = details[:177] + "..."
        lines.append(
            f"#{r['id']} | Ürün: <code>{product_id}</code> | İşlem: <b>{clean(r['action'])}</b>\n"
            f"Aktör: <code>{actor_id}</code> | Tarih: {fmt_dt(r['created_at'])}\n"
            f"{details}"
        )

    nav: list[tuple[str, str]] = []
    if page > 0:
        nav.append(("⬅️ Önceki", f"hist_page:{page - 1}"))
    if page < max_page:
        nav.append(("Sonraki ➡️", f"hist_page:{page + 1}"))

    buttons: list[list[tuple[str, str]]] = []
    if nav:
        buttons.append(nav)
    buttons.append([("⬅️ " + tr(user_id, "back"), "admin")])

    await send_or_edit(update, "\n\n".join(lines), kb(buttons))



async def admin_users_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "users"):
        await deny_permission(update, user_id)
        return
    await send_or_edit(update, tr(user_id, "admin_users_menu"), kb([
        [("🔎 " + tr(user_id, "manage_user_by_email"), "flow:user_lookup")],
        [("📋 " + tr(user_id, "list_users"), "adm_user_list"), ("⛔ " + tr(user_id, "ban_unban"), "adm_bans")],
        [("⬅️ " + tr(user_id, "back"), "admin")],
    ]))


async def admin_bans_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "users"):
        await deny_permission(update, user_id)
        return
    await send_or_edit(update, "⛔ <b>Ban / Unban</b>", kb([
        [("⛔ Ban", "flow:ban_user"), ("✅ Unban", "flow:unban_user")],
        [("📋 " + tr(user_id, "ban_list"), "adm_ban_list")],
        [("⬅️ " + tr(user_id, "back"), "adm_users")],
    ]))


async def list_users_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "users"):
        await deny_permission(update, user_id)
        return
    with db() as conn:
        rows = conn.execute("SELECT * FROM users ORDER BY updated_at DESC LIMIT 60").fetchall()
    lines = ["👤 <b>" + tr(user_id, "admin_users") + "</b>"]
    for r in rows:
        name = clean(r["username"] or r["first_name"] or "-")
        approved = "✅" if int(r["approved"] or 0) == 1 else "⏳"
        lines.append(f"\n{approved} <code>{r['user_id']}</code> | {clean(r['email'] or '-')} | @{name} | <b>{clean(r['role'])}</b> | ${float(r['balance']):.2f} | Session: {r['active_session']}")
    await send_or_edit(update, "\n".join(lines), back_home_kb(user_id, "adm_users"))


async def seed_demo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await send_or_edit(update, tr(user_id, "admin_only"), main_menu_kb(user_id))
        return
    if not has_admin_perm(user_id, "seed"):
        await deny_permission(update, user_id)
        return
    with db() as conn:
        ts = now_iso()
        ensure_platform_categories(conn)
        row = conn.execute("SELECT id FROM categories WHERE platform_key='android'").fetchone()
        cat_id = int(row["id"])
        cur = conn.execute(
            """
            INSERT INTO products(category_id, name, description, duration_days, base_price, active, created_at, updated_at)
            VALUES(?,?,?,?,?,1,?,?)
            """,
            (cat_id, "Demo Ürün 30 Gün", "Test satış ürünü", 30, 10.0, ts, ts),
        )
        prod_id = cur.lastrowid
        for i in range(1, 4):
            key_value = f"JERRY-DEMO-{prod_id}-{i:03d}"
            try:
                conn.execute(
                    "INSERT INTO keys(product_id, key_value, status, max_resets, added_by, created_at, updated_at) VALUES(?,?,?,?,?,?,?)",
                    (prod_id, key_value, "stock", 0, user_id, ts, ts),
                )
            except sqlite3.IntegrityError:
                pass
        add_product_history(conn, prod_id, user_id, "seed_demo", "Demo category/product/3 keys created")
    await send_or_edit(update, tr(user_id, "seeded"), admin_menu_kb(user_id))


# =========================
# GİRİŞ / KAYIT FLOW İŞLEME
# =========================
async def handle_auth_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, flow: str) -> None:
    row = ensure_user(update, login=None)
    user_id = int(row["user_id"])
    try:
        if flow == "auth_register_email":
            email = normalize_email(text)
            if not valid_email(email):
                await send_or_edit(update, tr(user_id, "auth_bad_email"), auth_cancel_kb(user_id))
                return
            with db() as conn:
                exists = conn.execute("SELECT user_id FROM users WHERE lower(email)=lower(?) AND user_id<>?", (email, user_id)).fetchone()
            if exists:
                await send_or_edit(update, tr(user_id, "auth_email_used"), auth_cancel_kb(user_id))
                return
            context.user_data["auth_email"] = email
            context.user_data["flow"] = "auth_register_password"
            await send_or_edit(update, tr(user_id, "auth_password_prompt"), auth_cancel_kb(user_id))
            return

        if flow == "auth_register_password":
            password = text.strip()
            if len(password) < 6:
                await send_or_edit(update, tr(user_id, "auth_bad_password"), auth_cancel_kb(user_id))
                return
            email = normalize_email(str(context.user_data.get("auth_email") or ""))
            if not valid_email(email):
                context.user_data.clear()
                await start_auth_register(update, context)
                return
            ts = now_iso()
            with db() as conn:
                exists = conn.execute("SELECT user_id FROM users WHERE lower(email)=lower(?) AND user_id<>?", (email, user_id)).fetchone()
                if exists:
                    await send_or_edit(update, tr(user_id, "auth_email_used"), auth_cancel_kb(user_id))
                    return
                final_role = "admin" if user_id in ADMIN_IDS else row["role"]
                conn.execute(
                    """
                    UPDATE users
                       SET email=?, password_hash=?, password_updated_at=?, last_login_at=?, active_session=1, role=?, updated_at=?
                     WHERE user_id=?
                    """,
                    (email, hash_password(password), ts, ts, final_role, ts, user_id),
                )
            context.user_data.clear()
            await send_or_edit(update, tr(user_id, "auth_registered_ok"))
            await show_home(update, context)
            return

        if flow == "auth_login_email":
            email = normalize_email(text)
            if not valid_email(email):
                await send_or_edit(update, tr(user_id, "auth_bad_email"), auth_cancel_kb(user_id))
                return
            context.user_data["auth_email"] = email
            context.user_data["flow"] = "auth_login_password"
            await send_or_edit(update, tr(user_id, "auth_password_prompt"), auth_cancel_kb(user_id))
            return

        if flow == "auth_login_password":
            email = normalize_email(str(context.user_data.get("auth_email") or ""))
            password = text.strip()
            with db() as conn:
                account = conn.execute("SELECT * FROM users WHERE user_id=? AND lower(email)=lower(?)", (user_id, email)).fetchone()
                if not account or not verify_password(password, account["password_hash"]):
                    context.user_data.clear()
                    await show_auth_screen(update, context, "auth_login_failed")
                    return
                ts = now_iso()
                final_role = "admin" if user_id in ADMIN_IDS else account["role"]
                conn.execute("UPDATE users SET active_session=1, last_login_at=?, role=?, updated_at=? WHERE user_id=?", (ts, final_role, ts, user_id))
            context.user_data.clear()
            await send_or_edit(update, tr(user_id, "auth_login_ok"))
            await show_home(update, context)
            return

        if flow == "auth_forgot_newpass":
            password = text.strip()
            if len(password) < 6:
                await send_or_edit(update, tr(user_id, "auth_bad_password"), auth_cancel_kb(user_id))
                return
            with db() as conn:
                account = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
                if not has_auth_account(account):
                    context.user_data.clear()
                    await show_auth_screen(update, context, "auth_no_account")
                    return
                ts = now_iso()
                conn.execute("UPDATE users SET password_hash=?, password_updated_at=?, last_login_at=?, active_session=1, updated_at=? WHERE user_id=?", (hash_password(password), ts, ts, ts, user_id))
            context.user_data.clear()
            await send_or_edit(update, tr(user_id, "auth_reset_ok"))
            await show_home(update, context)
            return

        await show_auth_screen(update, context)
    finally:
        # Şifre mesajını Telegram'dan silemeyebiliriz; yine de bot hafızasında tutmuyoruz.
        pass


# =========================
# ADMIN FLOW İŞLEME
# =========================
async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    row = ensure_user(update, login=None)
    user_id = row["user_id"]
    if is_banned_id(user_id):
        await send_or_edit(update, tr(user_id, "banned_msg", user_id=user_id))
        return
    flow = context.user_data.get("flow")
    text = update.effective_message.text.strip() if update.effective_message and update.effective_message.text else ""
    if flow in {"auth_register_email", "auth_register_password", "auth_login_email", "auth_login_password", "auth_forgot_newpass"}:
        await handle_auth_text(update, context, text, str(flow))
        return
    if not session_active(user_id):
        await show_auth_screen(update, context, "auth_required")
        return
    if not is_approved_user(user_id):
        await send_or_edit(update, tr(user_id, "auth_pending", user_id=user_id), kb([[ ("🚪 " + tr(user_id, "logout"), "logout"), ("🌐 " + tr(user_id, "language"), "language") ]]))
        return
    if not flow:
        await send_or_edit(update, tr(user_id, "unknown"), main_menu_kb(user_id))
        return
    if not is_admin(user_id):
        context.user_data.clear()
        await send_or_edit(update, tr(user_id, "admin_only"), main_menu_kb(user_id))
        return
    try:
        if flow == "reseller":
            await flow_reseller(update, context, text)
        elif flow == "price":
            await flow_price(update, context, text)
        elif flow == "key_single":
            await flow_key_single(update, context, text)
        elif flow == "key_bulk":
            await flow_key_bulk(update, context, text)
        elif flow == "stock_dec":
            await flow_stock_dec(update, context, text)
        elif flow == "cat_add":
            await flow_cat_add(update, context, text)
        elif flow == "cat_del":
            await flow_cat_del(update, context, text)
        elif flow == "prod_add_wizard":
            await flow_prod_add_wizard(update, context, text)
        elif flow == "prod_add":
            await flow_prod_add(update, context, text)
        elif flow == "prod_del":
            await flow_prod_del(update, context, text)
        elif flow == "prod_edit_price":
            await flow_product_edit_price(update, context, text)
        elif flow == "balance":
            await flow_balance(update, context, text)
        elif flow == "user_lookup":
            await flow_user_lookup(update, context, text)
        elif flow == "ban_user":
            await flow_ban_user(update, context, text)
        elif flow == "unban_user":
            await flow_unban_user(update, context, text)
        else:
            context.user_data.clear()
            await show_admin(update, context)
    except Exception as exc:
        logger.warning("flow error: %s", exc)
        await send_or_edit(update, tr(user_id, "bad_format"), cancel_kb(user_id))



def get_user_by_email(email: str) -> Optional[sqlite3.Row]:
    email = normalize_email(email)
    with db() as conn:
        return conn.execute("SELECT * FROM users WHERE lower(email)=lower(?)", (email,)).fetchone()


def set_admin_permissions(conn: sqlite3.Connection, target_id: int, perms: set[str]) -> None:
    clean_perms = [p for p in PERMISSION_ORDER if p in perms]
    conn.execute("UPDATE users SET admin_permissions=?, updated_at=? WHERE user_id=?", (",".join(clean_perms), now_iso(), target_id))


async def flow_user_lookup(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "users"):
        await deny_permission(update, actor)
        return
    email = normalize_email(text)
    if not valid_email(email):
        await send_or_edit(update, tr(actor, "auth_bad_email"), cancel_kb(actor))
        return
    row = get_user_by_email(email)
    if not row:
        context.user_data.clear()
        await send_or_edit(update, tr(actor, "user_not_found_email"), admin_menu_kb(actor))
        return
    context.user_data.clear()
    await show_admin_user_detail(update, context, int(row["user_id"]))


async def show_admin_user_detail(update: Update, context: ContextTypes.DEFAULT_TYPE, target_id: int) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "users"):
        await deny_permission(update, actor)
        return
    row = get_user(target_id)
    if not row:
        await send_or_edit(update, tr(actor, "not_found"), back_home_kb(actor, "adm_users"))
        return
    approved = tr(actor, "approved_yes") if int(row["approved"] or 0) == 1 else tr(actor, "approved_no")
    perms = permission_names(row["admin_permissions"] if "admin_permissions" in row.keys() else "") if row["role"] == "admin" else "-"
    text = tr(actor, "user_detail", user_id=target_id, email=clean(row["email"] or "-"), role=clean(row["role"]), approved=approved, balance=float(row["balance"]), perms=clean(perms))
    rows: list[list[tuple[str, str]]] = []
    if target_id not in ADMIN_IDS:
        if int(row["approved"] or 0) == 1:
            rows.append([("❌ " + tr(actor, "unapprove_user"), f"user_approve:{target_id}:0")])
        else:
            rows.append([("✅ " + tr(actor, "approve_user"), f"user_approve:{target_id}:1")])
        rows.append([
            ("👤 " + tr(actor, "set_customer"), f"user_role:{target_id}:customer"),
            ("🧩 " + tr(actor, "set_sub_seller"), f"user_role:{target_id}:sub_seller"),
        ])
        rows.append([
            ("🏪 " + tr(actor, "set_seller"), f"user_role:{target_id}:seller"),
            ("🏢 " + tr(actor, "set_distributor"), f"user_role:{target_id}:distributor"),
        ])
        if is_owner(actor):
            rows.append([("🛡 " + tr(actor, "set_admin"), f"user_role:{target_id}:admin")])
        if is_owner(actor) and row["role"] == "admin":
            rows.append([("🔐 " + tr(actor, "edit_permissions"), f"user_perms:{target_id}")])
        rows.append([("⛔ Ban", f"user_ban:{target_id}")])
    rows.append([("⬅️ " + tr(actor, "back"), "adm_users"), ("🏠 " + tr(actor, "home"), "home")])
    await send_or_edit(update, text, kb(rows))


async def set_user_approval(update: Update, context: ContextTypes.DEFAULT_TYPE, target_id: int, approved: int) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "users"):
        await deny_permission(update, actor)
        return
    if target_id in ADMIN_IDS:
        await send_or_edit(update, tr(actor, "owner_protected"), back_home_kb(actor, "adm_users"))
        return
    with db() as conn:
        conn.execute("UPDATE users SET approved=?, updated_at=? WHERE user_id=?", (1 if approved else 0, now_iso(), target_id))
        conn.execute("INSERT INTO transactions(user_id, amount, type, note, created_at) VALUES(?,?,?,?,?)", (target_id, 0, "approval_update", f"approved={approved} by {actor}", now_iso()))
    await show_admin_user_detail(update, context, target_id)


async def set_user_role_inline(update: Update, context: ContextTypes.DEFAULT_TYPE, target_id: int, role: str) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "users"):
        await deny_permission(update, actor)
        return
    if target_id in ADMIN_IDS:
        await send_or_edit(update, tr(actor, "owner_protected"), back_home_kb(actor, "adm_users"))
        return
    role = normalize_role(role)
    if role == "admin" and not is_owner(actor):
        await send_or_edit(update, tr(actor, "not_owner_for_admin"), back_home_kb(actor, f"manage_user:{target_id}"))
        return
    if role == "customer" and not is_owner(actor):
        # Yetkili admin müşteriye düşürebilir, sorun yok.
        pass
    approved = 1 if role in ("sub_seller", "seller", "distributor", "admin") else 0
    with db() as conn:
        current = conn.execute("SELECT * FROM users WHERE user_id=?", (target_id,)).fetchone()
        if not current:
            await send_or_edit(update, tr(actor, "not_found"), back_home_kb(actor, "adm_users"))
            return
        perms = current["admin_permissions"] if role == "admin" else ""
        conn.execute("UPDATE users SET role=?, approved=?, admin_permissions=?, updated_at=? WHERE user_id=?", (role, approved, perms, now_iso(), target_id))
        conn.execute("INSERT INTO transactions(user_id, amount, type, note, created_at) VALUES(?,?,?,?,?)", (target_id, 0, "role_update", f"role={role} approved={approved} by {actor}", now_iso()))
    await show_admin_user_detail(update, context, target_id)


async def show_user_permissions(update: Update, context: ContextTypes.DEFAULT_TYPE, target_id: int) -> None:
    actor = update.effective_user.id
    if not is_owner(actor):
        await send_or_edit(update, tr(actor, "not_owner_for_admin"), back_home_kb(actor, f"manage_user:{target_id}"))
        return
    row = get_user(target_id)
    if not row or row["role"] != "admin":
        await send_or_edit(update, tr(actor, "not_found"), back_home_kb(actor, "adm_users"))
        return
    current = admin_perm_set(row)
    lines = [tr(actor, "permissions_title", user_id=target_id, email=clean(row["email"] or "-"))]
    rows: list[list[tuple[str, str]]] = []
    for perm in PERMISSION_ORDER:
        state = "✅" if perm in current else "❌"
        state_text = tr(actor, "perm_on") if perm in current else tr(actor, "perm_off")
        rows.append([(f"{state} {ADMIN_PERMISSIONS[perm]} • {state_text}", f"perm_toggle:{target_id}:{perm}")])
    rows.append([("⬅️ " + tr(actor, "back"), f"manage_user:{target_id}"), ("🏠 " + tr(actor, "home"), "home")])
    await send_or_edit(update, "\n".join(lines), kb(rows))


async def toggle_user_permission(update: Update, context: ContextTypes.DEFAULT_TYPE, target_id: int, perm: str) -> None:
    actor = update.effective_user.id
    if not is_owner(actor):
        await send_or_edit(update, tr(actor, "not_owner_for_admin"), back_home_kb(actor, f"manage_user:{target_id}"))
        return
    if perm not in ADMIN_PERMISSIONS:
        await send_or_edit(update, tr(actor, "not_found"), back_home_kb(actor, f"manage_user:{target_id}"))
        return
    with db() as conn:
        row = conn.execute("SELECT * FROM users WHERE user_id=? AND role='admin'", (target_id,)).fetchone()
        if not row:
            await send_or_edit(update, tr(actor, "not_found"), back_home_kb(actor, "adm_users"))
            return
        perms = admin_perm_set(row)
        if perm in perms:
            perms.remove(perm)
        else:
            perms.add(perm)
        set_admin_permissions(conn, target_id, perms)
    await show_user_permissions(update, context, target_id)


def ban_user_db(actor: int, target_id: int, reason: str) -> None:
    if target_id in ADMIN_IDS:
        raise PermissionError("owner protected")
    with db() as conn:
        ts = now_iso()
        conn.execute(
            "INSERT INTO banned_users(user_id, reason, banned_by, created_at) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET reason=excluded.reason, banned_by=excluded.banned_by, created_at=excluded.created_at",
            (target_id, reason, actor, ts),
        )
        conn.execute("DELETE FROM users WHERE user_id=?", (target_id,))
        conn.execute("INSERT INTO transactions(user_id, amount, type, note, created_at) VALUES(?,?,?,?,?)", (target_id, 0, "ban", f"reason={reason}; by={actor}", ts))


async def flow_ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "users"):
        await deny_permission(update, actor)
        return
    parts = split_pipe(text, 1)
    target_id = int(parts[0])
    reason = parts[1] if len(parts) > 1 and parts[1] else "Admin ban"
    try:
        ban_user_db(actor, target_id, reason)
    except PermissionError:
        await send_or_edit(update, tr(actor, "owner_protected"), back_home_kb(actor, "adm_bans"))
        return
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "ban_ok", user_id=target_id), back_home_kb(actor, "adm_bans"))


async def ban_user_inline(update: Update, context: ContextTypes.DEFAULT_TYPE, target_id: int) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "users"):
        await deny_permission(update, actor)
        return
    try:
        ban_user_db(actor, target_id, "Inline admin ban")
    except PermissionError:
        await send_or_edit(update, tr(actor, "owner_protected"), back_home_kb(actor, "adm_users"))
        return
    await send_or_edit(update, tr(actor, "ban_ok", user_id=target_id), back_home_kb(actor, "adm_users"))


async def flow_unban_user(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "users"):
        await deny_permission(update, actor)
        return
    target_id = int(text.strip().split()[0])
    with db() as conn:
        conn.execute("DELETE FROM banned_users WHERE user_id=?", (target_id,))
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "unban_ok", user_id=target_id), back_home_kb(actor, "adm_bans"))


async def list_banned_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "users"):
        await deny_permission(update, actor)
        return
    with db() as conn:
        rows = conn.execute("SELECT * FROM banned_users ORDER BY created_at DESC LIMIT 80").fetchall()
    if not rows:
        await send_or_edit(update, tr(actor, "ban_list_empty"), back_home_kb(actor, "adm_bans"))
        return
    lines = ["⛔ <b>" + tr(actor, "ban_list") + "</b>"]
    for r in rows:
        lines.append(f"\n<code>{r['user_id']}</code> | Sebep: {clean(r['reason'] or '-')} | Admin: <code>{clean(r['banned_by'] or '-')}</code> | {fmt_dt(r['created_at'])}")
    await send_or_edit(update, "\n".join(lines), back_home_kb(actor, "adm_bans"))


async def flow_reseller(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    parts = split_pipe(text, 2)
    first = parts[0].strip()
    if "@" in first:
        row = get_user_by_email(first)
        if not row:
            raise ValueError("email not found")
        target_id = int(row["user_id"])
    else:
        target_id = int(first)
    role = normalize_role(parts[1])
    if role == "admin" or role == "customer":
        raise ValueError("role not allowed")
    parent = None
    if len(parts) >= 3 and parts[2]:
        parent = int(parts[2])
    with db() as conn:
        upsert_user_raw(conn, target_id, None, None, role=role, active_session=1)
        conn.execute("UPDATE users SET role=?, parent_id=?, approved=1, updated_at=? WHERE user_id=?", (role, parent, now_iso(), target_id))
        conn.execute(
            "INSERT INTO transactions(user_id, amount, type, note, created_at) VALUES(?,?,?,?,?)",
            (target_id, 0, "role_update", f"Role set to {role} by admin {actor}", now_iso()),
        )
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "reseller_ok", user_id=target_id, role=clean(role), parent=clean(parent or "-")), admin_menu_kb(actor))


async def flow_price(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    scope, value, product_id_s, price_s = split_pipe(text, 4)[:4]
    scope = scope.lower().strip()
    if scope not in ("user", "role"):
        raise ValueError("bad scope")
    product_id = int(product_id_s)
    price = float(price_s.replace(",", "."))
    if price < 0:
        raise ValueError("bad price")
    if scope == "role":
        value = normalize_role(value)
        if value not in ("distributor", "seller", "sub_seller"):
            raise ValueError("bad role")
    else:
        value = str(int(value))
    with db() as conn:
        p = product_by_id(conn, product_id)
        if not p:
            raise ValueError("product not found")
        ts = now_iso()
        conn.execute(
            """
            INSERT INTO price_overrides(scope_type, scope_value, product_id, price, created_at, updated_at)
            VALUES(?,?,?,?,?,?)
            ON CONFLICT(scope_type, scope_value, product_id)
            DO UPDATE SET price=excluded.price, updated_at=excluded.updated_at
            """,
            (scope, value, product_id, price, ts, ts),
        )
        add_product_history(conn, product_id, actor, "price_override", f"{scope}:{value} => ${price:.2f}")
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "price_ok", scope=clean(scope), value=clean(value), product_id=product_id, price=price), admin_menu_kb(actor))


async def flow_key_single(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    product_id_s, key_value = split_pipe(text, 2)[:2]
    count, skipped = add_keys_to_stock(actor, int(product_id_s), [key_value])
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "key_add_ok", count=count, skipped=skipped), admin_menu_kb(actor))


async def flow_key_bulk(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    if len(lines) < 2:
        raise ValueError("bad bulk")
    product_id = int(lines[0])
    keys = lines[1:]
    count, skipped = add_keys_to_stock(actor, product_id, keys)
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "key_add_ok", count=count, skipped=skipped), admin_menu_kb(actor))


def add_keys_to_stock(actor: int, product_id: int, keys: list[str]) -> tuple[int, int]:
    cleaned = []
    seen = set()
    for k in keys:
        k = k.strip()
        if not k or k in seen:
            continue
        seen.add(k)
        cleaned.append(k)
    added = 0
    skipped = 0
    with db() as conn:
        p = product_by_id(conn, product_id)
        if not p or not p["active"]:
            raise ValueError("product not found")
        ts = now_iso()
        for key_value in cleaned:
            try:
                cur = conn.execute(
                    "INSERT INTO keys(product_id, key_value, status, max_resets, added_by, created_at, updated_at) VALUES(?,?,?,?,?,?,?)",
                    (product_id, key_value, "stock", 0, actor, ts, ts),
                )
                added += 1
                add_key_event(conn, cur.lastrowid, actor, "stock_add", "Manual/bulk stock add")
            except sqlite3.IntegrityError:
                skipped += 1
        add_product_history(conn, product_id, actor, "stock_add", f"Added={added}, skipped={skipped}")
    return added, skipped


async def flow_stock_dec(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    product_id_s, qty_s, *rest = split_pipe(text, 2)
    product_id = int(product_id_s)
    qty = max(0, int(qty_s))
    reason = rest[0] if rest else "manual decrease"
    removed = 0
    with db() as conn:
        p = product_by_id(conn, product_id)
        if not p:
            raise ValueError("product not found")
        rows = conn.execute("SELECT id FROM keys WHERE product_id=? AND status='stock' ORDER BY id ASC LIMIT ?", (product_id, qty)).fetchall()
        for r in rows:
            conn.execute("UPDATE keys SET status='disabled', notes=?, updated_at=? WHERE id=?", (reason, now_iso(), r["id"]))
            add_key_event(conn, r["id"], actor, "stock_decrease", reason)
            removed += 1
        add_product_history(conn, product_id, actor, "stock_decrease", f"Removed={removed}; reason={reason}")
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "stock_dec_ok", count=removed), admin_menu_kb(actor))


async def flow_cat_add(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    parts = split_pipe(text, 1)
    name = parts[0].strip()
    desc = parts[1].strip() if len(parts) > 1 else ""
    if not name:
        raise ValueError("category name is empty")
    platform_key = platform_key_from_name(name)
    with db() as conn:
        if platform_key:
            existing = conn.execute("SELECT id FROM categories WHERE platform_key=?", (platform_key,)).fetchone()
            if existing:
                conn.execute("UPDATE categories SET active=1, name=?, description=COALESCE(NULLIF(?, ''), description) WHERE id=?", (platform_base_name(platform_key), desc, existing["id"]))
                cat_id = int(existing["id"])
            else:
                cur = conn.execute("INSERT INTO categories(name, description, active, created_at, platform_key) VALUES(?,?,1,?,?)", (platform_base_name(platform_key), desc, now_iso(), platform_key))
                cat_id = int(cur.lastrowid)
        else:
            cur = conn.execute("INSERT INTO categories(name, description, active, created_at, platform_key) VALUES(?,?,1,?,NULL)", (name, desc, now_iso()))
            cat_id = int(cur.lastrowid)
        add_product_history(conn, None, actor, "category_add", f"Category #{cat_id}: {name}")
    context.user_data.clear()
    context.user_data["cat_notice"] = tr(actor, "cat_ok", id=cat_id)
    await admin_cats(update, context)


async def flow_cat_del(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    cat_id = int(text.strip())
    with db() as conn:
        row = conn.execute("SELECT platform_key FROM categories WHERE id=?", (cat_id,)).fetchone()
        if not row:
            raise ValueError("not found")
        if row["platform_key"]:
            context.user_data.clear()
            await send_or_edit(update, tr(actor, "platform_protected"), admin_menu_kb(actor))
            return
        cur = conn.execute("UPDATE categories SET active=0 WHERE id=?", (cat_id,))
        if cur.rowcount == 0:
            raise ValueError("not found")
        conn.execute("UPDATE products SET active=0, updated_at=? WHERE category_id=?", (now_iso(), cat_id))
        add_product_history(conn, None, actor, "category_delete", f"Category #{cat_id} disabled with products")
    context.user_data.clear()
    context.user_data["cat_notice"] = tr(actor, "cat_deleted")
    await admin_cats(update, context)




async def start_product_add_wizard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Ürün eklemeyi tek tek soran basit admin sihirbazı."""
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await send_or_edit(update, tr(user_id, "admin_only"), main_menu_kb(user_id))
        return
    if not has_admin_perm(user_id, "products"):
        await deny_permission(update, user_id)
        return
    with db() as conn:
        ensure_platform_categories(conn)
        cats = conn.execute(
            f"""
            SELECT id, name, platform_key
              FROM categories
             WHERE active=1
             ORDER BY {platform_order_sql('categories')}, id DESC
             LIMIT 80
            """
        ).fetchall()
    if not cats:
        context.user_data.clear()
        await send_or_edit(update, tr(user_id, "prod_wizard_no_cat"), kb([
            [("➕ " + tr(user_id, "add_category"), "flow:cat_add")],
            [("⬅️ " + tr(user_id, "back"), "adm_products")],
        ]))
        return
    context.user_data.clear()
    context.user_data["flow"] = "prod_add_wizard"
    context.user_data["prod_add"] = {"step": "category"}
    buttons = [(f"#{c['id']} • {platform_button_label(user_id, c['platform_key'] if 'platform_key' in c.keys() else None, c['name'])}", f"prodadd_cat:{c['id']}") for c in cats]
    rows = chunk_buttons(buttons, 1)
    rows.append([("❌ " + tr(user_id, "cancel"), "cancel_flow")])
    rows.append([("⬅️ " + tr(user_id, "back"), "adm_products")])
    await send_or_edit(update, tr(user_id, "prod_wizard_select_cat"), kb(rows))


async def product_add_choose_category(update: Update, context: ContextTypes.DEFAULT_TYPE, category_id: int) -> None:
    actor = update.effective_user.id
    if not is_admin(actor):
        await send_or_edit(update, tr(actor, "admin_only"), main_menu_kb(actor))
        return
    if not has_admin_perm(actor, "products"):
        await deny_permission(update, actor)
        return
    with db() as conn:
        cat = conn.execute("SELECT id, name, platform_key FROM categories WHERE id=? AND active=1", (category_id,)).fetchone()
    if not cat:
        await send_or_edit(update, tr(actor, "not_found"), back_home_kb(actor, "adm_products"))
        return
    context.user_data["flow"] = "prod_add_wizard"
    context.user_data["prod_add"] = {
        "step": "name",
        "category_id": int(cat["id"]),
        "category_name": platform_button_label(actor, cat["platform_key"] if "platform_key" in cat.keys() else None, str(cat["name"])),
    }
    await send_or_edit(update, tr(actor, "prod_wizard_name"), cancel_kb(actor))


BASIC_PERIOD_CODES = ("daily", "weekly", "monthly")


def product_wizard_period_kb(user_id: int, selected: Optional[Iterable[str]] = None) -> InlineKeyboardMarkup:
    selected_set = {str(x) for x in (selected or [])}
    rows: list[list[tuple[str, str]]] = []
    for code in BASIC_PERIOD_CODES:
        days, label_key = _period_payload(code)
        mark = "✅" if code in selected_set else "➕"
        rows.append([(f"{mark} {package_emoji(days)} {tr(user_id, label_key)}", f"prodadd_toggle_period:{code}")])
    rows.append([("➡️ " + tr(user_id, "prod_wizard_continue"), "prodadd_period_done")])
    rows.append([("✍️ " + tr(user_id, "prod_wizard_custom_period"), "prodadd_custom_days")])
    rows.append([("❌ " + tr(user_id, "cancel"), "cancel_flow")])
    return kb(rows)


def product_wizard_price_kb(user_id: int) -> InlineKeyboardMarkup:
    return kb([
        [("$5", "prodadd_price:5"), ("$10", "prodadd_price:10"), ("$15", "prodadd_price:15")],
        [("$20", "prodadd_price:20"), ("$25", "prodadd_price:25"), ("$30", "prodadd_price:30")],
        [("✍️ " + tr(user_id, "prod_wizard_custom_price"), "prodadd_custom_price")],
        [("⏭ " + tr(user_id, "prod_wizard_skip_price"), "prodadd_skip_price")],
        [("❌ " + tr(user_id, "cancel"), "cancel_flow")],
    ])


def product_wizard_days_kb(user_id: int) -> InlineKeyboardMarkup:
    return kb([
        [("⏭ " + tr(user_id, "prod_wizard_skip_days"), "prodadd_skip_days")],
        [("❌ " + tr(user_id, "cancel"), "cancel_flow")],
    ])


def product_wizard_desc_kb(user_id: int) -> InlineKeyboardMarkup:
    return kb([
        [("⏭ " + tr(user_id, "prod_wizard_skip_desc"), "prodadd_skip_desc")],
        [("❌ " + tr(user_id, "cancel"), "cancel_flow")],
    ])


def _period_payload(code: str) -> tuple[int, str]:
    mapping = {
        "daily": (1, "prod_wizard_daily"),
        "weekly": (7, "prod_wizard_weekly"),
        "monthly": (30, "prod_wizard_monthly"),
    }
    if code not in mapping:
        raise ValueError("bad period")
    return mapping[code]


async def flow_prod_add_wizard(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    data = context.user_data.setdefault("prod_add", {})
    step = data.get("step")
    low = text.strip().lower()
    skip_words = {"atla", "skip", "geç", "gec", "o'tkaz", "отмена", "пропустить"}

    if step == "price" and low in skip_words:
        data["price"] = 0.0
        data["description"] = ""
        data["step"] = "confirm"
        await show_product_add_confirm(update, context)
        return

    if step == "days" and low in skip_words:
        data["days"] = 30
        data["package_label"] = tr(actor, "prod_wizard_monthly")
        data["step"] = "price"
        await send_or_edit(update, tr(actor, "prod_wizard_price"), product_wizard_price_kb(actor))
        return

    if step == "name":
        name = product_group_base_name(text.strip())
        if not (2 <= len(name) <= 80):
            raise ValueError("bad product name")
        data["name"] = name
        data["step"] = "period"
        data["selected_periods"] = []
        await send_or_edit(update, tr(actor, "prod_wizard_period"), product_wizard_period_kb(actor, data["selected_periods"]))
        return

    if step == "period":
        # Admin buton yerine gün sayısı yazarsa da kabul et.
        days = int(text.strip())
        if days <= 0 or days > 36500:
            raise ValueError("bad days")
        data["days"] = days
        data["package_label"] = f"{days} gün"
        data["step"] = "price"
        await send_or_edit(update, tr(actor, "prod_wizard_price"), product_wizard_price_kb(actor))
        return

    if step == "days":
        days = int(text.strip())
        if days <= 0 or days > 36500:
            raise ValueError("bad days")
        data["days"] = days
        data["package_label"] = f"{days} gün"
        data["step"] = "price"
        await send_or_edit(update, tr(actor, "prod_wizard_price"), product_wizard_price_kb(actor))
        return

    if step == "price_each":
        price = float(text.strip().replace(",", "."))
        await product_add_set_current_price(update, context, price)
        return

    if step == "price":
        price = float(text.strip().replace(",", "."))
        if price < 0 or price > 100000:
            raise ValueError("bad price")
        data["price"] = price
        data["description"] = ""
        data["step"] = "confirm"
        await show_product_add_confirm(update, context)
        return

    if step == "desc":
        desc = text.strip()
        if desc in {"-", "—", "yok", "Yok", "none", "None"}:
            desc = ""
        if len(desc) > 500:
            raise ValueError("description too long")
        data["description"] = desc
        data["step"] = "confirm"
        await show_product_add_confirm(update, context)
        return

    raise ValueError("wizard state invalid")


async def product_add_toggle_period(update: Update, context: ContextTypes.DEFAULT_TYPE, code: str) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    if context.user_data.get("flow") != "prod_add_wizard" or data.get("step") != "period":
        await start_product_add_wizard(update, context)
        return
    if code not in BASIC_PERIOD_CODES:
        raise ValueError("bad period")
    selected = list(data.get("selected_periods") or [])
    if code in selected:
        selected = [x for x in selected if x != code]
    else:
        selected.append(code)
    selected = [code for code in BASIC_PERIOD_CODES if code in selected]
    data["selected_periods"] = selected
    await send_or_edit(update, tr(actor, "prod_wizard_period"), product_wizard_period_kb(actor, selected))


async def ask_product_add_price_each(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    days_list = [int(d) for d in data.get("days_list") or []]
    index = int(data.get("price_index") or 0)
    if not days_list or index < 0 or index >= len(days_list):
        raise ValueError("missing package selection")
    days = days_list[index]
    package = package_label_for_days(actor, days)
    text = tr(
        actor,
        "prod_wizard_price_each",
        package=clean(package),
        category=clean(data.get("category_name") or "-"),
        name=clean(product_group_base_name(data.get("name") or "-")),
    )
    await send_or_edit(update, text, product_wizard_price_kb(actor))


async def product_add_period_done(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    if context.user_data.get("flow") != "prod_add_wizard" or data.get("step") != "period":
        await start_product_add_wizard(update, context)
        return
    selected = [code for code in BASIC_PERIOD_CODES if code in (data.get("selected_periods") or [])]
    if not selected:
        await send_or_edit(
            update,
            tr(actor, "prod_wizard_period_no_selection") + "\n\n" + tr(actor, "prod_wizard_period"),
            product_wizard_period_kb(actor, selected),
        )
        return
    data["days_list"] = [_period_payload(code)[0] for code in selected]
    data["price_list"] = []
    data["price_index"] = 0
    data["package_label"] = ", ".join(package_label_for_days(actor, d) for d in data["days_list"])
    data["step"] = "price_each"
    await ask_product_add_price_each(update, context)


async def product_add_set_current_price(update: Update, context: ContextTypes.DEFAULT_TYPE, price: float) -> None:
    data = context.user_data.get("prod_add") or {}
    if data.get("step") != "price_each":
        raise ValueError("wizard state invalid")
    if price < 0 or price > 100000:
        raise ValueError("bad price")
    days_list = [int(d) for d in data.get("days_list") or []]
    prices = [float(p) for p in data.get("price_list") or []]
    index = int(data.get("price_index") or 0)
    if index < 0 or index >= len(days_list):
        raise ValueError("missing package selection")
    if len(prices) > index:
        prices[index] = float(price)
        prices = prices[: index + 1]
    else:
        prices.append(float(price))
    data["price_list"] = prices
    data["price_index"] = index + 1
    if data["price_index"] >= len(days_list):
        data["price"] = prices[0] if prices else 0.0
        data["description"] = ""
        data["step"] = "confirm"
        await show_product_add_confirm(update, context)
        return
    await ask_product_add_price_each(update, context)


async def product_add_select_period(update: Update, context: ContextTypes.DEFAULT_TYPE, code: str) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    if context.user_data.get("flow") != "prod_add_wizard" or data.get("step") != "period":
        await start_product_add_wizard(update, context)
        return
    if code not in BASIC_PERIOD_CODES:
        raise ValueError("bad period")
    data["selected_periods"] = [code]
    await product_add_period_done(update, context)


async def product_add_custom_days(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    if context.user_data.get("flow") != "prod_add_wizard" or data.get("step") != "period":
        await start_product_add_wizard(update, context)
        return
    data["step"] = "days"
    await send_or_edit(update, tr(actor, "prod_wizard_custom_days"), product_wizard_days_kb(actor))


async def product_add_select_price(update: Update, context: ContextTypes.DEFAULT_TYPE, price: float) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    if context.user_data.get("flow") != "prod_add_wizard" or data.get("step") not in {"price", "price_each"}:
        await start_product_add_wizard(update, context)
        return
    if price < 0 or price > 100000:
        raise ValueError("bad price")
    if data.get("step") == "price_each":
        await product_add_set_current_price(update, context, float(price))
        return
    data["price"] = float(price)
    data["description"] = ""
    data["step"] = "confirm"
    await show_product_add_confirm(update, context)


async def product_add_custom_price(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    if context.user_data.get("flow") != "prod_add_wizard" or data.get("step") not in {"price", "price_each"}:
        await start_product_add_wizard(update, context)
        return
    if data.get("step") == "price_each":
        await ask_product_add_price_each(update, context)
        return
    await send_or_edit(update, tr(actor, "prod_wizard_price"), product_wizard_price_kb(actor))


async def product_add_skip_price(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    if context.user_data.get("flow") != "prod_add_wizard" or data.get("step") not in {"price", "price_each"}:
        await start_product_add_wizard(update, context)
        return
    if data.get("step") == "price_each":
        await product_add_set_current_price(update, context, 0.0)
        return
    data["price"] = 0.0
    data["description"] = ""
    data["step"] = "confirm"
    await show_product_add_confirm(update, context)


async def product_add_skip_days(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    if context.user_data.get("flow") != "prod_add_wizard" or data.get("step") != "days":
        await start_product_add_wizard(update, context)
        return
    data["days"] = 30
    data["package_label"] = tr(actor, "prod_wizard_monthly")
    data["step"] = "price"
    await send_or_edit(update, tr(actor, "prod_wizard_price"), product_wizard_price_kb(actor))


async def product_add_skip_desc(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    if context.user_data.get("flow") != "prod_add_wizard" or data.get("step") != "desc":
        await start_product_add_wizard(update, context)
        return
    data["description"] = ""
    data["step"] = "confirm"
    await show_product_add_confirm(update, context)


async def show_product_add_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    data.setdefault("description", "")
    if data.get("days_list"):
        required = ("category_id", "category_name", "name", "price_list", "days_list")
        if any(k not in data for k in required):
            raise ValueError("missing product data")
        package_lines = []
        for days, price in zip(data["days_list"], data["price_list"]):
            package_lines.append(tr(
                actor,
                "prod_wizard_package_line",
                emoji=package_emoji(int(days)),
                package=clean(package_label_for_days(actor, int(days))),
                price=float(price),
                days=int(days),
            ))
        text = tr(
            actor,
            "prod_wizard_confirm_multi",
            category=clean(data["category_name"]),
            name=clean(product_group_base_name(data["name"])),
            packages="\n".join(package_lines),
        )
    else:
        required = ("category_id", "category_name", "name", "package_label", "price", "days")
        if any(k not in data for k in required):
            raise ValueError("missing product data")
        text = tr(
            actor,
            "prod_wizard_confirm",
            category=clean(data["category_name"]),
            name=clean(product_group_base_name(data["name"])),
            package=clean(data.get("package_label") or f"{int(data['days'])} gün"),
            price=float(data["price"]),
            days=int(data["days"]),
        )
    await send_or_edit(update, text, kb([
        [("✅ " + tr(actor, "prod_wizard_save"), "prodadd_confirm")],
        [("🔁 " + tr(actor, "prod_wizard_edit"), "flow:prod_add")],
        [("❌ " + tr(actor, "cancel"), "cancel_flow")],
    ]))


def save_product_package(conn: sqlite3.Connection, cat_id: int, name: str, desc: str, days: int, price: float, actor: int, package_label: str) -> int:
    """Aynı ürün + aynı süre varsa tekrar oluşturmak yerine fiyatını günceller."""
    ts = now_iso()
    base_name = product_group_base_name(name)
    candidates = conn.execute(
        """
        SELECT id, name FROM products
         WHERE category_id=? AND active=1 AND duration_days=?
         ORDER BY id DESC
        """,
        (cat_id, days),
    ).fetchall()
    existing = next((row for row in candidates if product_group_key(row["name"]) == product_group_key(base_name)), None)
    if existing:
        prod_id = int(existing["id"])
        conn.execute(
            "UPDATE products SET name=?, description=?, base_price=?, updated_at=? WHERE id=?",
            (base_name, desc, price, ts, prod_id),
        )
        add_product_history(conn, prod_id, actor, "product_update_package", f"{base_name}; {package_label}; ${price:.2f}; {days} days")
        return prod_id
    cur = conn.execute(
        """
        INSERT INTO products(category_id, name, description, duration_days, base_price, active, created_at, updated_at)
        VALUES(?,?,?,?,?,1,?,?)
        """,
        (cat_id, base_name, desc, days, price, ts, ts),
    )
    prod_id = int(cur.lastrowid)
    add_product_history(conn, prod_id, actor, "product_add", f"{base_name}; {package_label}; ${price:.2f}; {days} days")
    return prod_id


async def product_add_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_add") or {}
    if context.user_data.get("flow") != "prod_add_wizard":
        await start_product_add_wizard(update, context)
        return
    cat_id = int(data.get("category_id") or 0)
    name = product_group_base_name(str(data.get("name") or "").strip())
    desc = str(data.get("description") or "").strip()
    if not cat_id or not name:
        await start_product_add_wizard(update, context)
        return
    with db() as conn:
        cat = conn.execute("SELECT * FROM categories WHERE id=? AND active=1", (cat_id,)).fetchone()
        if not cat:
            raise ValueError("category not found")
        prod_ids: list[int] = []
        if data.get("days_list"):
            days_list = [int(d) for d in data.get("days_list", [])]
            price_list = [float(p) for p in data.get("price_list", [])]
            if not days_list or len(days_list) != len(price_list):
                raise ValueError("missing product data")
            for days, price in zip(days_list, price_list):
                package_label = package_label_for_days(actor, days)
                prod_ids.append(save_product_package(conn, cat_id, name, desc, days, price, actor, package_label))
        else:
            if "days" not in data or "price" not in data:
                await start_product_add_wizard(update, context)
                return
            days = int(data["days"])
            price = float(data["price"])
            package_label = str(data.get("package_label") or package_label_for_days(actor, days))
            prod_ids.append(save_product_package(conn, cat_id, name, desc, days, price, actor, package_label))
    context.user_data.clear()
    if len(prod_ids) == 1:
        await send_or_edit(update, tr(actor, "prod_ok", id=prod_ids[0]), admin_menu_kb(actor))
    else:
        await send_or_edit(update, tr(actor, "prod_multi_ok", ids=", ".join(map(str, prod_ids))), admin_menu_kb(actor))


async def flow_prod_add(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    cat_s, name, price_s, days_s, desc = split_pipe(text, 5)[:5]
    cat_id = int(cat_s)
    price = float(price_s.replace(",", "."))
    days = int(days_s)
    if price < 0 or days <= 0:
        raise ValueError("bad values")
    with db() as conn:
        cat = conn.execute("SELECT * FROM categories WHERE id=? AND active=1", (cat_id,)).fetchone()
        if not cat:
            raise ValueError("category not found")
        package_label = package_label_for_days(actor, days)
        prod_id = save_product_package(conn, cat_id, name, desc, days, price, actor, package_label)
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "prod_ok", id=prod_id), admin_menu_kb(actor))


def duration_key(days: int) -> int:
    days = int(days or 0)
    return 30 if days in (30, 31) else days


def product_edit_price_kb(user_id: int, product_id: Optional[int] = None) -> InlineKeyboardMarkup:
    rows = [
        [("$1", "prodedit_price:1"), ("$3", "prodedit_price:3"), ("$5", "prodedit_price:5")],
        [("$10", "prodedit_price:10"), ("$15", "prodedit_price:15"), ("$20", "prodedit_price:20")],
    ]
    if product_id:
        rows.append([("🗑 " + tr(user_id, "prod_edit_disable_package"), f"prodedit_disable_pkg:{product_id}")])
    rows.append([("❌ " + tr(user_id, "cancel"), "cancel_flow")])
    return kb(rows)


async def start_product_edit(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not is_admin(user_id):
        await send_or_edit(update, tr(user_id, "admin_only"), main_menu_kb(user_id))
        return
    if not has_admin_perm(user_id, "products"):
        await deny_permission(update, user_id)
        return
    with db() as conn:
        ensure_platform_categories(conn)
        cats = conn.execute(
            f"""
            SELECT c.id, c.name, c.platform_key,
                   (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id AND p.active=1) AS product_count
              FROM categories c
             WHERE c.active=1
             ORDER BY {platform_order_sql('c')}, c.id DESC
            """
        ).fetchall()
    rows: list[list[tuple[str, str]]] = []
    for c in cats:
        count = int(c["product_count"] or 0)
        if count <= 0:
            continue
        rows.append([(f"{platform_button_label(user_id, c['platform_key'] if 'platform_key' in c.keys() else None, c['name'])} ({count})", f"prodedit_cat:{c['id']}")])
    if not rows:
        await send_or_edit(update, tr(user_id, "prod_edit_empty"), back_home_kb(user_id, "adm_products"))
        return
    rows.append([("⬅️ " + tr(user_id, "back"), "adm_products")])
    await send_or_edit(update, tr(user_id, "prod_edit_select_platform"), kb(rows))


async def show_product_edit_groups(update: Update, context: ContextTypes.DEFAULT_TYPE, category_id: int) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "products"):
        await deny_permission(update, user_id)
        return
    with db() as conn:
        cat = conn.execute("SELECT id, name, platform_key FROM categories WHERE id=? AND active=1", (category_id,)).fetchone()
        products = conn.execute(
            """
            SELECT p.*,
                   (SELECT COUNT(*) FROM keys k WHERE k.product_id=p.id AND k.status='stock') AS stock
              FROM products p
             WHERE p.category_id=? AND p.active=1
             ORDER BY lower(trim(p.name)) ASC, p.duration_days ASC, p.id ASC
            """,
            (category_id,),
        ).fetchall()
    if not cat:
        await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id, "adm_products"))
        return
    grouped: dict[str, dict[str, Any]] = {}
    for p in products:
        base = product_group_base_name(str(p["name"]))
        gkey = product_group_key(base)
        group = grouped.setdefault(gkey, {"name": base, "first_id": int(p["id"]), "package_keys": set()})
        group["package_keys"].add(duration_key(int(p["duration_days"])))
    if not grouped:
        await send_or_edit(update, tr(user_id, "prod_edit_empty"), back_home_kb(user_id, "prodedit_start"))
        return
    rows: list[list[tuple[str, str]]] = []
    for group in sorted(grouped.values(), key=lambda g: product_group_key(g["name"])):
        name = str(group["name"])
        label = f"{product_group_emoji(name)} {name} ({len(group['package_keys'])})"
        rows.append([(label, f"prodedit_grp:{category_id}:{int(group['first_id'])}")])
    cat_title = platform_button_label(user_id, cat["platform_key"] if "platform_key" in cat.keys() else None, cat["name"])
    rows.append([("⬅️ " + tr(user_id, "back"), "prodedit_start"), ("🏠 " + tr(user_id, "home"), "home")])
    await send_or_edit(update, tr(user_id, "prod_edit_select_group", category=clean(cat_title)), kb(rows))


async def get_edit_group_products(category_id: int, sample_product_id: int) -> tuple[sqlite3.Row, sqlite3.Row, str, list[sqlite3.Row]]:
    with db() as conn:
        sample = conn.execute("SELECT * FROM products WHERE id=? AND category_id=?", (sample_product_id, category_id)).fetchone()
        cat = conn.execute("SELECT id, name, platform_key FROM categories WHERE id=? AND active=1", (category_id,)).fetchone()
        if not sample or not cat:
            raise ValueError("not found")
        group_name = product_group_base_name(str(sample["name"]))
        all_products = conn.execute("SELECT * FROM products WHERE category_id=? AND active=1 ORDER BY id ASC", (category_id,)).fetchall()
        products = [p for p in all_products if product_group_key(str(p["name"])) == product_group_key(group_name)]
    return cat, sample, group_name, products


async def show_product_edit_group(update: Update, context: ContextTypes.DEFAULT_TYPE, category_id: int, sample_product_id: int) -> None:
    user_id = update.effective_user.id
    if not has_admin_perm(user_id, "products"):
        await deny_permission(update, user_id)
        return
    try:
        cat, sample, group_name, products = await get_edit_group_products(category_id, sample_product_id)
    except Exception:
        await send_or_edit(update, tr(user_id, "not_found"), back_home_kb(user_id, f"prodedit_cat:{category_id}"))
        return
    by_duration: dict[int, sqlite3.Row] = {duration_key(int(p["duration_days"])): p for p in products}
    rows: list[list[tuple[str, str]]] = []
    for code in BASIC_PERIOD_CODES:
        days, label_key = _period_payload(code)
        p = by_duration.get(duration_key(days))
        label = package_label_for_days(user_id, days)
        if p:
            button = f"✅ {package_emoji(days)} {label} • ${float(p['base_price']):.2f} • {tr(user_id, 'prod_edit_package_edit')}"
        else:
            button = f"➕ {package_emoji(days)} {label} • {tr(user_id, 'prod_edit_package_add')}"
        rows.append([(button, f"prodedit_pkg:{category_id}:{sample_product_id}:{code}")])
    cat_title = platform_button_label(user_id, cat["platform_key"] if "platform_key" in cat.keys() else None, cat["name"])
    text = tr(
        user_id,
        "prod_edit_group_title",
        category=clean(cat_title),
        name=clean(f"{product_group_emoji(group_name)} {group_name}"),
    )
    rows.append([("⬅️ " + tr(user_id, "back"), f"prodedit_cat:{category_id}"), ("🏠 " + tr(user_id, "home"), "home")])
    await send_or_edit(update, text, kb(rows))


async def start_product_edit_package_price(update: Update, context: ContextTypes.DEFAULT_TYPE, category_id: int, sample_product_id: int, code: str) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "products"):
        await deny_permission(update, actor)
        return
    if code not in BASIC_PERIOD_CODES:
        raise ValueError("bad period")
    cat, sample, group_name, products = await get_edit_group_products(category_id, sample_product_id)
    days, _ = _period_payload(code)
    existing = None
    for p in products:
        if duration_key(int(p["duration_days"])) == duration_key(days):
            existing = p
            break
    context.user_data.clear()
    context.user_data["flow"] = "prod_edit_price"
    context.user_data["prod_edit"] = {
        "category_id": int(category_id),
        "sample_product_id": int(sample_product_id),
        "product_id": int(existing["id"]) if existing else None,
        "name": group_name,
        "days": int(days),
        "package_label": package_label_for_days(actor, days),
        "description": str(existing["description"] or "") if existing else "",
    }
    current = f"${float(existing['base_price']):.2f}" if existing else "-"
    text = tr(
        actor,
        "prod_edit_price_prompt",
        package=clean(package_label_for_days(actor, days)),
        name=clean(group_name),
        current=clean(current),
    )
    await send_or_edit(update, text, product_edit_price_kb(actor, int(existing["id"]) if existing else None))


async def save_product_edit_price(update: Update, context: ContextTypes.DEFAULT_TYPE, price: float) -> None:
    actor = update.effective_user.id
    data = context.user_data.get("prod_edit") or {}
    if context.user_data.get("flow") != "prod_edit_price":
        await start_product_edit(update, context)
        return
    if price < 0 or price > 100000:
        raise ValueError("bad price")
    cat_id = int(data.get("category_id") or 0)
    sample_product_id = int(data.get("sample_product_id") or 0)
    days = int(data.get("days") or 0)
    name = product_group_base_name(str(data.get("name") or "").strip())
    desc = str(data.get("description") or "")
    package_label = str(data.get("package_label") or package_label_for_days(actor, days))
    if not cat_id or not days or not name:
        raise ValueError("missing edit data")
    with db() as conn:
        prod_id = save_product_package(conn, cat_id, name, desc, days, float(price), actor, package_label)
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "prod_edit_saved"), kb([
        [("✏️ " + tr(actor, "edit_product"), f"prodedit_grp:{cat_id}:{prod_id or sample_product_id}")],
        [("⬅️ " + tr(actor, "back"), f"prodedit_cat:{cat_id}"), ("🏠 " + tr(actor, "home"), "home")],
    ]))


async def flow_product_edit_price(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    price = float(text.strip().replace(",", "."))
    await save_product_edit_price(update, context, price)


async def product_edit_select_price(update: Update, context: ContextTypes.DEFAULT_TYPE, price: float) -> None:
    await save_product_edit_price(update, context, price)


async def product_edit_disable_package(update: Update, context: ContextTypes.DEFAULT_TYPE, product_id: int) -> None:
    actor = update.effective_user.id
    if not has_admin_perm(actor, "products"):
        await deny_permission(update, actor)
        return
    data = context.user_data.get("prod_edit") or {}
    cat_id = int(data.get("category_id") or 0)
    sample_id = int(data.get("sample_product_id") or product_id)
    with db() as conn:
        row = conn.execute("SELECT category_id FROM products WHERE id=?", (product_id,)).fetchone()
        if not row:
            raise ValueError("not found")
        cat_id = cat_id or int(row["category_id"])
        conn.execute("UPDATE products SET active=0, updated_at=? WHERE id=?", (now_iso(), product_id))
        add_product_history(conn, product_id, actor, "product_package_disable", f"Package product #{product_id} disabled")
        alt = conn.execute("SELECT id FROM products WHERE category_id=? AND active=1 ORDER BY id DESC LIMIT 1", (cat_id,)).fetchone()
        if alt:
            sample_id = int(alt["id"])
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "prod_edit_disabled"), kb([
        [("⬅️ " + tr(actor, "back"), f"prodedit_grp:{cat_id}:{sample_id}" if sample_id else f"prodedit_cat:{cat_id}")],
        [("🏠 " + tr(actor, "home"), "home")],
    ]))


async def flow_prod_del(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    prod_id = int(text.strip())
    with db() as conn:
        cur = conn.execute("UPDATE products SET active=0, updated_at=? WHERE id=?", (now_iso(), prod_id))
        if cur.rowcount == 0:
            raise ValueError("not found")
        add_product_history(conn, prod_id, actor, "product_delete", f"Product #{prod_id} disabled")
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "prod_deleted"), admin_menu_kb(actor))


async def flow_balance(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    actor = update.effective_user.id
    target_s, amount_s, *rest = split_pipe(text, 2)
    target = int(target_s)
    amount = float(amount_s.replace(",", "."))
    note = rest[0] if rest else "Admin balance update"
    with db() as conn:
        upsert_user_raw(conn, target, None, None, active_session=1)
        conn.execute("UPDATE users SET balance=balance+?, updated_at=? WHERE user_id=?", (amount, now_iso(), target))
        conn.execute(
            "INSERT INTO transactions(user_id, amount, type, note, created_at) VALUES(?,?,?,?,?)",
            (target, amount, "balance_add", f"{note} | admin={actor}", now_iso()),
        )
        row = conn.execute("SELECT balance FROM users WHERE user_id=?", (target,)).fetchone()
    context.user_data.clear()
    await send_or_edit(update, tr(actor, "balance_ok", user_id=target, balance=float(row["balance"])), admin_menu_kb(actor))


# =========================
# CALLBACK ROUTER
# =========================
async def callback_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await safe_answer(update)
    ensure_user(update, login=None)
    user_id = update.effective_user.id
    data = update.callback_query.data or ""

    if data == "auth":
        await show_auth_screen(update, context)
        return
    if data == "auth_register":
        await start_auth_register(update, context)
        return
    if data == "auth_login":
        await start_auth_login(update, context)
        return
    if data == "auth_forgot":
        await start_auth_forgot(update, context)
        return

    if data == "cancel_flow":
        context.user_data.clear()
        if not session_active(user_id):
            await show_auth_screen(update, context)
        else:
            await send_or_edit(update, tr(user_id, "cancelled"), main_menu_kb(user_id))
        return

    if data == "language":
        await show_language(update, context)
        return
    if data.startswith("set_lang:"):
        await set_language(update, context, data.split(":", 1)[1])
        return

    if is_banned_id(user_id):
        await send_or_edit(update, tr(user_id, "banned_msg", user_id=user_id))
        return
    if not session_active(user_id):
        await show_auth_screen(update, context, "auth_required")
        return
    if not is_approved_user(user_id) and data not in {"logout", "language"} and not data.startswith("set_lang:"):
        await send_or_edit(update, tr(user_id, "auth_pending", user_id=user_id), kb([[ ("🚪 " + tr(user_id, "logout"), "logout"), ("🌐 " + tr(user_id, "language"), "language") ]]))
        return

    if data == "home":
        context.user_data.clear()
        await show_home(update, context)
    elif data == "buy":
        await show_categories(update, context)
    elif data.startswith("cat:"):
        await show_products(update, context, int(data.split(":", 1)[1]))
    elif data.startswith("grp:"):
        _, category_id_s, sample_product_id_s = data.split(":", 2)
        await show_product_group(update, context, int(category_id_s), int(sample_product_id_s))
    elif data.startswith("prod:"):
        await show_product(update, context, int(data.split(":", 1)[1]))
    elif data.startswith("buy_confirm:"):
        await do_purchase(update, context, int(data.split(":", 1)[1]))
    elif data == "my_keys":
        await show_my_keys(update, context)
    elif data.startswith("key:"):
        await show_key(update, context, int(data.split(":", 1)[1]))
    elif data.startswith("key_reset:"):
        await request_key_reset(update, context, int(data.split(":", 1)[1]))
    elif data == "tx_history":
        await show_transactions(update, context)
    elif data == "prices":
        await show_price_list(update, context)
    elif data == "balance":
        await show_balance(update, context)
    elif data == "layout":
        await show_layout(update, context)
    elif data.startswith("set_layout:"):
        await set_layout(update, context, data.split(":", 1)[1])
    elif data == "language":
        await show_language(update, context)
    elif data.startswith("set_lang:"):
        await set_language(update, context, data.split(":", 1)[1])
    elif data == "logout":
        await do_logout(update, context)
    elif data == "admin":
        await show_admin(update, context)
    elif data == "adm_resellers":
        await admin_resellers(update, context)
    elif data == "adm_reseller_list":
        await list_resellers(update, context)
    elif data == "adm_prices":
        await admin_prices(update, context)
    elif data == "adm_price_list":
        await list_prices(update, context)
    elif data == "adm_keys":
        await admin_keys(update, context)
    elif data == "stock_platforms":
        await show_stock_platforms_admin(update, context)
    elif data.startswith("stock_cat:"):
        await show_stock_groups_admin(update, context, int(data.split(":", 1)[1]))
    elif data.startswith("stock_group:"):
        _, category_id_s, sample_product_id_s = data.split(":", 2)
        await show_stock_packages_admin(update, context, int(category_id_s), int(sample_product_id_s))
    elif data.startswith("stock_pkg:"):
        await send_stock_keys_txt_admin(update, context, int(data.split(":", 1)[1]))
    elif data == "adm_reset_requests":
        await list_reset_requests_admin(update, context)
    elif data.startswith("reset_approve:"):
        await approve_reset_request(update, context, int(data.split(":", 1)[1]))
    elif data.startswith("reset_reject:"):
        await reject_reset_request(update, context, int(data.split(":", 1)[1]))
    elif data == "adm_cats":
        await admin_cats(update, context)
    elif data == "adm_products":
        await admin_products(update, context)
    elif data == "adm_product_list":
        await list_products_admin(update, context)
    elif data == "prodedit_start":
        await start_product_edit(update, context)
    elif data.startswith("prodedit_cat:"):
        await show_product_edit_groups(update, context, int(data.split(":", 1)[1]))
    elif data.startswith("prodedit_grp:"):
        _, category_id_s, sample_product_id_s = data.split(":", 2)
        await show_product_edit_group(update, context, int(category_id_s), int(sample_product_id_s))
    elif data.startswith("prodedit_pkg:"):
        _, category_id_s, sample_product_id_s, code = data.split(":", 3)
        await start_product_edit_package_price(update, context, int(category_id_s), int(sample_product_id_s), code)
    elif data.startswith("prodedit_price:"):
        await product_edit_select_price(update, context, float(data.split(":", 1)[1]))
    elif data.startswith("prodedit_disable_pkg:"):
        await product_edit_disable_package(update, context, int(data.split(":", 1)[1]))
    elif data == "adm_balance":
        await admin_balance(update, context)
    elif data == "adm_history":
        await product_history_admin(update, context)
    elif data.startswith("hist_page:"):
        await product_history_admin(update, context, int(data.split(":", 1)[1]))
    elif data == "adm_users":
        await admin_users_menu(update, context)
    elif data == "adm_user_list":
        await list_users_admin(update, context)
    elif data == "adm_bans":
        await admin_bans_menu(update, context)
    elif data == "adm_ban_list":
        await list_banned_admin(update, context)
    elif data.startswith("manage_user:"):
        await show_admin_user_detail(update, context, int(data.split(":", 1)[1]))
    elif data.startswith("user_approve:"):
        _, tid, val = data.split(":", 2)
        await set_user_approval(update, context, int(tid), int(val))
    elif data.startswith("user_role:"):
        _, tid, role = data.split(":", 2)
        await set_user_role_inline(update, context, int(tid), role)
    elif data.startswith("user_perms:"):
        await show_user_permissions(update, context, int(data.split(":", 1)[1]))
    elif data.startswith("perm_toggle:"):
        _, tid, perm = data.split(":", 2)
        await toggle_user_permission(update, context, int(tid), perm)
    elif data.startswith("user_ban:"):
        await ban_user_inline(update, context, int(data.split(":", 1)[1]))
    elif data == "adm_seed":
        await seed_demo(update, context)
    elif data.startswith("prodadd_cat:"):
        await product_add_choose_category(update, context, int(data.split(":", 1)[1]))
    elif data.startswith("prodadd_toggle_period:"):
        await product_add_toggle_period(update, context, data.split(":", 1)[1])
    elif data == "prodadd_period_done":
        await product_add_period_done(update, context)
    elif data.startswith("prodadd_period:"):
        await product_add_select_period(update, context, data.split(":", 1)[1])
    elif data == "prodadd_custom_days":
        await product_add_custom_days(update, context)
    elif data.startswith("prodadd_price:"):
        await product_add_select_price(update, context, float(data.split(":", 1)[1]))
    elif data == "prodadd_custom_price":
        await product_add_custom_price(update, context)
    elif data == "prodadd_skip_price":
        await product_add_skip_price(update, context)
    elif data == "prodadd_skip_days":
        await product_add_skip_days(update, context)
    elif data == "prodadd_skip_desc":
        await product_add_skip_desc(update, context)
    elif data == "prodadd_confirm":
        await product_add_confirm(update, context)
    elif data.startswith("flow:"):
        await start_flow(update, context, data.split(":", 1)[1])
    else:
        await send_or_edit(update, tr(user_id, "unknown"), main_menu_kb(user_id))


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.exception("Unhandled error while processing update", exc_info=context.error)
    if isinstance(update, Update) and update.effective_message:
        try:
            uid = update.effective_user.id if update.effective_user else 0
            await update.effective_message.reply_text(tr(uid, "bad_format"), parse_mode=ParseMode.HTML)
        except Exception:
            pass


def build_application() -> Application:
    if not BOT_TOKEN:
        print("HATA: BOT_TOKEN veya TELEGRAM_BOT_TOKEN ortam değişkeni yok.")
        print("Örnek:")
        print('  BOT_TOKEN="123456:ABC" python jerry_key_bayi_bot.py')
        sys.exit(1)
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("menu", cmd_menu))
    app.add_handler(CommandHandler("admin", cmd_admin))
    app.add_handler(CommandHandler("id", cmd_id))
    app.add_handler(CommandHandler("logout", cmd_logout))
    app.add_handler(CallbackQueryHandler(callback_router))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_error_handler(error_handler)
    return app


def main() -> None:
    init_db()
    app = build_application()
    logger.info("JERRY Key Bayi Bot başlatılıyor. DB=%s", DB_PATH)
    app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)


if __name__ == "__main__":
    main()
