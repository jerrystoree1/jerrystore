JERRY MiniApp Kurulum

1) Bot dosyası:
   jerry_yeni_api.py dosyası artık MINIAPP_URL ortam değişkeni doluysa ana menüde MiniApp butonu gösterir.

2) MiniApp backend:
   cd jerry_miniapp
   pip install -r requirements.txt
   BOT_TOKEN="8842464258:AAHt4cCqOSaQ4nI8yJ1d1tb-On1s16XARiQ" JERRY_DB="../jerry_bayi_bot.sqlite3" python miniapp_server.py

3) Telegram MiniApp HTTPS ister:
   Lokal test için örnek:
   cloudflared tunnel --url http://localhost:8000
   veya
   ngrok http 8000

4) Botu MiniApp URL ile başlat:
   MINIAPP_URL="https://senin-public-url-adresin" python jerry_yeni_api.py

5) BotFather tarafı:
   /setdomain komutu ile public domaini botuna tanımla.

Notlar:
- MiniApp satın alma işlemini şimdilik bot tarafındaki mevcut güvenli akışa bırakır.
- Web panelde kullanıcı bilgisi, ürün/stok listesi, key geçmişi ve işlem geçmişi görünür.
- initData doğrulaması backend tarafında yapılır; Telegram dışından açılırsa API hata verir.
