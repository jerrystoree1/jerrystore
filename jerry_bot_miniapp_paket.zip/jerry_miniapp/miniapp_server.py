#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JERRY Telegram Mini App Backend

Çalıştırma:
  pip install flask
  BOT_TOKEN="8842464258:AAHt4cCqOSaQ4nI8yJ1d1tb-On1s16XARiQ" JERRY_DB="../jerry_bayi_bot.sqlite3" python miniapp_server.py

Not: Telegram Mini App için HTTPS public URL gerekir. Lokal test için ngrok/cloudflared kullanılabilir.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import sqlite3
import time
from pathlib import Path
from urllib.parse import parse_qsl

from flask import Flask, jsonify, request, send_from_directory

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = os.environ.get("JERRY_DB", str(BASE_DIR.parent / "jerry_bayi_bot.sqlite3"))
BOT_TOKEN = os.environ.get("BOT_TOKEN") or os.environ.get("TELEGRAM_BOT_TOKEN") or "8842464258:AAHt4cCqOSaQ4nI8yJ1d1tb-On1s16XARiQ"
MAX_INITDATA_AGE = int(os.environ.get("MINIAPP_INITDATA_MAX_AGE", "86400"))

app = Flask(__name__, static_folder=str(BASE_DIR / "static"))


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    return conn


def verify_init_data(init_data: str) -> dict:
    """Telegram WebApp initData doğrulaması."""
    if not init_data:
        raise ValueError("Telegram initData yok.")
    pairs = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = pairs.pop("hash", None)
    if not received_hash:
        raise ValueError("initData hash eksik.")

    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
    calculated_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated_hash, received_hash):
        raise ValueError("initData doğrulaması başarısız.")

    auth_date = int(pairs.get("auth_date", "0") or "0")
    if auth_date and time.time() - auth_date > MAX_INITDATA_AGE:
        raise ValueError("initData süresi dolmuş.")

    user = json.loads(pairs.get("user", "{}") or "{}")
    if not user.get("id"):
        raise ValueError("Telegram kullanıcı bilgisi yok.")
    return user


def current_user() -> dict:
    auth = request.headers.get("X-Telegram-Init-Data", "")
    return verify_init_data(auth)


@app.get("/")
def index():
    return send_from_directory(BASE_DIR / "static", "index.html")


@app.get("/api/me")
def api_me():
    tg_user = current_user()
    uid = int(tg_user["id"])
    with db() as conn:
        row = conn.execute("SELECT user_id, username, first_name, email, role, balance, approved, active_session, lang FROM users WHERE user_id=?", (uid,)).fetchone()
        banned = conn.execute("SELECT 1 FROM banned_users WHERE user_id=?", (uid,)).fetchone() is not None
    return jsonify({"telegram": tg_user, "user": dict(row) if row else None, "banned": banned})


@app.get("/api/catalog")
def api_catalog():
    current_user()
    with db() as conn:
        cats = conn.execute("SELECT id, name, description, platform_key FROM categories WHERE active=1 ORDER BY COALESCE(platform_key,''), id").fetchall()
        products = conn.execute(
            """
            SELECT p.id, p.category_id, p.name, p.duration_days, p.base_price,
                   c.name AS category_name,
                   (SELECT COUNT(*) FROM keys k WHERE k.product_id=p.id AND k.status='stock') AS stock
              FROM products p
              JOIN categories c ON c.id=p.category_id
             WHERE p.active=1 AND c.active=1
             ORDER BY c.id, p.name, p.duration_days
            """
        ).fetchall()
    return jsonify({"categories": [dict(x) for x in cats], "products": [dict(x) for x in products]})


@app.get("/api/my-keys")
def api_my_keys():
    tg_user = current_user()
    uid = int(tg_user["id"])
    with db() as conn:
        rows = conn.execute(
            """
            SELECT k.id, k.key_value, k.status, k.sold_at, k.expires_at, k.reset_count, k.max_resets,
                   p.name AS product_name, c.name AS category_name
              FROM keys k
              JOIN products p ON p.id=k.product_id
              JOIN categories c ON c.id=p.category_id
             WHERE k.owner_id=?
             ORDER BY k.sold_at DESC, k.id DESC
             LIMIT 100
            """,
            (uid,),
        ).fetchall()
    return jsonify({"keys": [dict(x) for x in rows]})


@app.get("/api/transactions")
def api_transactions():
    tg_user = current_user()
    uid = int(tg_user["id"])
    with db() as conn:
        rows = conn.execute(
            """
            SELECT id, product_id, key_id, amount, type, note, created_at
              FROM transactions
             WHERE user_id=?
             ORDER BY created_at DESC, id DESC
             LIMIT 100
            """,
            (uid,),
        ).fetchall()
    return jsonify({"transactions": [dict(x) for x in rows]})


@app.errorhandler(Exception)
def handle_error(exc):
    return jsonify({"error": str(exc)}), 400


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    app.run(host="0.0.0.0", port=port)
